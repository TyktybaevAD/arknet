from www.celery import app
from services.hospital.save_oper_sluch import Load_md
from services.hospital.create_reestr import Create
from services.hospital.patient_lists_reports import Create as Create_lists_reports
from services.hospital.reference_reports import Create as Create_reference_reports
from services.hospital.annual_reports import Create as Create_annual_reports
import json

@app.task
def save_oper_sluch(user):
    load_md = Load_md(user)
    #Убрать на боеваом сервере
    load_md.clear_md()
    ###
    load_md.load_data(user)
    return load_md.insert_temp.rez


@app.task
def create_reestr(user, date_1, date_2,filename,type_reestr):
    create = Create(user,date_1,date_2,filename,type_reestr)
    create.create()
    return 'Create Reestr OK !!!! '

@app.task
def create_mix_reports(user,request):
    if (request.get('list_data',None) != None):
        reports = Create_lists_reports(user,request)
        reports.create()
        return 'Create mix reports'
    else:
        return 'Not mix create reports'

@app.task
def create_reference_reports(user,request):
    reports = Create_reference_reports(user,request)
    reports.create()
    return 'Create reference reports'

@app.task
def create_annual_reports(user,request):
    reports = Create_annual_reports(user,request)
    reports.create()
    return 'Create annual reports'