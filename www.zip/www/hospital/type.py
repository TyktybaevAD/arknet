from graphene_django import DjangoObjectType
from okb2.models import (V005,otde,Rab_Ner,T004,F003,Vrzb,Oksm,Ds,V012,V009,V020,Vra,V021,
                         PR_OSOB,V001,T006,Ab_Obsh,Pope,Prli,Trv,Isfin,Skom,F008,F011,N018,
                         N002,N003,N004,N005,N007,N010,N008,
                         N011,N019,N013,N014,N001,V028,V029,V014,Prpg,PER,PR_PER,Tip_pb,Met_pb,V027,
                         Trvnas,V002,anesthesia,V018_bpoms,V019_bpoms,V018_sboms,V019_sboms,Tar_vt,group_kc_dkk,
                         Age_group)




class V005Type(DjangoObjectType):
    class Meta:
        model = V005
        fields = ('polname',)

class OtdeType(DjangoObjectType):
    class Meta:
        model = otde
        fields = ('naim',)

class Rab_nerType(DjangoObjectType):
    class Meta:
        model = Rab_Ner
        fields = ('naim',)

class T004Type(DjangoObjectType):
    class Meta:
        model = T004
        fields = ('name',)

class F003Type(DjangoObjectType):
    class Meta:
        model = F003
        fields = ('naim',)

class VrzbType(DjangoObjectType):
    class Meta:
        model = Vrzb
        fields = ('naim',)

class OksmType(DjangoObjectType):
    class Meta:
        model = Oksm
        fields = ('naim',)

class DsType(DjangoObjectType):
    class Meta:
        model = Ds
        fields = ('kod','naim')

class V012Type(DjangoObjectType):
    class Meta:
        model = V012
        fields = ('iz_name','id_iz')


class V009Type(DjangoObjectType):
    class Meta:
        model = V009
        fields = ('tip_name','id_tip')

class V020Type(DjangoObjectType):
    class Meta:
        model = V020
        fields = ('k_prname',)

class VraType(DjangoObjectType):
    class Meta:
        model = Vra
        fields = ('kod','naim','v021','kod_spec','v002')

class V021Type(DjangoObjectType):
    class Meta:
        model = V021
        fields = ('specname',)

class PR_OSOBType(DjangoObjectType):
    class Meta:
        model = PR_OSOB
        fields = ('kod','naim')

class V001Type(DjangoObjectType):
    class Meta:
        model = V001
        fields = ('kod','naim')

class T006Type(DjangoObjectType):
    class Meta:
        model = T006
        fields = ('code_usl_kz','ksg','code_usl','title')

class Ab_ObshType(DjangoObjectType):
    class Meta:
        model = Ab_Obsh
        fields = ('kod','ima')

class PopeType(DjangoObjectType):
    class Meta:
        model = Pope
        fields = ('kod','naim')

class PrliType(DjangoObjectType):
    class Meta:
        model = Prli
        fields = ('naim','kod')

class TrvType(DjangoObjectType):
    class Meta:
        model = Trv
        fields = ('naim',)

class IsfinType(DjangoObjectType):
    class Meta:
        model = Isfin
        fields = ('naim',)

class SkomType(DjangoObjectType):
    class Meta:
        model = Skom
        fields = ('naim',)

class F008Type(DjangoObjectType):
    class Meta:
        model = F008
        fields = ('tip_name',)

class F011Type(DjangoObjectType):
    class Meta:
        model = F011
        fields = ('docname','id_doc')

class N018Type(DjangoObjectType):
    class Meta:
        model = N018
        fields = ('reas_name',)

class N002Type(DjangoObjectType):
    class Meta:
        model = N002
        fields = ('kod_st',)

class N003Type(DjangoObjectType):
    class Meta:
        model = N003
        fields = ('kod_t',)

class N004Type(DjangoObjectType):
    class Meta:
        model = N004
        fields = ('kod_n',)

class N005Type(DjangoObjectType):
    class Meta:
        model = N005
        fields = ('kod_m',)

class N007Type(DjangoObjectType):
    class Meta:
        model = N007
        fields = ('mrf_name',)

class N010Type(DjangoObjectType):
    class Meta:
        model = N010
        fields = ('kod_igh','igh_name')


class N008Type(DjangoObjectType):
    class Meta:
        model = N008
        fields = ('r_m_name',)

class N011Type(DjangoObjectType):
    class Meta:
        model = N011
        fields = ('r_i_name',)

class N019Type(DjangoObjectType):
    class Meta:
        model = N019
        fields = ('cons_name',)

class N013Type(DjangoObjectType):
    class Meta:
        model = N013
        fields = ('tlech_name',)

class N014Type(DjangoObjectType):
    class Meta:
        model = N014
        fields = ('thir_name',)

class N001Type(DjangoObjectType):
    class Meta:
        model = N001
        fields = ('prot_name',)

class V028Type(DjangoObjectType):
    class Meta:
        model = V028
        fields = ('n_vn',)

class V029Type(DjangoObjectType):
    class Meta:
        model = V029
        fields = ('n_met',)

class V014Type(DjangoObjectType):
    class Meta:
        model = V014
        fields = ('tip_name',)

class PrpgType(DjangoObjectType):
    class Meta:
        model = Prpg
        fields = ('naim',)

class PERType(DjangoObjectType):
    class Meta:
        model = PER
        fields = ('naim',)

class PR_PERType(DjangoObjectType):
    class Meta:
        model = PR_PER
        fields = ('naim',)

class Tip_pbType(DjangoObjectType):
    class Meta:
        model = Tip_pb
        fields = ('naim',)

class Met_pbType(DjangoObjectType):
    class Meta:
        model = Met_pb
        fields = ('naim',)

class V027Type(DjangoObjectType):
    class Meta:
        model = V027
        fields = ('n_cz',)


class TrvnasType(DjangoObjectType):
    class Meta:
        model = Trvnas
        fields = ('naim',)

class V002Type(DjangoObjectType):
    class Meta:
        model = V002
        fields = ('id_pr',)


class anesthesiaType(DjangoObjectType):
    class Meta:
        model = anesthesia
        fields = ('kod',)

class V018_bpomsType(DjangoObjectType):
    class Meta:
        model = V018_bpoms
        fields = ('idhvid',)

class V019_bpomsType(DjangoObjectType):
    class Meta:
        model = V019_bpoms
        fields = ('hvid',)


# class V018_sbomsType(DjangoObjectType):
#     class Meta:
#         model = V018_sboms
#         fields = ('hvid',)

class V019_sbomsType(DjangoObjectType):
    class Meta:
        model = V019_sboms
        fields = ('idhvid',)


class Tar_vtType(DjangoObjectType):
    class Meta:
        model = Tar_vt
        fields = ('kod','naim')


# class T006Type(DjangoObjectType):
#     class Meta:
#         model = T006
#         fields = ('ksg','code_usl','title')

class group_kc_dkkType(DjangoObjectType):
    class Meta:
        model = group_kc_dkk
        fields = ('kod',)

class Age_groupType(DjangoObjectType):
    class Meta:
        model = Age_group
        fields = ('name',)