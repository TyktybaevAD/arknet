import json
from channels.generic.websocket import AsyncWebsocketConsumer

class ReportsConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.user_id = self.scope['url_route']['kwargs']['user_id']
        self.user_group_name = 'hospital_reports_%s' % self.user_id
        await self.channel_layer.group_add(self.user_group_name,
                                           self.channel_name)
        await self.accept()

    async def disconnect(self, code):
        pass

    async def report_data(self,event):
        new_data = event['text']
        await self.send(json.dumps(new_data))

class ReferenceConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.user_id = self.scope['url_route']['kwargs']['user_id']
        self.user_group_name = 'hospital_reference_%s' % self.user_id
        await self.channel_layer.group_add(self.user_group_name,
                                           self.channel_name)
        await self.accept()

    async def disconnect(self, code):
        pass

    async def report_data(self,event):
        new_data = event['text']
        await self.send(json.dumps(new_data))

class ExportFrom1cConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.user_id = self.scope['url_route']['kwargs']['user_id']
        self.user_group_name = 'hospital_exportfrom1c_%s' % self.user_id
        await self.channel_layer.group_add(self.user_group_name,
                                           self.channel_name)
        await self.accept()

    async def disconnect(self, code):
        pass

    async def report_data(self,event):
        await self.send(json.dumps(event))

    async def progress(self,event):
        await self.send(json.dumps(event))


class CreateReestr(AsyncWebsocketConsumer):
    async def connect(self):
        self.user_id = self.scope['url_route']['kwargs']['user_id']
        self.user_group_name = 'hospital_createreestr_%s' % self.user_id
        await self.channel_layer.group_add(self.user_group_name,
                                           self.channel_name)
        await self.accept()

    async def disconnect(self, code):
        pass

    async def report_data(self,event):
        await self.send(json.dumps(event))

    async def progress(self,event):
        await self.send(json.dumps(event))