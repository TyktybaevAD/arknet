from django.shortcuts import render
from django.views.generic import View
from django.http import JsonResponse
from .models import Load_1c
from .forms import Load_1c_forms

from .tasks import (save_oper_sluch,
                    create_reestr,
                    create_mix_reports,
                    create_reference_reports,
                    create_annual_reports)
from services.hospital.search_history import Search_history
from services.hospital.history import History
from services.hospital.history_save import Save
# Create your views here.
class index(View):
    def get(self, request):
        return render(request, 'hospital_index.html')
    def post(self,request):
        if request.POST.get('type') == 'get_user':
            return JsonResponse({'user': request.user.id})
        elif request.POST.get('type') == 'load_fales':
            Load_1c.objects.filter(user=request.user.id).delete()
            form = Load_1c_forms(request.POST, request.FILES)
            if form.is_valid():
                form.save()
                save_oper_sluch.delay(request.user.id)
                return JsonResponse({'rez': ''}, status=200)


class Create_reestr(View):
    def post(self,request):
        if request.POST.get('type') == 'create_reestr':
            create_reestr.delay(request.user.id,
                                request.POST.get('date_1'),
                                request.POST.get('date_2'),
                                request.POST.get('filename'),
                                None)
        return JsonResponse({'rez': ''})

class reports(View):
    def post(self,request):
        # print(request.POST)
        if self.request.POST.get('task_type') == 'kcc_cb':
            create_mix_reports.delay(
                request.user.id,
                request.POST
            )
        elif self.request.POST.get('task_type') == 'reports':
            create_reference_reports.delay(
                request.user.id,
                request.POST
            )
        elif self.request.POST.get('task_type') == 'annual':
            print('annual_annual')
            create_annual_reports.delay(
                request.user.id,
                request.POST
            )
        return JsonResponse({'rez':True})

class search(View):
    def get(self, request):
        return render(request, 'search_history.html')

    def post(self, request):
        if request.POST.get('type') == 'search':
            history_list = Search_history(request.POST.get('history'), request.user.id)
            rez = history_list.get_history()
            return JsonResponse({'rez': rez})
        elif request.POST.get('type') == 'data_history':
            pk = request.POST.get('id')
            h = History(pk)
            rez = h.get_History_data()
            return JsonResponse({'rez': rez})
        elif request.POST.get('type') == 'save':
            save = Save(request=request)
            save.save()
            return JsonResponse({'rez':''})
