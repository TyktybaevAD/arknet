$(function(){
    $(".date").mask("99-99-9999")
    $(".tm").mask("99:99")
    $(".ss").mask("999-999-999 99")
    $(".vec").mask("9999")
  });

// $(function(){
//     $("#v_datp").change(function(){
//         history_obj.modal_history.$data.v_datp = $("#v_datp").val()
//     })

//     $("#v_tm_otd").change(function(){
//           history_obj.modal_history.$data.v_tm_otd = $("#v_tm_otd").val()
//     })
    
//     $("#v_datv").change(function(){
//         history_obj.modal_history.$data.v_datv = $("#v_datv").val()
//     })

//     $("#v_datr").change(function(){
//         history_obj.modal_history.$data.v_datr = $("#v_datr").val()
//     })

//     $("#v_npr_date").change(function(){
//         history_obj.modal_history.$data.v_npr_date = $("#v_npr_date").val()
//     })
//     $("#v_dat_otd").change(function(){
//         history_obj.modal_history.$data.v_dat_otd = $("#v_dat_otd").val()
//     })
//     // $("#v_tm_otd_2").change(function(){
//     //     history_obj.modal_history.$data.v_tm_otd = $("#v_tm_otd_2").val()
//     // })

//     $("#v_dat_pe").change(function(){
//         history_obj.modal_history.$data.v_dat_pe = $("#v_dat_pe").val()
//     })


//     $("#v_tm_let").change(function(){
//         history_obj.modal_history.$data.v_tm_let = $("#v_tm_let").val()
//     })

//     $("#v_docdate").change(function(){
//         history_obj.modal_history.$data.v_docdate = $("#v_docdate").val()
//     })
    
//     $("#v_vb_a_datv").change(function(){
//         history_obj.modal_history.$data.v_vb_a_datv = $("#v_vb_a_datv").val()
//     })

//     $("#v_dat_l1").change(function(){
//         history_obj.modal_history.$data.v_dat_l1 = $("#v_dat_l1").val()
//     })
    
//     $("#v_dat_l2").change(function(){
//         history_obj.modal_history.$data.v_dat_l2 = $("#v_dat_l2").val()
//     })
 
//     $("#v_diag_date").change(function(){
//         history_obj.modal_history.$data.v_diag_date = $("#v_diag_date").val()
//     })

//     $("#v_dt_cons").change(function(){
//         history_obj.modal_history.$data.v_dt_cons = $("#v_dt_cons").val()
//     })
    
//     $("#v_d_prot").change(function(){
//         history_obj.modal_history.$data.v_d_prot = $("#v_d_prot").val()
//     })
//     $("#v_naprdate").change(function(){
//         history_obj.modal_history.$data.v_naprdate = $("#v_naprdate").val()
//     })
    
//     $("#v_mp_roj").change(function(){
//         history_obj.modal_history.$data.v_mp_roj = $("#v_mp_roj").val()
//     })
//     $("#v_tm_otd_d").change(function(){
//         history_obj.modal_history.$data.v_tm_otd_d = $("#v_tm_otd_d").val()
//     })
//     $("#v_ss").change(function(){
//         history_obj.modal_history.$data.v_ss = $("#v_ss").val()
//     })
//     $("#v_vec").change(function(){
//         history_obj.modal_history.$data.v_vec = $("#v_vec").val()
//     })
//     $("#v_wskr_date").change(function(){
//         history_obj.modal_history.$data.v_wskr_date = $("#v_wskr_date").val()
//     })

    
    
    
//   });