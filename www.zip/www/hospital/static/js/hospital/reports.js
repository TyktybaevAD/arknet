
Vue.component('otdel', {
    template: `<div style="display: block;height: 150px;overflow-y: auto;" class="text-center" id="otdel"> 
    <label>Отделения</label>
    <ul>
      <li class="list-group-item" v-for="otde in spravlist.Otde">
        <input type="checkbox" :value="otde['naim']">
        {{otde['naim']}}
      </li>
    </ul>
  </div>`,
    props: ['spravlist']
})

Vue.component('date', {
    template: `<div class="text-center">
        <div><label>за период (дд.мм.гггг)</label></div>
        <label>с</label>
        <input type="date" id="date1">
        <label>по</label>
        <input type="date" id="date2">
        </div>`
})


Vue.component('input_s_po', {
    template: `<div class="text-center">
        <label>с</label>
        <input type="text" id="input_1" style="width:88px">
        <label>по</label>
        <input type="text" id="input_2" style="width:88px">
        </div>`
})
Vue.component('district', {
    template: `<div class="text-center">
                <select class="text-center" style="width: 230px;height: 32px;margin-bottom: 10px;margin-top: 10px;" id="rai">
                <option value="">-----</option>
                <option value="Центральный АО">1.Центральный АО</option>
                <option value="Ленинский АО">2.Ленинский АО</option>
                <option value="Калининский АО">3.Калининский АО</option>
                <option value="Восточный">4.Восточный</option>
                </select>
             </div>`
})

Vue.component('isfin', {
    template: `<div style="display: block;height: 150px;overflow-y: auto;" class="text-center" id="isfin">
    <label>По источникам финансир-я</label>
    <ul>
      <li class="list-group-item" v-for="otde in spravlist.Isfin">
        <input type="checkbox" :value="otde['naim']">
        {{otde['naim']}}
      </li>
    </ul>
  </div>`,
    props: ['spravlist']
})

Vue.component('btn', {
    props: ['btn'],
    template: `<div class="text-center" style="margin-bottom:10px">
    <div>
    <input type="text" value="" id="filename" class="mb-3">
    </div>
    <button v-bind:btn="btn" type="button" id="create_btn_reports" onclick="create_reports(event)" class="btn btn-primary btn-lg" style="padding:0">Создать отчет</button>
    </div>`
})

Vue.component('tit', {
    template: `<div class="text-center" style="margin-top: 10px;">
    {{title}}
  </div>`,
    props: ['title']

})

Vue.component('all_filter', {
    template: `<div id="menu-list">
        <ul id="filters_ul">
          <li class="list-group-item"><input type="checkbox" id="datv_filt">Период выбытия</li>
          <li class="list-group-item"><input type="checkbox" id="datp_filt">Период поступления</li>
          <li class="list-group-item"><input type="checkbox" id="otd_filt">Отделение</li>
          <li class="list-group-item"><input type="checkbox" id="prof_filt">Профиль койки</li>
          <li class="list-group-item"><input type="checkbox" id="fam_filt">Фимилия (начало фамилии)</li>
          <li class="list-group-item"><input type="checkbox" id="im_filt">Имя (начало имени)</li>
          <li class="list-group-item"><input type="checkbox" id="ot_filt">Отчество (начало отчества)</li>
          <li class="list-group-item"><input type="checkbox" id="pol_filt">Пол</li>
          <li class="list-group-item"><input type="checkbox" id="type_lgots_filt">Тип льготы</li>
          <li class="list-group-item"><input type="checkbox" id="in_t_filt">Льгота</li>
          <li class="list-group-item"><input type="checkbox" id="r_n_filt">Социальный статус</li>
          <li class="list-group-item"><input type="checkbox" id="age_group_filt">Возрастная группа</li>
          <li class="list-group-item"><input type="checkbox" id="goc_filt">Форма госпитализации</li>
          <li class="list-group-item"><input type="checkbox" id="prpg_filt">Вид госпитализации</li>
          <li class="list-group-item"><input type="checkbox" id="vrez_filt">Давность заболевания</li>
          <li class="list-group-item"><input type="checkbox" id="dskz_filt">Ds основной с ...по...</li>
          <li class="list-group-item"><input type="checkbox" id="dsc_filt">Ds сопутствующий</li>
          <li class="list-group-item"><input type="checkbox" id="dspat_filt">Ds патологоанатомический</li>
          <li class="list-group-item"><input type="checkbox" id="dson_filt">Ds онкопатологии</li>
          <li class="list-group-item"><input type="checkbox" id="ksg_osn_filt">КСГ основного Ds</li>
          <li class="list-group-item"><input type="checkbox" id="c_oksm_filt">Гражданство</li>
          <li class="list-group-item"><input type="checkbox" id="terr_filt">Территория проживания</li>
          <li class="list-group-item"><input type="checkbox" id="reg_obl_rai_filt">Регион (обл.,р-н)</li>
          <li class="list-group-item"><input type="checkbox" id="rai_in_filt">АО г.Тюмень</li>
          <li class="list-group-item"><input type="checkbox" id="cj_filt">Категория проживания</li>
          <li class="list-group-item"><input type="checkbox" id="lpy_filt">Направившее учреждение</li>
          <li class="list-group-item"><input type="checkbox" id="ctkom_filt">Страховая организация</li>
          <li class="list-group-item"><input type="checkbox" id="vds_filt">Источник покрытия затрат</li>
          <li class="list-group-item"><input type="checkbox" id="icx_filt">Исход лечения</li>
          <li class="list-group-item"><input type="checkbox" id="otdel_let_filt">Отд-е летального исхода</li>
          <li class="list-group-item"><input type="checkbox" id="kod_vra_filt">Лечащий врач</li>
          <li class="list-group-item"><input type="checkbox" id="kod_op_filt">Код операции</li>
          <li class="list-group-item"><input type="checkbox" id="pr_osob_filt">Особенность выполнения операции</li>
          <li class="list-group-item"><input type="checkbox" id="t_trv_filt">Тип травмы</li>
          <li class="list-group-item"><input type="checkbox" id="trav_ns_filt">Тип телесных повреждений</li>
          <li class="list-group-item"><input type="checkbox" id="disability_filt">Наличие закрытого листа нетрудос</li>
          <li class="list-group-item"><input type="checkbox" id="wskr_filt">Тип вскрытия(для умерших)</li>
          <li class="list-group-item"><input type="checkbox" id="rasxp_filt">Расхождение с патанатом.Ds</li>
          <li class="list-group-item"><input type="checkbox" id="srber_filt">Срок беременности с ..по..нед</li>
          <li class="list-group-item"><input type="checkbox" id="potd_filt">Внутрибольничный перевод</li>
          <li class="list-group-item"><input type="checkbox" id="kod_y_filt">Перевод в др. ЛПУ</li>
          <li class="list-group-item"><input type="checkbox" id="dskz_prich_filt">Причина травмы</li>
          <li class="list-group-item"><input type="checkbox" id="pr_per_filt">Причина перевода в др.ЛПУ</li>
          <li class="list-group-item"><input type="checkbox" id="time_minuts_po_filt">Длительность пребывания в ПО (мин)</li>
          <li class="list-group-item"><input type="checkbox" id="stay_in_mo_filt">Пребывание в МО (к-дн)</li>
        </ul>
  </div>`
})

Vue.component('all_input_models', {
    template: `<div id="menu-group">
    <ul id="list_data">
      <li class="list-group-item"><b>Персональные данные</b></li>
      <li class="list-group-item"><input type="checkbox" id="nib">История</li>
      <li class="list-group-item"><input type="checkbox" id="fam">Фимилия</li>
      <li class="list-group-item"><input type="checkbox" id="im">Имя</li>
      <li class="list-group-item"><input type="checkbox" id="ot">Отчество</li>
      <li class="list-group-item"><input type="checkbox" id="pol">Пол</li>
      <li class="list-group-item"><input type="checkbox" id="datp">Дата поступления</li>
      <li class="list-group-item"><input type="checkbox" id="tm_otd">Время</li>
      <li class="list-group-item"><input type="checkbox" id="datv">Дата выписки</li>
      <li class="list-group-item"><input type="checkbox" id="datr">Дата рождения</li>
      <li class="list-group-item"><input type="checkbox" id="otd">Отделение</li>
      <li class="list-group-item"><input type="checkbox" id="m_roj_in">Адрес рождения</li>
      <li class="list-group-item"><input type="checkbox" id="adr_in">Адрес регистрации</li>
      <li class="list-group-item"><input type="checkbox" id="rab">Место работы</li>
      <li class="list-group-item"><input type="checkbox" id="prof">Профессия</li>
      <li class="list-group-item"><input type="checkbox" id="r_n">Социальный статус</li>
      <li class="list-group-item"><input type="checkbox" id="in_t">Категория льготности</li>
      <li class="list-group-item"><input type="checkbox" id="lpy">Кем направлен</li>
      <li class="list-group-item"><input type="checkbox" id="npr_num">№ Направления</li>
      <li class="list-group-item"><input type="checkbox" id="npr_date">Дата направления</li>
      <li class="list-group-item"><input type="checkbox" id="alg">Подозрениена опьянение</li>
      <li class="list-group-item"><input type="checkbox" id="goc">Госпитализация</li>
      <li class="list-group-item"><input type="checkbox" id="prpg">Обращения</li>
      <li class="list-group-item"><input type="checkbox" id="vrez">Давность заболевания</li>
      <li class="list-group-item"><input type="checkbox" id="p_per">Признак поступления</li>
      <li class="list-group-item"><b>Сведения о диагнозах</b></li>
      <li class="list-group-item"><input type="checkbox" id="dsny">Ds направив.учреждения</li>
      <li class="list-group-item"><input type="checkbox" id="ds_0">Ds при поступлении</li>
      <li class="list-group-item"><input type="checkbox" id="dsk">Ds Клинический</li>
      <li class="list-group-item"><input type="checkbox" id="dskz">Ds Клин.заключ</li>
      <li class="list-group-item"><input type="checkbox" id="ds_osl">Ds осложнения</li>
      <li class="list-group-item"><input type="checkbox" id="dsc">Ds сопутствующий</li>
      <li class="list-group-item"><input type="checkbox" id="dson">Ds онкологий</li>
      <li class="list-group-item"><input type="checkbox" id="dat_otd">отметка о дате поступления из приемного отд.</li>
      <li class="list-group-item"><input type="checkbox" id="tm_otd_d">отметка о времени поступления из приемного отд.</li>
      <li class="list-group-item"><input type="checkbox" id="icx">Исход лечения.</li>
      <li class="list-group-item"><input type="checkbox" id="rslt">Результат лечения.</li>
      <li class="list-group-item"><b>Койко-дни</b></li>
      <li class="list-group-item"><input type="checkbox" id="koy_N">Всего койко-дни</li>
      <li class="list-group-item"><input type="checkbox" id="koy_aro">В Аро</li>
      <li class="list-group-item"><input type="checkbox" id="koy_otd">В профильном отделении</li>
      <li class="list-group-item"><input type="checkbox" id="koy_prof_k">Отделение</li>
      <li class="list-group-item"><input type="checkbox" id="koy_kod">Код врача</li>
      <li class="list-group-item"><b>Операции</b></li>
      <li class="list-group-item"><input type="checkbox" id="oper_date">Дата операции</li>
      <li class="list-group-item"><input type="checkbox" id="oper_tm">Время операции</li>
      <li class="list-group-item"><input type="checkbox" id="oper_py">ПО/СТАЦ</li>
      <li class="list-group-item"><input type="checkbox" id="oper_kod_op">Код операции</li>
      <li class="list-group-item"><input type="checkbox" id="oper_goc">ПЛ/ЭК</li>
      <li class="list-group-item"><input type="checkbox" id="oper_kodx">Код хирурга</li>
      <li class="list-group-item"><input type="checkbox" id="oper_pop">Основ.опер?</li>
      <li class="list-group-item"><input type="checkbox" id="oper_pr_osob">Особ-ти операции</li>
      <li class="list-group-item"><input type="checkbox" id="oper_k_mm">К-во.биом</li>
      <li class="list-group-item"><input type="checkbox" id="oper_kodxa">1-Ассистент</li>
      <li class="list-group-item"><input type="checkbox" id="oper_kodxa1">2-Ассистент</li>
      <li class="list-group-item"><input type="checkbox" id="oper_obz">Метод.обез-я</li>
      <li class="list-group-item"><input type="checkbox" id="oper_kodan">Анестезиолог</li>
      <li class="list-group-item"><b>Клинико-стат.гр.заболев-я</b></li>
      <li class="list-group-item"><input type="checkbox" id="ksg_osn">КСГ осн.заболевания</li>
      <li class="list-group-item"><input type="checkbox" id="oopkk">Дополнительный классификатор критерии</li>
      <li class="list-group-item"><input type="checkbox" id="ksg_sop">КСГ сопут.заболевания</li>
      <li class="list-group-item"><input type="checkbox" id="iddoc">Таб.N врача для ОМС</li>
      <li class="list-group-item"><b>Осложнение</b></li>
      <li class="list-group-item"><input type="checkbox" id="oslo_tnvr">Таб.N</li>
      <li class="list-group-item"><input type="checkbox" id="oslo_date">Дата осложнения</li>
      <li class="list-group-item"><input type="checkbox" id="oslo_kod_osl">Код осложнения</li>
      <li class="list-group-item"><input type="checkbox" id="oslo_xosl">Характер осл.</li>
      <li class="list-group-item"><input type="checkbox" id="oslo_posl">Причина</li>
      <li class="list-group-item"><input type="checkbox" id="oslo_aosl">Экспертиза</li>
      <li class="list-group-item"><b>Трудоспособность</b></li>
      <li class="list-group-item"><input type="checkbox" id="trs">Трудоспособность</li>
      <li class="list-group-item"><b>Манипуляция</b></li>
      <li class="list-group-item"><input type="checkbox" id="man_date">Дата манипуляции</li>
      <li class="list-group-item"><input type="checkbox" id="man_tnvr">Таб.N врача</li>
      <li class="list-group-item"><input type="checkbox" id="man_kodmn">Код Манипуляции</li>
      <li class="list-group-item"><input type="checkbox" id="man_kol">К-во</li>
      <li class="list-group-item"><input type="checkbox" id="man_pl">Плат.Услуга?</li>
      <li class="list-group-item"><b>Переводы</b></li>
      <li class="list-group-item"><input type="checkbox" id="potd">Перевод из Отд.</li>
      <li class="list-group-item"><input type="checkbox" id="dat_pe">Дата перевода</li>
      <li class="list-group-item"><input type="checkbox" id="kod_y">Перевод в Др.ЛПУ</li>
      <li class="list-group-item"><input type="checkbox" id="pr_per">Причина перевода</li>
      <li class="list-group-item"><b>Патанатомический Ds</b></li>
      <li class="list-group-item"><input type="checkbox" id="wskr_date">Дата смерти</li>
      <li class="list-group-item"><input type="checkbox" id="tm_let">Время смерти (час.мин)</li>
      <li class="list-group-item"><input type="checkbox" id="pri">Код причины летального исхода</li>
      <li class="list-group-item"><input type="checkbox" id="ds_let_kod">Ds причины летального исхода </li>
      <li class="list-group-item"><input type="checkbox" id="wskr">Вскрытие</li>
      <li class="list-group-item"><input type="checkbox" id="dspat_kod">Ds паталогоанатомический</li>
      <li class="list-group-item"><input type="checkbox" id="rasxp">Расхождение Ds установлено</li>
      <li class="list-group-item"><input type="checkbox" id="otd_y">Умер в</li>
      <li class="list-group-item"><b>Сведения о травмах</b></li>
      <li class="list-group-item"><input type="checkbox" id="dskz_kod">Характер травмы</li>
      <li class="list-group-item"><input type="checkbox" id="details_kod">Внешние причины травмы</li>
      <li class="list-group-item"><input type="checkbox" id="t_trv">Тип травмы</li>
      <li class="list-group-item"><input type="checkbox" id="trav_ns">Травма получена в рез-те противоправных действий третьих лиц</li>
      <li class="list-group-item"><b>Полис/Документ/Снилс</b></li>
      <li class="list-group-item"><input type="checkbox" id="vds">Источник оплаты</li>
      <li class="list-group-item"><input type="checkbox" id="sctp">Сер.полиса</li>
      <li class="list-group-item"><input type="checkbox" id="nctp">N полиса</li>
      <li class="list-group-item"><input type="checkbox" id="ctkom">СМО</li>
      <li class="list-group-item"><input type="checkbox" id="t_pol">Тип полиса</li>
      <li class="list-group-item"><input type="checkbox" id="udl">Тип документа</li>
      <li class="list-group-item"><input type="checkbox" id="s_pasp">Сер.ДУЛ</li>
      <li class="list-group-item"><input type="checkbox" id="n_pasp">N ДУЛ</li>
      <li class="list-group-item"><input type="checkbox" id="docdate">Дата выдачи</li>
      <li class="list-group-item"><input type="checkbox" id="docorg">Кем выдан</li>
      <li class="list-group-item"><input type="checkbox" id="m_roj">Место рождения</li>
      <li class="list-group-item"><input type="checkbox" id="ss">Снилс</li>
      <li class="list-group-item"><b>Сведения о беременности</b></li>
      <li class="list-group-item"><input type="checkbox" id="vb_a_datv">Дата</li>
      <li class="list-group-item"><input type="checkbox" id="srber">Срок беременности (недель)</li>
      <li class="list-group-item"><input type="checkbox" id="n_ber">Настоящая беременность по счету</li>
      <li class="list-group-item"><input type="checkbox" id="pria">Причины прерывания беременности</li>
      <li class="list-group-item"><input type="checkbox" id="m_prer">Метод прерывания беременности</li>
      <li class="list-group-item"><b>Лист нетрудоспособности</b></li>
      <li class="list-group-item"><input type="checkbox" id="dat_l1">Открыт с</li>
      <li class="list-group-item"><input type="checkbox" id="dat_l2">Закрыт по</li>
      <li class="list-group-item"><input type="checkbox" id="ot_ln">Закрыт</li>
      <li class="list-group-item"><input type="checkbox" id="vs_bol">Полных лет</li>
      <li class="list-group-item"><input type="checkbox" id="dis_sex_bol">Пол</li>
      <li class="list-group-item"><b>Представитель пациента</b></li>
      <li class="list-group-item"><input type="checkbox" id="fam_p">Фимилия</li>
      <li class="list-group-item"><input type="checkbox" id="im_p">Имя</li>
      <li class="list-group-item"><input type="checkbox" id="ot_p">Отчество</li>
      <li class="list-group-item"><input type="checkbox" id="pol_p">Пол</li>
      <li class="list-group-item"><input type="checkbox" id="mp_roj">Место рождения</li>
      <li class="list-group-item"><input type="checkbox" id="udl_p">Тип документа</li>
      <li class="list-group-item"><input type="checkbox" id="sp_pasp">Серия</li>
      <li class="list-group-item"><input type="checkbox" id="np_pasp">Номер</li>
      <li class="list-group-item"><input type="checkbox" id="skom_p">СМО</li>
      <li class="list-group-item"><input type="checkbox" id="stat_p">Тип полиса</li>
      <li class="list-group-item"><input type="checkbox" id="s_pol">Сер.полиса</li>
      <li class="list-group-item"><input type="checkbox" id="n_pol">N.полиса</li>
      <li class="list-group-item"><b>Карта онкобольного</b></li>
      <li class="list-group-item"><input type="checkbox" id="ds1_t">Повод обращения</li>
      <li class="list-group-item"><input type="checkbox" id="stad">Стадия заболевания</li>
      <li class="list-group-item"><input type="checkbox" id="onk_t">Стадия по T</li>
      <li class="list-group-item"><input type="checkbox" id="onk_n">Стадия по N</li>
      <li class="list-group-item"><input type="checkbox" id="onk_m">Стадия по M</li>
      <li class="list-group-item"><input type="checkbox" id="mtstz">Наличие отдельных метастазов</li>
      <li class="list-group-item"><input type="checkbox" id="c_zab">Характер заболевания</li>
      <li class="list-group-item"><b>Сведения о диагностике</b></li>
      <li class="list-group-item"><input type="checkbox" id="diag_date">Дата взятия материала</li>
      <li class="list-group-item"><input type="checkbox" id="diag_tip">Тип диагностического показателя</li>
      <li class="list-group-item"><input type="checkbox" id="diag_code">Код диагностического показателя</li>
      <li class="list-group-item"><input type="checkbox" id="diag_rslt">Код результата диагностики</li>
      <li class="list-group-item"><input type="checkbox" id="rec_rslt">Признак получения результата диагностики</li>
      <li class="list-group-item"><b>Сведения о проведении консилиума</b></li>
      <li class="list-group-item"><input type="checkbox" id="dt_cons">Дата консилиума</li>
      <li class="list-group-item"><input type="checkbox" id="pr_cons">Цель консилиума</li>
      <li class="list-group-item"><b>Сведения об услуге лечения</b></li>
      <li class="list-group-item"><input type="checkbox" id="usl_tip">Тип услуги</li>
      <li class="list-group-item"><input type="checkbox" id="hir_tip">Тип хирургического лечения</li>
      <li class="list-group-item"><b>Сведения о противопоказаниях и отказах</b></li>
      <li class="list-group-item"><input type="checkbox" id="d_prot">Дата регистрации</li>
      <li class="list-group-item"><input type="checkbox" id="prot">противопоказания и отказы</li>
      <li class="list-group-item"><b>Сведения о направлений в МО (из выписного эпикриза)</b></li>
      <li class="list-group-item"><input type="checkbox" id="naprdate">Дата направления</li>
      <li class="list-group-item"><input type="checkbox" id="napr_v">Вид направления</li>
      <li class="list-group-item"><input type="checkbox" id="napr_mo">Мо,куда рекомендовано обращаться</li>
      <li class="list-group-item"><input type="checkbox" id="napr_issl">Метод диагностич.исследования</li>
      <li class="list-group-item"><input type="checkbox" id="napr_usl">Мед.услуга(код) рекомендованная</li>
      <li class="list-group-item"><b>Мо прикрепления</b></li>
      <li class="list-group-item"><input type="checkbox" id="pmg">Мо прикрепления</li>
    </ul>
  </div>`
})


Vue.component('input_select', {
    template: `<div>
    <input type="text" v-bind:list="ll" v-bind:id="id" style="margin-bottom: 10px;" class="text-center">
    <datalist v-bind:id="ll">
    <option v-for="s in spravlist">{{s[k]}}</option>
    </datalist>
    </div>`,
    props: ['spravlist', 'k', 'll', 'id']

})

// Vue.component('input_select', {
//     template: `<div>
//     <input type="text" v-bind:list="ll" style="margin-bottom: 10px;" class="text-center">
//     <datalist v-bind:id="ll">
//     <option v-for="s in spravlist">{{s[k]}}<option>
//     </datalist>
//     </div>`,
//     props: ['spravlist','k','ll']

// })

let report_oth = new Vue({

    el: '#report_oth',
    data: {
        lists_references: false,
        annual_reports: false,
        menu_list: false,
        menu_group: false,
        menu_annual: false,
        menu_reports: false,
        report_generation: false,

        //Справочники
        sprav_list: [],
        otdel: false,

        //Отчеты


        g_tip_ot_3_2_v: false,
        gla_vra: false,
        isfin_l: false,


        a_oth_1: false,
        a_oth_2: false,
        a_oth_3: false,
        a_oth_4: false,
        a_oth_5: false,
        a_oth_6: false,
        a_oth_7: false,
        a_oth_8: false,
        a_oth_9: false,
        a_oth_10: false,
        a_oth_11: false,
        a_oth_12: false,
        a_oth_13: false,
        a_oth_14: false,
        a_oth_15: false,
        a_oth_16: false,
        a_oth_17: false,
        a_oth_18: false,
        a_oth_19: false,
        a_oth_20: false,
        a_oth_21: false,
        a_oth_22: false,
        a_oth_23: false,
        a_oth_24: false,
        a_oth_25: false,
        a_oth_26: false,
        a_oth_27: false,
        a_oth_28: false,
        a_oth_29: false,
        a_oth_30: false,
        a_oth_31: false,
        a_oth_32: false,
        a_oth_33: false,



        a_oth_2_select_2_f: false,

        statistics_reports: false,
        departments_reports: false,
        vra_reports: false,
        vault_otd_reports: false,

        statistics_rep_oth_13_1: false,
        statistics_rep_oth_14_1: false,
        statistics_rep_oth_14_2: false,
        statistics_rep_oth_14_3: false,
        statistics_rep_oth_14_4: false,
        statistics_rep_oth_30_1: false,
        statistics_rep_oth_30_2: false,
        statistics_rep_oth_30_3: false,
        statistics_rep_oth_16_1: false,
        statistics_rep_oth_57_1: false,
        statistics_rep_oth_1_1: false,
        statistics_rep_oth_1_2: false,
        statistics_rep_oth_1_3: false,
        statistics_rep_oth_1_4: false,
        statistics_rep_oth_1_5: false,
        statistics_rep_oth_1_6: false,
        statistics_rep_oth_1_7: false,
        statistics_rep_oth_1_8: false,
        statistics_rep_oth_1_9: false,
        statistics_rep_oth_1_а: false,
        statistics_rep_oth_1_б: false,
        statistics_rep_oth_1_в: false,
        statistics_rep_oth_1_г: false,
        statistics_rep_oth_1_д: false,


        shaping: false,
        create: false,
    },
    mounted: function () {
        this.get_sprav_list()
    },
    methods: {
        get_sprav_list: function () {
            let query = `
       query{
           Otde{
             naim
           },
           Isfin{
            naim
           },
           V020{
            kPrname
          },
          V005{
            polname
          },
          T004{
            name
          },
          RabNer{
            naim
          },
          AgeGroup{
            name
          },
          V014{
            tipName
          },
          Prpg{
            naim
          },
          Vrzb{
            naim
          },
          Oksm{
            naim
           },
           F003{
            naim
          },
          Skom{
            naim
         },
         Isfin{
            naim
         },
         V012{
            idIz
            izName
           },
           Vra{
            kod
          },
          V001{
            kod
         },
         PROsob{
            kod
            naim
        },
        Trv{
            naim
         },
         Trvnas{
            naim
         },
         AbObsh{
                kod
              }
       }`
            return fetch('graph_hospital/', {
                method: 'post',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ query })
            })
                .then(response => response.json())
                .then(data => {
                    this.sprav_list = data.data
                })
                .catch((e) => {
                    // console.log(e)
                })
        },
        init: function () {
            this.lists_references = false
            this.annual_reports = false
            this.menu_list = false
            this.menu_group = false
            this.menu_annual = false
            this.menu_reports = false
            this.report_generation = false

        },
        init_oth: function () {
            this.otdel = false

            this.a_oth_1 = false
            this.a_oth_2 = false
            this.a_oth_3 = false
            this.a_oth_4 = false
            this.a_oth_5 = false
            this.a_oth_6 = false
            this.a_oth_7 = false
            this.a_oth_8 = false
            this.a_oth_9 = false
            this.a_oth_10 = false
            this.a_oth_11 = false
            this.a_oth_12 = false
            this.a_oth_13 = false
            this.a_oth_14 = false
            this.a_oth_15 = false
            this.a_oth_16 = false
            this.a_oth_17 = false
            this.a_oth_18 = false
            this.a_oth_19 = false
            this.a_oth_20 = false
            this.a_oth_21 = false
            this.a_oth_22 = false
            this.a_oth_23 = false
            this.a_oth_24 = false
            this.a_oth_25 = false
            this.a_oth_26 = false
            this.a_oth_27 = false
            this.a_oth_28 = false
            this.a_oth_29 = false
            this.a_oth_30 = false
            this.a_oth_31 = false
            this.a_oth_32 = false
            this.a_oth_33 = false


            this.statistics_reports = false
            this.departments_reports = false
            this.vra_reports = false
            this.vault_otd_reports = false

            this.statistics_rep_oth_1 = false
            this.statistics_rep_oth_2 = false
            this.statistics_rep_oth_3 = false
            this.statistics_rep_oth_4 = false
            this.statistics_rep_oth_5 = false
            this.statistics_rep_oth_6 = false
            this.statistics_rep_oth_7 = false
            this.statistics_rep_oth_8 = false
            this.statistics_rep_oth_9 = false
            this.statistics_rep_oth_10 = false

            this.shaping = false
            this.create = false

            let date_1 = document.getElementById("date1")
            let date_2 = document.getElementById("date2")
            let filename = document.getElementById("filename")

            if (date_1 != null) { date_1.value = '' }
            if (date_2 != null) { date_2.value = '' }
            if (filename != null) { filename.value = '' }

        },
        references: function () {
            this.init()
            this.init_oth()
            this.statistics_r_oth_init()
            this.lists_references = !this.lists_references
            this.annual_reports = false
            this.menu_reports = false
            this.menu_group = false
            this.menu_annual = false


        },
        reports: function () {
            this.init()
            this.init_oth()
            this.statistics_r_oth_init()

            this.annual_reports = !this.annual_reports
            this.lists_references = false
            this.menu_group = false
            this.menu_annual = false
            this.report_generation = false
            this.menu_reports = false

        },
        group: function () {
            this.init_oth()
            this.menu_group = !this.menu_group
            this.menu_annual = false

            setTimeout(() => {
                all_filters()
            }, 300)
        },
        annual: function () {
            this.init_oth()
            this.menu_annual = !this.menu_annual
            this.menu_group = false
        },
        generation: function () {
            this.init_oth()
            this.report_generation = !this.report_generation
            this.menu_reports = false
        },
        reports_menu: function () {
            this.menu_reports = !this.menu_reports
            this.report_generation = false
        },

        group_oth_1: function () {
            this.init_oth()
            this.g_oth_1 = true
        },
        group_oth_2: function () {
            this.init_oth()
            this.g_oth_2 = true
            setTimeout(() => {
                all_filters()
            }, 300);
        },
        group_oth_3: function () {
            this.init_oth()
            this.g_oth_3 = true
        },
        group_oth_4: function () {
            this.init_oth()
            this.g_oth_4 = true
            setTimeout(() => {
                all_filters()
            }, 300);
        },
        group_oth_5: function () {
            this.init_oth()
            this.g_oth_5 = true
        },
        group_oth_6: function () {
            this.init_oth()
            this.g_oth_6 = true
        },
        group_oth_7: function () {
            this.init_oth()
            this.g_oth_7 = true
        },
        group_oth_8: function () {
            this.init_oth()
            this.g_oth_8 = true
        },
        group_oth_9: function () {
            this.init_oth()
            this.g_oth_9 = true
        },
        group_oth_10: function () {
            this.init_oth()
            this.g_oth_10 = true
        },
        group_oth_11: function () {
            this.init_oth()
            this.g_oth_11 = true
        },
        group_oth_12: function () {
            this.init_oth()
            this.g_oth_12 = true
        },
        group_oth_13: function () {
            this.init_oth()
            this.g_oth_13 = true
        },
        group_oth_14: function () {
            this.init_oth()
            this.g_oth_14 = true
        },
        group_oth_15: function () {
            this.init_oth()
            this.g_oth_15 = true
        },
        group_oth_16: function () {
            this.init_oth()
            this.g_oth_16 = true
        },
        group_oth_17: function () {
            this.init_oth()
            this.g_oth_17 = true
        },
        group_oth_1: function () {
            this.init_oth()
            this.g_oth_1 = true
        },
        group_oth_18: function () {
            this.init_oth()
            this.g_oth_18 = true
        },
        group_oth_19: function () {
            this.init_oth()
            this.g_oth_19 = true
        },
        group_oth_20: function () {
            this.init_oth()
            this.g_oth_20 = true
        },
        group_oth_21: function () {
            this.init_oth()
            this.g_oth_21 = true
        },
        group_oth_22: function () {
            this.init_oth()
            this.g_oth_22 = true
        },
        group_oth_23: function () {
            this.init_oth()
            this.g_oth_23 = true
        },
        group_oth_24: function () {
            this.init_oth()
            this.g_oth_24 = true
        },
        group_oth_25: function () {
            this.init_oth()
            this.g_oth_25 = true
        },


        annual_oth_1: function () {
            this.init_oth()
            this.a_oth_1 = true
        },
        annual_oth_2: function () {
            this.init_oth()
            this.a_oth_2 = true
        },
        annual_oth_3: function () {
            this.init_oth()
            this.a_oth_3 = true
        },
        annual_oth_4: function () {
            this.init_oth()
            this.a_oth_4 = true
        },
        annual_oth_5: function () {
            this.init_oth()
            this.a_oth_5 = true
            setTimeout(() => {
                all_filters()
            }, 300)
        },
        annual_oth_6: function () {
            this.init_oth()
            this.a_oth_6 = true
        },
        annual_oth_7: function () {
            this.init_oth()
            this.a_oth_7 = true
        },
        annual_oth_8: function () {
            this.init_oth()
            this.a_oth_8 = true
        },
        annual_oth_9: function () {
            this.init_oth()
            this.a_oth_9 = true
        },
        annual_oth_10: function () {
            this.init_oth()
            this.a_oth_10 = true
        },
        annual_oth_11: function () {
            this.init_oth()
            this.a_oth_11 = true
        },
        annual_oth_12: function () {
            this.init_oth()
            this.a_oth_12 = true
        },
        annual_oth_13: function () {
            this.init_oth()
            this.a_oth_13 = true
        },
        annual_oth_14: function () {
            this.init_oth()
            this.a_oth_14 = true
        },
        annual_oth_15: function () {
            this.init_oth()
            this.a_oth_15 = true
        },
        annual_oth_16: function () {
            this.init_oth()
            this.a_oth_16 = true
        },
        annual_oth_17: function () {
            this.init_oth()
            this.a_oth_17 = true
        },
        annual_oth_18: function () {
            this.init_oth()
            this.a_oth_18 = true
        },
        annual_oth_19: function () {
            this.init_oth()
            this.a_oth_19 = true
        },
        annual_oth_20: function () {
            this.init_oth()
            this.a_oth_20 = true
        },
        annual_oth_21: function () {
            this.init_oth()
            this.a_oth_21 = true
        },
        annual_oth_22: function () {
            this.init_oth()
            this.a_oth_22 = true
        },
        annual_oth_23: function () {
            this.init_oth()
            this.a_oth_23 = true
        },
        annual_oth_24: function () {
            this.init_oth()
            this.a_oth_24 = true
        },
        annual_oth_25: function () {
            this.init_oth()
            this.a_oth_25 = true
        },
        annual_oth_26: function () {
            this.init_oth()
            this.a_oth_26 = true
        },
        annual_oth_27: function () {
            this.init_oth()
            this.a_oth_27 = true
        },
        annual_oth_28: function () {
            this.init_oth()
            this.a_oth_28 = true
        },
        annual_oth_29: function () {
            this.init_oth()
            this.a_oth_29 = true
        },
        annual_oth_30: function () {
            this.init_oth()
            this.a_oth_30 = true
        },
        annual_oth_31: function () {
            this.init_oth()
            this.a_oth_31 = true
        },
        annual_oth_32: function () {
            this.init_oth()
            this.a_oth_32 = true
        },
        annual_oth_33: function () {
            this.init_oth()
            this.a_oth_33 = true
        },
        statistics_rep: function () {
            this.init_oth()
            this.statistics_reports = !this.statistics_reports


            // setTimeout(() => {
            //     let panel_13 = document.getElementById("panel_13")
            
            //     panel_13.onclick = function(){
            //        let menu = document.getElementById("panel-13-menu")
            //        if (menu.classList.contains('show')){
            //            document.getElementById("13-menu").click()
            //        }
            //     }
            // }, 300)
           
            
        },
        departments_rep: function () {
            this.init_oth()
            this.departments_reports = !this.departments_reports
        },
        vra_rep: function () {
            this.init_oth()
            this.vra_reports = !this.vra_reports
        },
        vault_otd_rep: function () {
            this.init_oth()
            this.vault_otd_reports = !this.vault_otd_reports
        },
        statistics_r_oth_init: function () {
            this.statistics_rep_oth_13_1 = false
            this.statistics_rep_oth_14_1 = false
            this.statistics_rep_oth_14_2 = false
            this.statistics_rep_oth_14_3 = false
            this.statistics_rep_oth_14_4 = false
            this.statistics_rep_oth_30_1 = false
            this.statistics_rep_oth_30_2 = false
            this.statistics_rep_oth_30_3 = false
            this.statistics_rep_oth_16_1 = false
            this.statistics_rep_oth_57_1 = false
            this.statistics_rep_oth_1_1 = false
            this.statistics_rep_oth_1_2 = false
            this.statistics_rep_oth_1_3 = false
            this.statistics_rep_oth_1_4 = false
            this.statistics_rep_oth_1_5 = false
            this.statistics_rep_oth_1_6 = false
            this.statistics_rep_oth_1_7 = false
            this.statistics_rep_oth_1_8 = false
            this.statistics_rep_oth_1_9 = false
            this.statistics_rep_oth_1_а = false
            this.statistics_rep_oth_1_б = false
            this.statistics_rep_oth_1_в = false
            this.statistics_rep_oth_1_г = false
            this.statistics_rep_oth_1_д = false
        },
        statistics_r_oth_13_1: function () {
            this.statistics_r_oth_init()
            this.statistics_rep_oth_13_1 = !this.statistics_rep_oth_13_1
        },
        statistics_r_oth_14_1: function () {
            this.statistics_r_oth_init()
            this.statistics_rep_oth_14_1 = !this.statistics_rep_oth_14_1
        },
        statistics_r_oth_14_2: function () {
            this.statistics_r_oth_init()
            this.statistics_rep_oth_14_2 = !this.statistics_rep_oth_14_2
        },
        statistics_r_oth_14_3: function () {
            this.statistics_r_oth_init()
            this.statistics_rep_oth_14_3 = !this.statistics_rep_oth_14_3
        },
        statistics_r_oth_14_4: function () {
            this.statistics_r_oth_init()
            this.statistics_rep_oth_14_4 = !this.statistics_rep_oth_14_4
        },
        statistics_r_oth_30_1: function () {
            this.statistics_r_oth_init()
            this.statistics_rep_oth_30_1 = !this.statistics_rep_oth_30_1
        },
        statistics_r_oth_30_2: function () {
            this.statistics_r_oth_init()
            this.statistics_rep_oth_30_2 = !this.statistics_rep_oth_30_2
        },
        statistics_r_oth_33_3: function () {
            this.statistics_r_oth_init()
            this.statistics_rep_oth_33_3 = !this.statistics_rep_oth_33_3
        },
        statistics_r_oth_16_1: function () {
            this.statistics_r_oth_init()
            this.statistics_rep_oth_16_1 = !this.statistics_rep_oth_16_1
        },
        statistics_r_oth_57_1: function () {
            this.statistics_r_oth_init()
            this.statistics_rep_oth_57_1 = !this.statistics_rep_oth_57_1
        },
        statistics_r_oth_1_1: function () {
            this.statistics_r_oth_init()
            this.statistics_rep_oth_1_1 = !this.statistics_rep_oth_1_1
        },
        statistics_r_oth_1_2: function () {
            this.statistics_r_oth_init()
            this.statistics_rep_oth_1_2 = !this.statistics_rep_oth_1_2
        },
        statistics_r_oth_1_3: function () {
            this.statistics_r_oth_init()
            this.statistics_rep_oth_1_3 = !this.statistics_rep_oth_1_3
        },
        statistics_r_oth_1_4: function () {
            this.statistics_r_oth_init()
            this.statistics_rep_oth_1_4 = !this.statistics_rep_oth_1_4
        },
        statistics_r_oth_1_5: function () {
            this.statistics_r_oth_init()
            this.statistics_rep_oth_1_5 = !this.statistics_rep_oth_1_5
        },
        statistics_r_oth_1_6: function () {
            this.statistics_r_oth_init()
            this.statistics_rep_oth_1_6 = !this.statistics_rep_oth_1_6
        },
        statistics_r_oth_1_7: function () {
            this.statistics_r_oth_init()
            this.statistics_rep_oth_1_7 = !this.statistics_rep_oth_1_7
        },
        statistics_r_oth_1_8: function () {
            this.statistics_r_oth_init()
            this.statistics_rep_oth_1_8 = !this.statistics_rep_oth_1_8
        },
        statistics_r_oth_1_9: function () {
            this.statistics_r_oth_init()
            this.statistics_rep_oth_1_9 = !this.statistics_rep_oth_1_9
        },
        statistics_r_oth_1_а: function () {
            this.statistics_r_oth_init()
            this.statistics_rep_oth_1_а = !this.statistics_rep_oth_1_а
        },
        statistics_r_oth_1_б: function () {
            this.statistics_r_oth_init()
            this.statistics_rep_oth_1_б = !this.statistics_rep_oth_1_б
        },
        statistics_r_oth_1_в: function () {
            this.statistics_r_oth_init()
            this.statistics_rep_oth_1_в = !this.statistics_rep_oth_1_в
        },
        statistics_r_oth_1_г: function () {
            this.statistics_r_oth_init()
            this.statistics_rep_oth_1_г = !this.statistics_rep_oth_1_г
        },
        statistics_r_oth_1_д: function () {
            this.statistics_r_oth_init()
            this.statistics_rep_oth_1_д = !this.statistics_rep_oth_1_д
        },


    }

})


function init() {
    report_oth.init()
    report_oth.init_oth()
}

function onchange_g_select_tip_ot_1(event) {
    if (event.target.value == 'по отделению') {
        report_oth.$data.otdel = true
    }
    else {
        report_oth.$data.otdel = false
    }

    if (event.target.value == 'Для зам.гл.врача') {
        report_oth.$data.gla_vra = true
    }
    else {
        report_oth.$data.gla_vra = false
    }
}

function onchange_g_select_tip_ot_3_1(event) {
    if (event.target.value == 'по подразделениям ЛУ') {
        report_oth.$data.g_tip_ot_3_2_v = true
    }
    else {
        report_oth.$data.g_tip_ot_3_2_v = false
    }
}

function onchange_g_isfin(event) {
    if (event.target.value == 'по источникам финансир-я') {
        report_oth.$data.isfin_l = true
    }
    else {
        report_oth.$data.isfin_l = false
    }
}


function onchange_a_oth_2_select_1(event) {
    if (event.target.value == 'По территор.признаку') {
        report_oth.$data.a_oth_2_select_2_f = true
    }
    else {
        report_oth.$data.a_oth_2_select_2_f = false
    }
}

function all_filters() {
    let list_li = document.getElementById("filters_ul").querySelectorAll('li')
    let filters = document.getElementById("filters")
    let type_lgots = ['Территориальная', 'Федеральная']
    for (let li of list_li) {
        li.firstChild.addEventListener("click", function () {
            let div_block = document.createElement("div")
            div_block.setAttribute("id", this.id + "_block")
            let lab = document.createElement("label")
            lab.innerHTML = this.nextSibling.data
            lab.setAttribute("style", "display:block")
            div_block.appendChild(lab)
            if (this.id == 'datv_filt' || this.id == 'datp_filt' || this.id == 'datv_datp_filt') {
                let dat_1 = document.createElement("input")
                dat_1.setAttribute("type", "date")
                let dat_2 = document.createElement("input")
                dat_2.setAttribute("type", "date")
                let lab_1 = document.createElement("label")
                lab_1.innerHTML = 'C'
                let lab_2 = document.createElement("label")
                lab_2.innerHTML = 'по'
                div_block.appendChild(lab_1)
                div_block.appendChild(dat_1)
                div_block.appendChild(lab_2)
                div_block.appendChild(dat_2)
            }
            else if (this.id == 'otd_filt' || this.id == 'prof_filt' || this.id == 'pol_filt' || this.id == 'type_lgots_filt'
                || this.id == 'in_t_filt' || this.id == 'r_n_filt' || this.id == 'age_group_filt' || this.id == 'goc_filt'
                || this.id == 'prpg_filt' || this.id == 'vrez_filt' || this.id == 'c_oksm_filt' || this.id == 'terr_filt'
                || this.id == 'rai_in_filt' || this.id == 'cj_filt' || this.id == 'lpy_filt' || this.id == 'ctkom_filt'
                || this.id == 'vds_filt' || this.id == 'icx_filt' || this.id == 'otdel_let_filt' || this.id == 'kod_vra_filt'
                || this.id == 'kod_op_filt' || this.id == 'pr_osob_filt' || this.id == 't_trv_filt' || this.id == 'trav_ns_filt'
                || this.id == 'wskr_filt' || this.id == 'rasxp_filt' || this.id == 'potd_filt' || this.id == 'kod_y_filt'
                || this.id == 'pr_per_filt') {

                if (this.id == 'otd_filt' || this.id == 'potd_filt') {
                    var list = report_oth.$data.sprav_list.Otde
                }
                else if (this.id == 'prof_filt') {
                    var list = report_oth.$data.sprav_list.V020
                }
                else if (this.id == 'pol_filt') {
                    var list = report_oth.$data.sprav_list.V005
                }
                else if (this.id == 'type_lgots_filt') {
                    var list = type_lgots
                }
                else if (this.id == 'in_t_filt') {
                    var list = report_oth.$data.sprav_list.T004
                }
                else if (this.id == 'r_n_filt') {
                    var list = report_oth.$data.sprav_list.RabNer
                }
                else if (this.id == 'age_group_filt') {
                    var list = report_oth.$data.sprav_list.AgeGroup
                }
                else if (this.id == 'goc_filt') {
                    var list = report_oth.$data.sprav_list.V014
                }
                else if (this.id == 'prpg_filt') {
                    var list = report_oth.$data.sprav_list.Prpg
                }
                else if (this.id == 'vrez_filt') {
                    var list = report_oth.$data.sprav_list.Vrzb
                }
                else if (this.id == 'c_oksm_filt') {
                    var list = report_oth.$data.sprav_list.Oksm
                }
                else if (this.id == 'terr_filt') {
                    var list = ['г.Тюменю', 'Юг Тюм.обл.кроме Тюм.р-н', 'Тюменский р-н', 'Ханты-Мансйский АО',
                        'Ямало-Немецкий АО', 'Др.регионы Россий', 'Др. государства']
                }
                else if (this.id == 'rai_in_filt') {
                    var list = ['Центральный АО', 'Ленинский АО', 'Калининский АО', 'Восточный АО']
                }
                else if (this.id == 'cj_filt') {
                    var list = ['Городской', 'Сельский']
                }
                else if (this.id == 'lpy_filt' || this.id == 'kod_y_filt') {
                    var list = report_oth.$data.sprav_list.F003
                }
                else if (this.id == 'ctkom_filt') {
                    var list = report_oth.$data.sprav_list.Skom
                }
                else if (this.id == 'vds_filt') {
                    var list = report_oth.$data.sprav_list.Isfin
                }
                else if (this.id == 'icx_filt') {
                    var list = report_oth.$data.sprav_list.V012
                }
                else if (this.id == 'otdel_let_filt') {
                    var list = ['ПРИЕМНОЕ', 'АРО N1', 'АРО 2 ИНТЕН.НЕВРОЛОГ', 'АРО N3 (ЛДО)']
                }
                else if (this.id == 'kod_vra_filt') {
                    var list = report_oth.$data.sprav_list.Vra
                }
                else if (this.id == 'kod_op_filt') {
                    var list = report_oth.$data.sprav_list.V001
                }
                else if (this.id == 'pr_osob_filt') {
                    var list = report_oth.$data.sprav_list.PROsob
                }
                else if (this.id == 't_trv_filt') {
                    var list = report_oth.$data.sprav_list.Trv
                }

                else if (this.id == 'trav_ns_filt') {
                    var list = report_oth.$data.sprav_list.Trvnas
                }

                else if (this.id == 'wskr_filt') {
                    var list = ['без вскрытия', 'патологоанатом.', 'судебное']
                }
                else if (this.id == 'rasxp_filt') {
                    var list = ['да', 'нет']
                }

                else if (this.id == 'pr_per_filt') {
                    var list = ['для оказания специализированной мед.помощи', 'для прохождения реабилитации', 'для следующего этапа лечения']
                }



                let inp = document.createElement("input")
                inp.setAttribute("list", this.id + "_l")
                let datalist = document.createElement("datalist")
                datalist.setAttribute("id", this.id + "_l")

                for (o of list) {
                    var op = document.createElement("option")
                    if (this.id == 'otd_filt' || this.id == 'r_n_filt' || this.id == 'prpg_filt'
                        || this.id == 'vrez_filt' || this.id == 'c_oksm_filt' || this.id == 'lpy_filt'
                        || this.id == 'ctkom_filt' || this.id == 'vds_filt' || this.id == 'pr_osob_filt'
                        || this.id == 't_trv_filt' || this.id == 'trav_ns_filt' || this.id == 'potd_filt'
                        || this.id == 'kod_y_filt') {
                        op.value = o.naim
                        op.innerText = o.naim
                    }
                    else if (this.id == 'prof_filt') {
                        op.value = o.kPrname
                        op.innerText = o.kPrname
                    }
                    else if (this.id == 'pol_filt') {
                        op.value = o.polname
                        op.innerText = o.polname
                    }
                    else if (this.id == 'type_lgots_filt' || this.id == 'terr_filt' || this.id == 'rai_in_filt'
                        || this.id == 'cj_filt' || this.id == 'otdel_let_filt' || this.id == 'wskr_filt'
                        || this.id == 'rasxp_filt' || this.id == 'pr_per_filt') {
                        op.value = o
                        op.innerText = o
                    }
                    else if (this.id == 'in_t_filt' || this.id == 'age_group_filt') {
                        op.value = o.name
                        op.innerText = o.name
                    }
                    else if (this.id == 'goc_filt') {
                        op.value = o.tipName
                        op.innerText = o.tipName
                    }
                    else if (this.id == 'icx_filt') {
                        op.value = o.izName
                        op.innerText = o.izName
                    }
                    else if (this.id == 'kod_vra_filt' || this.id == 'kod_op_filt') {
                        op.value = o.kod
                        op.innerText = o.kod
                    }
                    datalist.appendChild(op)
                }
                div_block.appendChild(inp)
                div_block.appendChild(datalist)

            }

            else if (this.id == 'fam_filt' || this.id == 'im_filt' || this.id == 'ot_filt' || this.id == 'dsc_filt'
                || this.id == 'dspat_filt' || this.id == 'dson_filt' || this.id == 'ksg_osn_filt' || this.id == 'reg_obl_rai_filt'
                || this.id == 'dskz_prich_filt' || this.id == 'stay_in_mo_filt' || this.id == 'time_minuts_po_filt') {
                let inp = document.createElement("input")
                div_block.appendChild(inp)
            }
            else if (this.id == 'dskz_filt' || this.id == 'srber_filt') {
                let inp_1 = document.createElement("input")
                inp_1.setAttribute("style", "width:80px")
                let inp_2 = document.createElement("input")
                inp_2.setAttribute("style", "width:80px")
                let lab_1 = document.createElement("label")
                lab_1.innerHTML = 'C'
                let lab_2 = document.createElement("label")
                lab_2.innerHTML = 'по'
                div_block.appendChild(lab_1)
                div_block.appendChild(inp_1)
                div_block.appendChild(lab_2)
                div_block.appendChild(inp_2)
            }

            if (this.checked) {
                filters.appendChild(div_block)
            }
            else {
                filters.removeChild(document.getElementById(this.id + "_block"))
            }


        })
    }

}

function get_checked_filters() {
    var filter = {}
    for (div of filters.childNodes) {
        if (div.id == 'datv_datp_filt') {
            filter.datv_datp = {
                datp: div.childNodes[2].value,
                datv: div.childNodes[4].value
            }
        }
        else if (div.id == 'datv_filt_block') {
            filter.datv = {
                date_1: div.childNodes[2].value,
                date_2: div.childNodes[4].value
            }
        }
        else if (div.id == 'datp_filt_block') {
            filter.datp = {
                date_1: div.childNodes[2].value,
                date_2: div.childNodes[4].value
            }
        }
        else if (div.id == 'otd_filt_block') {
            filter.otd = {
                otd: div.childNodes[1].value,
            }
        }
        else if (div.id == 'prof_filt_block') {
            filter.prof = {
                prof: div.childNodes[1].value,
            }
        }
        else if (div.id == 'fam_filt_block') {
            filter.fam = {
                fam: div.childNodes[1].value,
            }
        }
        else if (div.id == 'im_filt_block') {
            filter.im = {
                im: div.childNodes[1].value,
            }
        }
        else if (div.id == 'ot_filt_block') {
            filter.ot = {
                ot: div.childNodes[1].value,
            }
        }
        else if (div.id == 'pol_filt_block') {
            filter.pol = {
                pol: div.childNodes[1].value,
            }
        }
        else if (div.id == 'type_lgots_filt_block') {
            filter.type_lgots = {
                type_lgots: div.childNodes[1].value,
            }
        }
        else if (div.id == 'in_t_filt_block') {
            filter.in_t = {
                in_t: div.childNodes[1].value,
            }
        }
        else if (div.id == 'r_n_filt_block') {
            filter.r_n = {
                r_n: div.childNodes[1].value,
            }
        }
        else if (div.id == 'age_group_filt_block') {
            filter.age_group = {
                age_group: div.childNodes[1].value,
            }
        }
        else if (div.id == 'goc_filt_block') {
            filter.goc = {
                goc: div.childNodes[1].value,
            }
        }
        else if (div.id == 'prpg_filt_block') {
            filter.prpg = {
                prpg: div.childNodes[1].value,
            }
        }
        else if (div.id == 'vrez_filt_block') {
            filter.vrez = {
                vrez: div.childNodes[1].value,
            }
        }
        else if (div.id == 'dskz_filt_block') {
            filter.dskz = {
                dskz_1: div.childNodes[2].value,
                dskz_2: div.childNodes[4].value
            }
        }
        else if (div.id == 'dsc_filt_block') {
            filter.dsc = {
                dsc: div.childNodes[1].value,
            }
        }
        else if (div.id == 'dspat_filt_block') {
            filter.dspat = {
                dspat: div.childNodes[1].value,
            }
        }
        else if (div.id == 'dson_filt_block') {
            filter.dson = {
                dson: div.childNodes[1].value,
            }
        }
        else if (div.id == 'dson_filt_block') {
            filter.dson = {
                dson: div.childNodes[1].value,
            }
        }
        else if (div.id == 'ksg_osn_filt_block') {
            filter.ksg_osn = {
                ksg_osn: div.childNodes[1].value,
            }
        }
        else if (div.id == 'c_oksm_filt_block') {
            filter.c_oksm = {
                c_oksm: div.childNodes[1].value,
            }
        }
        else if (div.id == 'terr_filt_block') {
            filter.terr = {
                terr: div.childNodes[1].value,
            }
        }
        else if (div.id == 'reg_obl_rai_filt_block') {
            filter.reg = {
                reg: div.childNodes[1].value,
            }
        }
        else if (div.id == 'rai_in_filt_block') {
            filter.rai_in = {
                rai_in: div.childNodes[1].value,
            }
        }
        else if (div.id == 'cj_filt_block') {
            filter.cj = {
                cj: div.childNodes[1].value,
            }
        }
        else if (div.id == 'lpy_filt_block') {
            filter.lpy = {
                lpy: div.childNodes[1].value,
            }
        }
        else if (div.id == 'ctkom_filt_block') {
            filter.ctkom = {
                ctkom: div.childNodes[1].value,
            }
        }
        else if (div.id == 'vds_filt_block') {
            filter.vds = {
                vds: div.childNodes[1].value,
            }
        }
        else if (div.id == 'icx_filt_block') {
            filter.icx = {
                icx: div.childNodes[1].value,
            }
        }
        else if (div.id == 'otdel_let_filt_block') {
            filter.otdel_let = {
                otdel_let: div.childNodes[1].value,
            }
        }
        else if (div.id == 'kod_vra_filt_block') {
            filter.kod_vra = {
                vra: div.childNodes[1].value,
            }
        }
        else if (div.id == 'kod_op_filt_block') {
            filter.kod_op = {
                kod_op: div.childNodes[1].value,
            }
        }
        else if (div.id == 'pr_osob_filt_block') {
            filter.pr_osob = {
                pr_osob: div.childNodes[1].value,
            }
        }
        else if (div.id == 't_trv_filt_block') {
            filter.t_trv = {
                t_trv: div.childNodes[1].value,
            }
        }
        else if (div.id == 'trav_ns_filt_block') {
            filter.trav_ns = {
                trav_ns: div.childNodes[1].value,
            }
        }
        else if (div.id == 'disability_filt_block') {
            filter.disability = {
                disability: div.childNodes[0].value,
            }
        }

        else if (div.id == 'srber_filt_block') {
            filter.srber = {
                num_1: div.childNodes[2].value,
                num2_2: div.childNodes[4].value
            }
        }
        else if (div.id == 'potd_filt_block') {
            filter.potd = {
                potd: div.childNodes[1].value,
            }
        }
        else if (div.id == 'kod_y_filt_block') {
            filter.kod_y = {
                kod_y: div.childNodes[1].value,
            }
        }
        else if (div.id == 'dskz_prich_filt_block') {
            filter.dskz_prich = {
                dskz_prich: div.childNodes[1].value,
            }
        }
        else if (div.id == 'pr_per_filt_block') {
            filter.pr_per = {
                pr_per: div.childNodes[1].value,
            }
        }
        else if (div.id == 'time_minuts_po_filt_block') {
            filter.time_minuts_po = {
                time_minuts_po: div.childNodes[1].value,
            }
        }
        else if (div.id == 'stay_in_mo_filt_block') {
            filter.stay_in_mo = {
                stay_in_mo: div.childNodes[1].value,
            }
        }
    }

    return { filter }

}

function create_reports(event) {
    let type_report = event.target.getAttribute("btn")
    console.log(type_report)
    if (type_report == 'g_oth') { mix_reports() }
    else if (type_report == 'a_oth_1') { a_oth_1_f(type_report) }
    else if (type_report == 'a_oth_2') { a_oth_2_f(type_report) }
    else if (type_report == 'a_oth_3') { a_oth_3_f(type_report) }
    else if (type_report == 'a_oth_4') { a_oth_4_f(type_report) }
    else if (type_report == 'a_oth_5') { a_oth_5_f(type_report) }
    else if (type_report == 'a_oth_6') { a_oth_6_f(type_report) }
    else if (type_report == 'a_oth_7') { a_oth_7_f(type_report) }
    else if (type_report == 'a_oth_8') { a_oth_8_f(type_report) }
    else if (type_report == 'a_oth_9') { a_oth_9_f(type_report) }
    else if (type_report == 'a_oth_10') { a_oth_10_f(type_report) }
    else if (type_report == 'a_oth_11') { a_oth_11_f(type_report) }
    else if (type_report == 'a_oth_12') { a_oth_12_f(type_report) }
    else if (type_report == 'a_oth_13') { a_oth_13_f(type_report) }
    else if (type_report == 'a_oth_14') { a_oth_14_f(type_report) }
    else if (type_report == 'a_oth_15') { a_oth_15_f(type_report) }
    else if (type_report == 'a_oth_16') { a_oth_16_f(type_report) }
    else if (type_report == 'a_oth_17') { a_oth_17_f(type_report) }
    else if (type_report == 'a_oth_18') { a_oth_18_f(type_report) }
    else if (type_report == 'a_oth_19') { a_oth_19_f(type_report) }
    else if (type_report == 'a_oth_20') { a_oth_20_f(type_report) }
    else if (type_report == 'a_oth_21') { a_oth_21_f(type_report) }
    else if (type_report == 'a_oth_22') { a_oth_22_f(type_report) }
    else if (type_report == 'a_oth_23') { a_oth_23_f(type_report) }
    else if (type_report == 'a_oth_24') { a_oth_24_f(type_report) }
    else if (type_report == 'a_oth_25') { a_oth_25_f(type_report) }
    else if (type_report == 'a_oth_26') { a_oth_26_f(type_report) }
    else if (type_report == 'a_oth_27') { a_oth_27_f(type_report) }
    else if (type_report == 'a_oth_28') { a_oth_28_f(type_report) }
    else if (type_report == 'a_oth_29') { a_oth_29_f(type_report) }
    else if (type_report == 'a_oth_30') { a_oth_30_f(type_report) }
    else if (type_report == 'a_oth_31') { a_oth_31_f(type_report) }
    else if (type_report == 'a_oth_32') { a_oth_32_f(type_report) }
    else if (type_report == 'a_oth_33') { a_oth_33_f(type_report) }
    else if (type_report == 'annual_13_1_1') { annual_13_1_1_f(type_report) }

}
function mix_reports() {
    let filters = get_checked_filters()
    let list_data = get_checked_input(document.getElementById("list_data"))
    let date_1 = document.getElementById("date1")
    let date_2 = document.getElementById("date2")

    var formData = new FormData()
    formData.append('task_type', 'kcc_cb')
    formData.append('date_1', date_1.value)
    formData.append('date_2', date_2.value)
    formData.append('filters', JSON.stringify(filters))

    console.log(filters)
    console.log(list_data)

    if (list_data.length > 0) {
        formData.append('list_data', JSON.stringify(list_data))
    }
    if (date_1.value != "" && date_2.value != "") {
        sendRequest_f(formData)
    }
}
function a_oth_1_f(type_report) {
    let date_1 = document.getElementById("date1")
    let date_2 = document.getElementById("date2")
    let abobsh = document.getElementById("abobsh")
    let vra = document.getElementById("vra")
    let otdel = document.getElementById("otdel")
    let fam_pat = document.getElementById("fam_pat")
    let agegroup = document.getElementById("agegroup")
    let v014 = document.getElementById("v014")
    let prpg = document.getElementById("prpg")
    let v005 = document.getElementById("v005")
    let ds_1 = document.getElementById("input_1")
    let ds_2 = document.getElementById("input_2")
    let v012 = document.getElementById("v012")
    let filename = document.getElementById("filename")

    var filter = {}

    filter.abobsh_list = {
        abobsh: abobsh.value
    }
    filter.kod_vra_man = {
        vra: vra.value
    }
    filter.otd = {
        otd: otdel.value
    }
    filter.fam = {
        fam: fam_pat.value
    }
    filter.age_group = {
        age_group: agegroup.value
    }
    filter.goc = {
        goc: v014.value
    }
    filter.prpg = {
        prpg: prpg.value
    }
    filter.pol = {
        pol: v005.value
    }
    filter.dskz = {
        dskz_1: ds_1.value,
        dskz_2: ds_2.value
    }
    filter.icx = {
        icx: v012.value
    }

    var formData = new FormData()
    formData.append('task_type', 'reports')
    formData.append('type_report', type_report)
    formData.append("date_1", date_1.value)
    formData.append("date_2", date_2.value)
    // formData.append("abobsh", abobsh.value)
    // formData.append("vra", vra.value)
    // formData.append("otdel", otdel.value)
    // formData.append("fam_pat", fam_pat.value)
    // formData.append("agegroup", agegroup.value)
    // formData.append("v014", v014.value)
    // formData.append("prpg", prpg.value)
    // formData.append("v005", v005.value)
    // formData.append("ds_1", ds_1.value)
    // formData.append("ds_2", ds_2.value)
    // formData.append("v012", v012.value)
    formData.append('filters', JSON.stringify({ filter }))
    formData.append("filename", filename.value)
    console.log(date_1.value)
    if (date_1.value != "" && date_2.value != "") {
        sendRequest_f(formData)
        report_oth.$data.shaping = true
    }

}
function a_oth_2_f(type_report) {
    let date_1 = document.getElementById("date1")
    let date_2 = document.getElementById("date2")
    let select_1 = document.getElementById("a_oth_2_select_1")
    let select_2 = document.getElementById("a_oth_2_select_2")
    let filename = document.getElementById("filename")

    var filter = {}
    if (select_2 != null) {
        filter.terr = {
            terr: select_2.value
        }
    }

    var formData = new FormData()
    formData.append('task_type', 'reports')
    formData.append('type_report', type_report)
    formData.append("date_1", date_1.value)
    formData.append("date_2", date_2.value)
    formData.append("select_1", select_1.value)
    formData.append("filter", JSON.stringify({ filter }))
    formData.append("filename", filename.value)



    if (date_1.value != "" && date_2.value != "") {
        sendRequest_f(formData)
        report_oth.$data.shaping = true
    }
}
function a_oth_3_f(type_report) {
    let date_1 = document.getElementById("date1")
    let date_2 = document.getElementById("date2")
    let select_1 = document.querySelectorAll("select")[0]
    let filename = document.getElementById("filename")
    var formData = new FormData()
    formData.append('task_type', 'reports')
    formData.append('type_report', type_report)
    formData.append("date_1", date_1.value)
    formData.append("date_2", date_2.value)
    formData.append("select_1", select_1.value)
    formData.append("filename", filename.value)
    if (date_1.value != "" && date_2.value != "") {
        sendRequest_f(formData)
        report_oth.$data.shaping = true
    }
}
function a_oth_4_f(type_report) {
    let date_1 = document.getElementById("date1")
    let date_2 = document.getElementById("date2")
    let input = document.getElementById("a_oth_4_ds")
    let filename = document.getElementById("filename")

    var formData = new FormData()
    formData.append('task_type', 'reports')
    formData.append('type_report', type_report)
    formData.append("date_1", date_1.value)
    formData.append("date_2", date_2.value)
    formData.append("input", input.value)
    formData.append("filename", filename.value)
    if (date_1.value != "" && date_2.value != "") {
        sendRequest_f(formData)
        report_oth.$data.shaping = true
    }
}
function a_oth_5_f(type_report) {
    let filters = get_checked_filters()
    let date_1 = document.getElementById("date1")
    let date_2 = document.getElementById("date2")
    let filename = document.getElementById("filename")
    var formData = new FormData()
    formData.append('task_type', 'reports')
    formData.append('type_report', type_report)
    formData.append("date_1", date_1.value)
    formData.append("date_2", date_2.value)
    formData.append('filters', JSON.stringify(filters))
    formData.append("filename", filename.value)
    if (date_1.value != "" && date_2.value != "") {
        sendRequest_f(formData)
        report_oth.$data.shaping = true
    }
}
function a_oth_6_f(type_report) {
    let date_1 = document.getElementById("date1")
    let date_2 = document.getElementById("date2")
    let filename = document.getElementById("filename")
    var formData = new FormData()
    formData.append('task_type', 'reports')
    formData.append('type_report', type_report)
    formData.append("date_1", date_1.value)
    formData.append("date_2", date_2.value)
    formData.append("filename", filename.value)
    if (date_1.value != "" && date_2.value != "") {
        sendRequest_f(formData)
        report_oth.$data.shaping = true
    }
}
function a_oth_7_f(type_report) {
    let date_1 = document.getElementById("date1")
    let date_2 = document.getElementById("date2")
    let filename = document.getElementById("filename")
    var formData = new FormData()
    formData.append('task_type', 'reports')
    formData.append('type_report', type_report)
    formData.append("date_1", date_1.value)
    formData.append("date_2", date_2.value)
    formData.append("filename", filename.value)
    if (date_1.value != "" && date_2.value != "") {
        sendRequest_f(formData)
        report_oth.$data.shaping = true
    }
}
function a_oth_8_f(type_report) {
    let date_1 = document.getElementById("date1")
    let date_2 = document.getElementById("date2")
    let filename = document.getElementById("filename")
    var formData = new FormData()
    formData.append('task_type', 'reports')
    formData.append('type_report', type_report)
    formData.append("date_1", date_1.value)
    formData.append("date_2", date_2.value)
    formData.append("filename", filename.value)
    if (date_1.value != "" && date_2.value != "") {
        sendRequest_f(formData)
        report_oth.$data.shaping = true
    }
}
function a_oth_9_f(type_report) {
    let date_1 = document.getElementById("date1")
    let date_2 = document.getElementById("date2")
    let filename = document.getElementById("filename")
    var formData = new FormData()
    formData.append('task_type', 'reports')
    formData.append('type_report', type_report)
    formData.append("date_1", date_1.value)
    formData.append("date_2", date_2.value)
    formData.append("filename", filename.value)
    if (date_1.value != "" && date_2.value != "") {
        sendRequest_f(formData)
        report_oth.$data.shaping = true
    }
}
function a_oth_10_f(type_report) {
    let date_1 = document.getElementById("date1")
    let date_2 = document.getElementById("date2")
    let select = document.getElementById("a_oth_10_select")
    let filename = document.getElementById("filename")
    var formData = new FormData()
    formData.append('task_type', 'reports')
    formData.append('type_report', type_report)
    formData.append("date_1", date_1.value)
    formData.append("date_2", date_2.value)
    formData.append("select", select.value)
    formData.append("filename", filename.value)
    if (date_1.value != "" && date_2.value != "") {
        sendRequest_f(formData)
        report_oth.$data.shaping = true
    }
}
function a_oth_11_f(type_report) {
    let date_1 = document.getElementById("date1")
    let date_2 = document.getElementById("date2")
    let filename = document.getElementById("filename")
    var formData = new FormData()
    formData.append('task_type', 'reports')
    formData.append('type_report', type_report)
    formData.append("date_1", date_1.value)
    formData.append("date_2", date_2.value)
    formData.append("filename", filename.value)
    if (date_1.value != "" && date_2.value != "") {
        sendRequest_f(formData)
        report_oth.$data.shaping = true
    }
}
function a_oth_12_f(type_report) {
    let date_1 = document.getElementById("date1")
    let date_2 = document.getElementById("date2")
    let filename = document.getElementById("filename")
    var formData = new FormData()
    formData.append('task_type', 'reports')
    formData.append('type_report', type_report)
    formData.append("date_1", date_1.value)
    formData.append("date_2", date_2.value)
    formData.append("filename", filename.value)
    if (date_1.value != "" && date_2.value != "") {
        sendRequest_f(formData)
        report_oth.$data.shaping = true
    }
}
function a_oth_13_f(type_report) {
    let date_1 = document.getElementById("date1")
    let date_2 = document.getElementById("date2")
    let filename = document.getElementById("filename")
    var formData = new FormData()
    formData.append('task_type', 'reports')
    formData.append('type_report', type_report)
    formData.append("date_1", date_1.value)
    formData.append("date_2", date_2.value)
    formData.append("filename", filename.value)
    if (date_1.value != "" && date_2.value != "") {
        sendRequest_f(formData)
        report_oth.$data.shaping = true
    }
}
function a_oth_14_f(type_report) {
    let date_1 = document.getElementById("date1")
    let date_2 = document.getElementById("date2")
    let filename = document.getElementById("filename")
    var formData = new FormData()
    formData.append('task_type', 'reports')
    formData.append('type_report', type_report)
    formData.append("date_1", date_1.value)
    formData.append("date_2", date_2.value)
    formData.append("filename", filename.value)
    if (date_1.value != "" && date_2.value != "") {
        sendRequest_f(formData)
        report_oth.$data.shaping = true
    }
}
function a_oth_15_f(type_report) {
    let date_1 = document.getElementById("date1")
    let date_2 = document.getElementById("date2")
    let filename = document.getElementById("filename")
    var formData = new FormData()
    formData.append('task_type', 'reports')
    formData.append('type_report', type_report)
    formData.append("date_1", date_1.value)
    formData.append("date_2", date_2.value)
    formData.append("filename", filename.value)
    if (date_1.value != "" && date_2.value != "") {
        sendRequest_f(formData)
        report_oth.$data.shaping = true
    }
}
function a_oth_16_f(type_report) {
    let date_1 = document.getElementById("date1")
    let date_2 = document.getElementById("date2")
    let filename = document.getElementById("filename")
    var formData = new FormData()
    formData.append('task_type', 'reports')
    formData.append('type_report', type_report)
    formData.append("date_1", date_1.value)
    formData.append("date_2", date_2.value)
    formData.append("filename", filename.value)
    if (date_1.value != "" && date_2.value != "") {
        sendRequest_f(formData)
        report_oth.$data.shaping = true
    }
}
function a_oth_17_f(type_report) {
    let date_1 = document.getElementById("date1")
    let date_2 = document.getElementById("date2")
    let filename = document.getElementById("filename")
    var formData = new FormData()
    formData.append('task_type', 'reports')
    formData.append('type_report', type_report)
    formData.append("date_1", date_1.value)
    formData.append("date_2", date_2.value)
    formData.append("filename", filename.value)
    if (date_1.value != "" && date_2.value != "") {
        sendRequest_f(formData)
        report_oth.$data.shaping = true
    }
}
function a_oth_18_f(type_report) {
    let date_1 = document.getElementById("date1")
    let date_2 = document.getElementById("date2")
    let filename = document.getElementById("filename")
    var formData = new FormData()
    formData.append('task_type', 'reports')
    formData.append('type_report', type_report)
    formData.append("date_1", date_1.value)
    formData.append("date_2", date_2.value)
    formData.append("filename", filename.value)
    if (date_1.value != "" && date_2.value != "") {
        sendRequest_f(formData)
        report_oth.$data.shaping = true
    }
}
function a_oth_19_f(type_report) {
    let date_1 = document.getElementById("date1")
    let date_2 = document.getElementById("date2")
    let trv = document.getElementById("trv")
    let trvnas = document.getElementById("trvnas")
    let filename = document.getElementById("filename")

    var filter = {}


    filter.t_trv = {
        t_trv: trv.value,
    }

    filter.trav_ns = {
        trav_ns: trvnas.value,
    }



    var formData = new FormData()
    formData.append('task_type', 'reports')
    formData.append('type_report', type_report)
    formData.append("date_1", date_1.value)
    formData.append("date_2", date_2.value)
    // formData.append("trv", trv.value)
    // formData.append("trvnas", trvnas.value)
    formData.append("filter", JSON.stringify({ filter }))
    formData.append("filename", filename.value)
    if (date_1.value != "" && date_2.value != "") {
        sendRequest_f(formData)
        report_oth.$data.shaping = true
    }
}
function a_oth_20_f(type_report) {
    let date_1 = document.getElementById("date1")
    let date_2 = document.getElementById("date2")
    let isfin = document.getElementById("isfin")
    let ds_1 = document.getElementById("input_1")
    let ds_2 = document.getElementById("input_2")
    let v014 = document.getElementById("v014")
    let f003 = document.getElementById("f003")
    let filename = document.getElementById("filename")

    var filter = {}


    filter.vds = {
        vds: isfin.value
    }
    filter.dskz = {
        dskz_1: ds_1.value,
        dskz_2: ds_2.value
    }
    filter.goc = {
        goc: v014.value
    }
    filter.lpy = {
        lpy: f003.value
    }


    var formData = new FormData()
    formData.append('task_type', 'reports')
    formData.append('type_report', type_report)
    formData.append("date_1", date_1.value)
    formData.append("date_2", date_2.value)
    // formData.append("isfin", isfin.value)
    // formData.append("ds_1", ds_1.value)
    // formData.append("ds_2", ds_2.value)
    // formData.append("v014", v014.value)
    // formData.append("f003", f003.value)
    formData.append("filter", JSON.stringify({ filter }))
    formData.append("filename", filename.value)
    if (date_1.value != "" && date_2.value != "") {
        sendRequest_f(formData)
        report_oth.$data.shaping = true
    }
}
function a_oth_21_f(type_report) {
    let date_1 = document.getElementById("date1")
    let date_2 = document.getElementById("date2")
    let select = document.getElementById("a_oth_21_select")
    let input_1 = document.getElementById("a_oth_21_input_1")
    let input_2 = document.getElementById("a_oth_21_input_2")
    let vra = document.getElementById("vra")
    let filename = document.getElementById("filename")
    var formData = new FormData()
    formData.append('task_type', 'reports')
    formData.append('type_report', type_report)
    formData.append("date_1", date_1.value)
    formData.append("date_2", date_2.value)
    formData.append("select", select.value)
    formData.append("input_1", input_1.value)
    formData.append("input_2", input_2.value)
    formData.append("vra", vra.value)
    formData.append("filename", filename.value)

    if (date_1.value != "" && date_2.value != "") {
        sendRequest_f(formData)
        report_oth.$data.shaping = true
    }

}
function a_oth_22_f(type_report) {
    let date_1 = document.getElementById("date1")
    let date_2 = document.getElementById("date2")
    let filename = document.getElementById("filename")

    var formData = new FormData()
    formData.append('task_type', 'reports')
    formData.append('type_report', type_report)
    formData.append("date_1", date_1.value)
    formData.append("date_2", date_2.value)
    formData.append("filename", filename.value)

    if (date_1.value != "" && date_2.value != "") {
        sendRequest_f(formData)
        report_oth.$data.shaping = true
    }
}
function a_oth_23_f(type_report) {
    let date_1 = document.getElementById("date1")
    let date_2 = document.getElementById("date2")
    let filename = document.getElementById("filename")
    var formData = new FormData()
    formData.append('task_type', 'reports')
    formData.append('type_report', type_report)
    formData.append("date_1", date_1.value)
    formData.append("date_2", date_2.value)
    formData.append("filename", filename.value)
    if (date_1.value != "" && date_2.value != "") {
        sendRequest_f(formData)
        report_oth.$data.shaping = true
    }
}
function a_oth_24_f(type_report) {
    let date_1 = document.getElementById("date1")
    let date_2 = document.getElementById("date2")
    let filename = document.getElementById("filename")
    var formData = new FormData()
    formData.append('task_type', 'reports')
    formData.append('type_report', type_report)
    formData.append("date_1", date_1.value)
    formData.append("date_2", date_2.value)
    formData.append("filename", filename.value)
    if (date_1.value != "" && date_2.value != "") {
        sendRequest_f(formData)
        report_oth.$data.shaping = true
    }
}
function a_oth_25_f(type_report) {
    let date_1 = document.getElementById("date1")
    let date_2 = document.getElementById("date2")
    let filename = document.getElementById("filename")
    var formData = new FormData()
    formData.append('task_type', 'reports')
    formData.append('type_report', type_report)
    formData.append("date_1", date_1.value)
    formData.append("date_2", date_2.value)
    formData.append("filename", filename.value)
    if (date_1.value != "" && date_2.value != "") {
        sendRequest_f(formData)
        report_oth.$data.shaping = true
    }
}
function a_oth_26_f(type_report) {
    let date_1 = document.getElementById("date1")
    let date_2 = document.getElementById("date2")
    let select = document.getElementById("a_oth_26_select")
    let filename = document.getElementById("filename")
    var formData = new FormData()
    formData.append('task_type', 'reports')
    formData.append('type_report', type_report)
    formData.append("date_1", date_1.value)
    formData.append("date_2", date_2.value)
    formData.append("select", select.value)
    formData.append("filename", filename.value)
    if (date_1.value != "" && date_2.value != "") {
        sendRequest_f(formData)
        report_oth.$data.shaping = true
    }
}
function a_oth_27_f(type_report) {
    let date_1 = document.getElementById("date1")
    let date_2 = document.getElementById("date2")
    let select = document.getElementById("a_oth_27_select")
    let v020 = document.getElementById("v020")
    let filename = document.getElementById("filename")

    var formData = new FormData()
    formData.append('task_type', 'reports')
    formData.append('type_report', type_report)
    formData.append("date_1", date_1.value)
    formData.append("date_2", date_2.value)
    formData.append("select", select.value)
    formData.append("v020", v020.value)
    formData.append("filename", filename.value)

    if (date_1.value != "" && date_2.value != "") {
        sendRequest_f(formData)
        report_oth.$data.shaping = true
    }

}
function a_oth_28_f(type_report) {
    let date_1 = document.getElementById("date1")
    let date_2 = document.getElementById("date2")
    let filename = document.getElementById("filename")
    var formData = new FormData()
    formData.append('task_type', 'reports')
    formData.append('type_report', type_report)
    formData.append("date_1", date_1.value)
    formData.append("date_2", date_2.value)
    formData.append("filename", filename.value)
    if (date_1.value != "" && date_2.value != "") {
        sendRequest_f(formData)
        report_oth.$data.shaping = true
    }
}
function a_oth_29_f(type_report) {
    let date_1 = document.getElementById("date1")
    let date_2 = document.getElementById("date2")
    let input_ds_1 = document.getElementById("input_1")
    let input_ds_2 = document.getElementById("input_2")
    let filename = document.getElementById("filename")
    var formData = new FormData()
    formData.append('task_type', 'reports')
    formData.append('type_report', type_report)
    formData.append("date_1", date_1.value)
    formData.append("date_2", date_2.value)
    formData.append("input_ds_1", input_ds_1.value)
    formData.append("input_ds_2", input_ds_2.value)
    formData.append("filename", filename.value)
    if (date_1.value != "" && date_2.value != "") {
        sendRequest_f(formData)
        report_oth.$data.shaping = true
    }
}
function a_oth_30_f(type_report) {
    let date_1 = document.getElementById("date1")
    let date_2 = document.getElementById("date2")
    let filename = document.getElementById("filename")
    var formData = new FormData()
    formData.append('task_type', 'reports')
    formData.append('type_report', type_report)
    formData.append("date_1", date_1.value)
    formData.append("date_2", date_2.value)
    formData.append("filename", filename.value)
    if (date_1.value != "" && date_2.value != "") {
        sendRequest_f(formData)
        report_oth.$data.shaping = true
    }
}
function a_oth_31_f(type_report) {
    let date_1 = document.getElementById("date1")
    let date_2 = document.getElementById("date2")
    let filename = document.getElementById("filename")
    var formData = new FormData()
    formData.append('task_type', 'reports')
    formData.append('type_report', type_report)
    formData.append("date_1", date_1.value)
    formData.append("date_2", date_2.value)
    formData.append("filename", filename.value)
    if (date_1.value != "" && date_2.value != "") {
        sendRequest_f(formData)
        report_oth.$data.shaping = true
    }
}
function a_oth_32_f(type_report) {
    let date_1 = document.getElementById("date1")
    let date_2 = document.getElementById("date2")
    let filename = document.getElementById("filename")
    var formData = new FormData()
    formData.append('task_type', 'reports')
    formData.append('type_report', type_report)
    formData.append("date_1", date_1.value)
    formData.append("date_2", date_2.value)
    formData.append("filename", filename.value)
    if (date_1.value != "" && date_2.value != "") {
        sendRequest_f(formData)
        report_oth.$data.shaping = true
    }
}
function a_oth_33_f(type_report) {
    let date_1 = document.getElementById("date1")
    let date_2 = document.getElementById("date2")
    let filename = document.getElementById("filename")
    var formData = new FormData()
    formData.append('task_type', 'reports')
    formData.append('type_report', type_report)
    formData.append("date_1", date_1.value)
    formData.append("date_2", date_2.value)
    formData.append("filename", filename.value)
    if (date_1.value != "" && date_2.value != "") {
        sendRequest_f(formData)
        report_oth.$data.shaping = true
    }
}

function annual_13_1_1_f(type_report) {
    // let date_1 = document.getElementById("date1")
    // let date_2 = document.getElementById("date2")


    // var formData = new FormData()
    // formData.append('task_type', 'annual')
    // formData.append('type_report', type_report)
    // formData.append("date_1", date_1.value)
    // formData.append("date_2", date_2.value)
    // if (date_1.value != "" && date_2.value != "") {
    //     sendRequest_f(formData)
    //     console.log('annual_13_1_1_f')
    //     // report_oth.$data.shaping = true
    // }
    // var formData = new FormData()
    // formData.append('task_type', 'annual')
    // formData.append('type_report', type_report)
    // formData.append("date_1", $("#date_r_1").val())
    // formData.append("date_2", $("#date_r_2").val())
    // sendRequest_f(formData)


    let date_1 = document.getElementById("date1")
    let date_2 = document.getElementById("date2")
    var formData = new FormData()
    formData.append('task_type', 'annual')
    formData.append('type_report', type_report)
    formData.append("date_1", date_1.value)
    formData.append("date_2", date_2.value)
    if (date_1.value != "" && date_2.value != "") {
        sendRequest_f(formData)
        report_oth.$data.shaping = true
    }

}


function sendRequest_f(formData) {
    var r = sendRequest('reports/', 'post', formData)
        .then(response => {
            console.log(response.data.rez)
        })
        .catch(error => {
        })
}

function get_checked_input(ul) {
    if (ul != null && ul != undefined) {
        let list_input = ul.querySelectorAll("input")
        let checked_input = []
        for (input of list_input) {
            if (input.checked) {
                checked_input.push(input.id)
            }
        }
        return checked_input
    }
    return ''

}




function departments_reports() {
}

function vra_reports() {
}

function vault_otd_reports() {
}
