function Oper_add() {
    let tbody = document.getElementById("operation_table").querySelector("tbody")
    let count = tbody.childNodes

    if (count.length == 0) {
        var n = 0
    }
    else {
        var n = count.length
    }
    let pr = app.$data.sprav_list.PROsob
    let op_l = ['dato', 'tm_o', 'py', 'kod_op', 'kod_op_name', 'goc', 'kodx', 'kodx_naim', 'pop', 'pr_osob', 'k_mm', 'kodxa', 'kodxa1', 'obz', 'kodan', 'btn']
    let tr = document.createElement("tr")
    tr.setAttribute("n", n)
    for (o in op_l) {
        let td = document.createElement("td")
        td.setAttribute("name", op_l[o])
        if (op_l[o] == "py") {
            let select = document.createElement("select")
            select.classList.add('custom-select')
            select.classList.add('text-center')
            let py = [1, 2]
            for (let i = 0; i < py.length; i++) {
                let option = document.createElement("option")
                option.innerText = py[i]
                select.appendChild(option)
                select.value = ''
            }
            td.appendChild(select)
            td.setAttribute("name", op_l[o])
            td.setAttribute("tr", n)
            tr.appendChild(td)
        }

        else if (op_l[o] == "goc") {
            let select = document.createElement("select")
            select.classList.add('custom-select')
            select.classList.add('text-center')
            let goc = ['1', '2']
            for (let i = 0; i < goc.length; i++) {
                let option = document.createElement("option")
                option.innerText = goc[i]
                select.appendChild(option)
            }
            select.value = ''
            td.appendChild(select)
            td.setAttribute("name", op_l[o])
            td.setAttribute("tr", n)
            tr.appendChild(td)
        }
        else if (op_l[o] == "pop") {
            let select = document.createElement("select")
            select.classList.add('custom-select')
            select.classList.add('text-center')
            let pop = ['Да', 'Нет', 'Неизвестно']
            for (let p of pop) {
                let option = document.createElement("option")
                option.innerText = p
                select.appendChild(option)
            }
            select.value = ''
            td.appendChild(select)
            td.setAttribute("name", op_l[o])
            td.setAttribute("tr", n)
            tr.appendChild(td)
        }
        else if (op_l[o] == "pr_osob") {
            let select = document.createElement("select")
            select.classList.add('form-control')
            select.classList.add('text-center')
            select.setAttribute('multiple', '')
            select.setAttribute('style', 'width: 379px')
            for (let p = 0; p < pr.length; p++) {
                let option = document.createElement("option")
                option.value = pr[p].kod
                option.innerText = pr[p].naim
                select.appendChild(option)
            }

            td.appendChild(select)


            td.setAttribute("name", op_l[o])
            td.setAttribute("tr", n)
            tr.appendChild(td)
        }
        else if (op_l[o] == "btn") {
            td.setAttribute("name", "btn")
            let btn = document.createElement("input")
            btn.setAttribute('type', 'button')
            btn.classList.add('btn')
            btn.classList.add('btn-danger')
            btn.value = 'Удалить'
            btn.addEventListener("click", function () {
                tr.remove()
                Oper_delete(td)
            })
            td.appendChild(btn)
            tr.appendChild(td)
        }
        else {

            var ed = document.createElement("input")
            // ed.value = op_l[o]
            if (op_l[o] == 'dato') {
                ed.setAttribute("style", "width:95px")
                ed.setAttribute("name", op_l[o])
            }
            else if (op_l[o] == 'tm_o') {
                ed.setAttribute("style", "width:60px")
            }
            else if (op_l[o] == 'kod_op') {
                ed.setAttribute("style", "width:150px")
            }
            else if (op_l[o] == 'kod_op_name') {
                ed.setAttribute("style", "width:310px")
            }
            else if (op_l[o] == 'kodx') {
                ed.setAttribute("style", "width:86px")
            }
            else if (op_l[o] == 'kodx_naim') {
                ed.setAttribute("style", "width:188px")
            }
            else if (op_l[o] == 'k_mm') {
                ed.setAttribute("style", "width:71px")
            }
            else if (op_l[o] == 'kodxa') {
                ed.setAttribute("style", "width:86px")
            }
            else if (op_l[o] == 'kodxa1') {
                ed.setAttribute("style", "width:86px")
            }
            else if (op_l[o] == 'obz') {
                ed.setAttribute("style", "width:92px")
            }
            else if (op_l[o] == 'kodan') {
                ed.setAttribute("style", "width:92px")
            }

            td.appendChild(ed)


            td.setAttribute("name", op_l[o])
            td.setAttribute("tr", n)
            tr.appendChild(td)
        }

    }
    tbody.appendChild(tr)
    obj = {}
    for (let t = 0; t < tr.childNodes.length; t++) {
        let td = tr.childNodes[t]
        if (td.getAttribute("name") != "btn") {
            if (td.getAttribute("name") != "pr_osob") {
                obj[td.getAttribute("name")] = ''
            }
            else {
                obj[td.getAttribute("name")] = []
            }
        }
    }
    app.$data.history.oper.push(obj)
    Oper_input()
    let add_btn = document.getElementById("add_tr_koyko")
    add_btn.setAttribute("disabled","disabled")
}

function Oper_edit() {
    document.getElementById("inf_operation").scrollLeft = 0
    let tbody = document.getElementById("operation_table").querySelector("tbody")
    tbody.innerHTML = ""
    let v_oper = app.$data.history.oper
    let pr = app.$data.sprav_list.PROsob
    var n = 0
    if (v_oper.length > 0) {
        for (let opers in v_oper) {
            let oper = v_oper[opers]
            let tr = document.createElement("tr")
            tr.setAttribute("n", n)
            for (o in oper) {
                let td = document.createElement("td")
                if (o == "py") {
                    let select = document.createElement("select")
                    select.classList.add('custom-select')
                    select.classList.add('text-center')
                    let py = [1, 2]
                    for (let i = 0; i < py.length; i++) {
                        let option = document.createElement("option")
                        option.innerText = py[i]
                        select.appendChild(option)
                    }
                    select.value = oper[o]
                    td.appendChild(select)
                    td.setAttribute("name", o)
                    td.setAttribute("tr", n)
                    tr.appendChild(td)
                }
                else if (o == "goc") {
                    let select = document.createElement("select")
                    select.classList.add('custom-select')
                    select.classList.add('text-center')
                    let goc = ['1', '2']
                    for (let i = 0; i < goc.length; i++) {
                        let option = document.createElement("option")
                        option.innerText = goc[i]
                        select.appendChild(option)
                    }
                    select.value = oper[o]
                    td.appendChild(select)
                    td.setAttribute("name", o)
                    td.setAttribute("tr", n)
                    tr.appendChild(td)
                }
                else if (o == "pop") {
                    let select = document.createElement("select")
                    select.classList.add('custom-select')
                    select.classList.add('text-center')
                    let pop = ['Да', 'Нет', 'Неизвестно']
                    for (let p of pop) {
                        let option = document.createElement("option")
                        option.innerText = p
                        select.appendChild(option)
                    }
                    select.value = oper[o]
                    if (select.value == 'Да'){
                        $("#oper_osn").val(oper['kod_op']) 
                    }
                 
                    td.appendChild(select)
                    td.setAttribute("name", o)
                    td.setAttribute("tr", n)
                    tr.appendChild(td)
                }
                else if (o == "pr_osob") {
                    let select = document.createElement("select")
                    select.classList.add('form-control')
                    select.classList.add('text-center')
                    select.setAttribute('multiple', '')
                    select.setAttribute('style', 'width: 379px')
                    for (let p = 0; p < pr.length; p++) {
                        let option = document.createElement("option")
                        option.value = pr[p].kod
                        option.innerText = pr[p].naim
                        select.appendChild(option)
                    }
                    options = Array.from(select.childNodes)
                    td.appendChild(select)

                    oper[o].forEach(function (v) {
                        options.find(c => c.value == v).selected = true;

                    });
                    td.setAttribute("name", o)
                    td.setAttribute("tr", n)
                    tr.appendChild(td)
                }
                else {
                    var ed = document.createElement("input")
                    ed.value = oper[o]
                    if (o == 'dato') {
                        ed.setAttribute("style", "width:95px")
                        ed.setAttribute("name", o)
                    }
                    else if (o == 'tm_o') {
                        ed.setAttribute("style", "width:60px")
                    }
                    else if (o == 'kod_op') {
                        ed.setAttribute("style", "width:150px")
                    }
                    else if (o == 'kod_op_name') {
                        ed.setAttribute("style", "width:310px")
                    }
                    else if (o == 'kodx') {
                        ed.setAttribute("style", "width:86px")
                    }
                    else if (o == 'kodx_naim') {
                        ed.setAttribute("style", "width:188px")
                    }
                    else if (o == 'k_mm') {
                        ed.setAttribute("style", "width:71px")
                    }
                    else if (o == 'kodxa') {
                        ed.setAttribute("style", "width:86px")
                    }
                    else if (o == 'kodxa1') {
                        ed.setAttribute("style", "width:86px")
                    }
                    else if (o == 'obz') {
                        ed.setAttribute("style", "width:92px")
                    }
                    else if (o == 'kodan') {
                        ed.setAttribute("style", "width:92px")
                    }

                    td.appendChild(ed)
                    td.setAttribute("name", o)
                    td.setAttribute("tr", n)
                    tr.appendChild(td)
                }

            }

            let td = document.createElement("td")
            td.setAttribute("name", "btn")
            let btn = document.createElement("input")
            btn.setAttribute('type', 'button')
            btn.classList.add('btn')
            btn.classList.add('btn-danger')
            btn.value = 'Удалить'

            btn.addEventListener("click", function () {
                tr.remove()
                Oper_delete(td)
            })
            td.appendChild(btn)
            td.setAttribute("tr", n)
            tr.appendChild(td)

            tbody.appendChild(tr)
            n += 1
        }
    Oper_input()
    }
    else{
        // let add_btn = document.getElementById("add_tr_koyko")
        // add_btn.removeAttribute("disabled")
        // Oper_add()
    }
   
}

function Oper_input() {
    let kod = app.$data.sprav_list.V001
    let str_kod = ''
    for (let k = 0; k < kod.length; k++) {
        str_kod += '<option value="' + kod[k].kod + '" />'
    }

    let kod_vra = app.$data.sprav_list.Vra
    let str_vra = ''
    for (let k = 0; k < kod_vra.length; k++) {
        str_vra += '<option value="' + kod_vra[k].kod + '" />'
    }
    let kod_obez = app.$data.sprav_list.anesthesia
    let str_obez = ''
    for (let k = 0; k < kod_obez.length; k++) {
        str_obez += '<option value="' + kod_obez[k].kod + '" />'
    }
    var table = document.getElementById("operation_table")
    var cells = table.getElementsByTagName("td")

    for (let i = 0; i < cells.length; i++) {
        if ((cells[i].getAttribute("name") == "dato") || (cells[i].getAttribute("name") == "tm_o") || (cells[i].getAttribute("name") == "kod_op")
            || (cells[i].getAttribute("name") == "kodx")  || (cells[i].getAttribute("name") == "kodxa")
            || (cells[i].getAttribute("name") == "kodxa1") || (cells[i].getAttribute("name") == "obz") || (cells[i].getAttribute("name") == "kodan")) {

            let input = cells[i].childNodes[0]
            if (cells[i].getAttribute("name") == "dato") {
                input.setAttribute("maxlength", 10)
                input.addEventListener("input", function () {
                    var n = input.value.replace(/[^0-9]/g, '').split('')
                    if (n.length > 2) n.splice(2, 0, '-')
                    if (n.length > 4) n.splice(5, 0, '-')
                    input.value = n.join('')
                })
                input.addEventListener("change", function () {
                    Oper_update(cells[i])
                })
            }
            else if (cells[i].getAttribute("name") == "tm_o") {
                input.setAttribute("maxlength", 5)
                input.addEventListener("input", function () {
                    var n = input.value.replace(/[^0-9]/g, '').split('')
                    if (n.length > 2) n.splice(2, 0, ':')
                    input.value = n.join('')
                })
                input.addEventListener("change", function () {
                    Oper_update(cells[i])
                })
            }
            else if (cells[i].getAttribute("name") == "kod_op") {

                input.addEventListener('focus',function () {
                    document.getElementById("inf_operation").scrollLeft = 250
                })

                input.addEventListener("input", function () {
                    input.setAttribute('list', cells[i].getAttribute("name"))
                    let data = document.createElement("datalist")
                    data.setAttribute('id', cells[i].getAttribute("name"))
                    data.innerHTML = str_kod
                    input.appendChild(data)
                })
                input.addEventListener("change", function () {
                        let query = `
                          query{
                              V001Name(kod:"${input.value}"){
                                naim
                              }
                          }`
                        fetch('graph_hospital/', {
                              method: 'post',
                              headers: {
                                'Content-Type': 'application/json',
                              },
                              body: JSON.stringify({query})
                            })
                            .then(response => response.json())
                            .then(data => {
                                var tr_list = document.getElementById("operation_table").querySelector("tbody").querySelectorAll("tr")
                                var tr = tr_list[cells[i].getAttribute("tr")]
                                var naim = tr.childNodes[4]
                                naim.childNodes[0].value = data.data.V001Name[0].naim
                                Oper_update(tr.childNodes[3])
                                Oper_update(tr.childNodes[4])
                            })
                            .catch((e) => {
                              console.log(e)
                            })

                })
            }
            else if ((cells[i].getAttribute('name') == "kodx") || (cells[i].getAttribute('name') == "kodxa")
                || (cells[i].getAttribute('name') == "kodxa1") || (cells[i].getAttribute('name') == "kodan")) {
                input.addEventListener("input", function () {
                    input.setAttribute('list', cells[i].getAttribute("name"))
                    let data = document.createElement("datalist")
                    data.setAttribute('id', cells[i].getAttribute("name"))
                    data.innerHTML = str_vra
                    input.appendChild(data)
                })

                if (cells[i].getAttribute('name') == "kodx") {
                    input.addEventListener('focus',function () {
                    document.getElementById("inf_operation").scrollLeft = 850
                })

                    input.addEventListener('change', function () {
                        let query = `
                          query{
                              VraName(kod:"${input.value}"){
                                naim
                              }
                          }`
                        fetch('graph_hospital/', {
                              method: 'post',
                              headers: {
                                'Content-Type': 'application/json',
                              },
                              body: JSON.stringify({query})
                            })
                            .then(response => response.json())
                            .then(data => {
                                var tr_list = document.getElementById("operation_table").querySelector("tbody").querySelectorAll("tr")
                                var tr = tr_list[cells[i].getAttribute("tr")]
                                var naim = tr.childNodes[7]
                                naim.childNodes[0].value = data.data.VraName[0].naim
                                Oper_update(tr.childNodes[6])
                                Oper_update(tr.childNodes[7])
                            })
                            .catch((e) => {
                              console.log(e)
                            })
                    })
                }

                else {
                    input.addEventListener("change",function(){
                        Oper_update(cells[i])
                    })
                    if(cells[i].getAttribute('name') == "kodxa"){
                         input.addEventListener('focus',function () {
                        document.getElementById("inf_operation").scrollLeft = 1550
                })
                    }
                }
            }

            else if (cells[i].getAttribute('name') == "obz") {
                input.addEventListener("input", function () {
                    input.setAttribute('list', cells[i].getAttribute("name"))
                    let data = document.createElement("datalist")
                    data.setAttribute('id', cells[i].getAttribute("name"))
                    data.innerHTML = str_obez
                    input.appendChild(data)
                })

                input.addEventListener("change",function(){
                    Oper_update(cells[i])
                })
            }
        }
        else if (cells[i].getAttribute("name") == "pop"){

            let select = cells[i].childNodes[0]
            select.addEventListener('focus',function () {
                    document.getElementById("inf_operation").scrollLeft = 1200
                })
            select.addEventListener("change",function(){
                Oper_update(cells[i])
                if (cells[i].childNodes[0].value == 'Да'){
                    $("#oper_osn").val(cells[3].childNodes[0].value)
                }
                
            })
        }
        else {
            let select = cells[i].childNodes[0]
            select.addEventListener("change",function(){
                Oper_update(cells[i])
            })
        }

    }
}

function Oper_delete(td) {
    let v_oper = app.$data.history.oper
    let oper = []

    for (let c = 0;c < v_oper.length;c++){
        if (c != td.getAttribute("tr")){
            oper.push(v_oper[c])
        }
    }
    app.$data.history.oper = oper
    Oper_edit()
    Oper_input()
}
function Oper_update(td) {
    var v_oper = app.$data.history.oper
    if (td.getAttribute("name") != "pr_osob"){
        v_oper[td.getAttribute("tr")][td.getAttribute("name")] = td.childNodes[0].value
    }
    else{
        let select_active = td.childNodes[0].selectedOptions
        let active = []
        for (let a of select_active) {
            active.push(a.value)
        }
        v_oper[td.getAttribute("tr")][td.getAttribute("name")] = active
    }

}