import graphene
from django.db.models import Max
from  .type import *
# request == info.context
from okb2.models import (V005, otde, Rab_Ner, T004, F003, Vrzb, Oksm, Ds,V012,V009,V020,Vra,V021,
                         PR_OSOB,V001,T006,MyUser,Ab_Obsh,Pope,Prli,Trv,Isfin,Skom,F008,F011,N018,
                         N002,N003,N004,N005,N007,N010,N008,
                         N011, N019, N013, N014, N001, V028, V029, V014, Prpg, PER, PR_PER, Tip_pb, Met_pb, V027,
                         Trvnas, V002, anesthesia, V018_bpoms, V019_bpoms, V018_sboms, V019_sboms, Tar_vt, group_kc_dkk,
                         Age_group)


class Query(graphene.ObjectType):
    V005 = graphene.List(V005Type)
    Otde = graphene.List(OtdeType)
    Rab_ner = graphene.List(Rab_nerType)
    T004 = graphene.List(T004Type)
    F003 = graphene.List(F003Type)
    Vrzb = graphene.List(VrzbType)
    Oksm = graphene.List(OksmType)
    Ds_list = graphene.List(DsType,ds=graphene.String())
    Ds_name = graphene.List(DsType,ds=graphene.String())
    V012 = graphene.List(V012Type)
    V009 = graphene.List(V009Type)
    V020 = graphene.List(V020Type)
    Vra = graphene.List(VraType)
    Vra_name = graphene.List(VraType,kod=graphene.String())
    V021_name = graphene.List(V021Type,spec=graphene.String())
    PR_OSOB = graphene.List(PR_OSOBType)
    V001 = graphene.List(V001Type)
    T006 = graphene.List(T006Type)
    Ab_Obsh = graphene.List(Ab_ObshType)
    V001_name = graphene.List(V001Type,kod=graphene.String())
    Pope = graphene.List(PopeType)
    Pope_name = graphene.List(PopeType,kod=graphene.String())
    Ab_Obsh_name = graphene.List(Ab_ObshType,kod=graphene.String())
    Prli = graphene.List(PrliType)
    Trv = graphene.List(TrvType)
    Isfin = graphene.List(IsfinType)
    Skom = graphene.List(SkomType)
    F008 = graphene.List(F008Type)
    F011 = graphene.List(F011Type)
    N018 = graphene.List(N018Type)
    N002 = graphene.List(N002Type,ds=graphene.String())
    N003 = graphene.List(N003Type,ds=graphene.String())
    N004 = graphene.List(N004Type,ds=graphene.String())
    N005 = graphene.List(N005Type,ds=graphene.String())
    N007 = graphene.List(N007Type)
    N010 = graphene.List(N010Type)
    N008 = graphene.List(N008Type)
    N011 = graphene.List(N011Type)
    N019 = graphene.List(N019Type)
    N013 = graphene.List(N013Type)
    N014 = graphene.List(N014Type)
    N001 = graphene.List(N001Type)
    V028 = graphene.List(V028Type)
    V029 = graphene.List(V029Type)
    V014 = graphene.List(V014Type)
    Prpg = graphene.List(PrpgType)
    PER = graphene.List(PERType)
    PR_PER = graphene.List(PR_PERType)
    Tip_pb = graphene.List(Tip_pbType)
    Met_pb = graphene.List(Met_pbType)
    V027 = graphene.List(V027Type)
    Trvnas = graphene.List(TrvnasType)
    F011_doc = graphene.List(F011Type,name=graphene.String())
    V002 = graphene.List(V002Type)
    anesthesia = graphene.List(anesthesiaType)
    V018_bpoms = graphene.List(V018_bpomsType)
    V019_bpoms = graphene.List(V019_bpomsType)
    # V018_sboms
    V019_sboms = graphene.List(V019_sbomsType)
    Tar_vt = graphene.List(Tar_vtType,isf=graphene.String(),
                            kod_stat=graphene.String(),
                            metod=graphene.String()
                           )
    group_kc_dkk = graphene.List(group_kc_dkkType,ksg=graphene.String())
    T006_ksg_code_usl_title = graphene.List(T006Type,ksg=graphene.String())
    Age_group = graphene.List(Age_groupType)



    def resolve_V005(*args, **kwargs):
        return V005.objects.filter(dateend=None).all()
    def resolve_Otde(root,info,*args, **kwargs):
        return otde.objects.filter(dateend=None).all()
        # user = MyUser.objects.get(user=info.context.user.id)
        # if user.ws.kod == 1:
        #     return otde.objects.filter(dateend=None,tipe=1).all()
        # elif user.ws.kod == 2:
        #     return otde.objects.filter(dateend=None,tipe=2).all()

    def resolve_Rab_ner(*args,**kwargs):
        return Rab_Ner.objects.filter(dateend=None).all()

    def resolve_T004(*args,**kwargs):
        return T004.objects.filter(dateend=None).all()

    def resolve_F003(*args,**kwargs):
        return F003.objects.filter(dateend=None).all()

    def resolve_Vrzb(*args,**kwargs):
        return Vrzb.objects.filter(dateend=None).all()

    def resolve_Oksm(*args, **kwargs):
        return Oksm.objects.filter(dateend=None).all()

    def resolve_Ds_list(*args, **kwargs):
        ds = kwargs.get('ds',None)
        return Ds.objects.filter(kod__icontains=ds,dateend=None).all()[:10]

    def resolve_Ds_name(*args,**kwargs):
        ds = kwargs.get('ds',None)
        return Ds.objects.filter(kod=ds, dateend=None).all()[:10]

    def resolve_V012(*args, **kwargs):
        return V012.objects.filter(id_iz__istartswith='1',dateend=None).all()

    def resolve_V009(*args, **kwargs):
        return V009.objects.filter(id_tip__istartswith='1',dateend=None).all()

    def resolve_V020(*args, **kwargs):
        return V020.objects.filter(dateend=None).all()

    def resolve_Vra(*args, **kwargs):
        return Vra.objects.filter(dateend=None).all()

    def resolve_Vra_name(*args,**kwargs):
        kod = kwargs.get('kod',None)
        return Vra.objects.filter(kod=kod,dateend=None).all()[:1]

    def resolve_V021_name(*args,**kwargs):
        spec = kwargs.get('spec',None)
        return V021.objects.filter(id_spec=spec,dateend=None).all()

    def resolve_PR_OSOB(*args, **kwargs):
        return PR_OSOB.objects.filter(dateend=None).order_by('-kod').all()


    def resolve_V001(*args,**kwargs):
        return V001.objects.filter(dateend=None).order_by('kod').all()


    def resolve_T006(root,info,*args, **kwargs):
        user = MyUser.objects.get(user=info.context.user.id)
        if user.ws.kod == 1:
            return T006.objects.filter(ksg__icontains='st',dateend=None).all()
        elif user.ws.kod == 2:
            return T006.objects.filter(ksg__icontains='ds', dateend=None).all()

    def resolve_Ab_Obsh(*args,**kwargs):
        return Ab_Obsh.objects.filter(dateend=None).all()

    def resolve_V001_name(*args,**kwargs):
        kod = kwargs.get('kod',None)
        return V001.objects.filter(kod=kod,dateend=None).all()

    def resolve_Pope(*args,**kwargs):
        return Pope.objects.filter(dateend=None).all()

    def resolve_Pope_name(*args,**kwargs):
        kod = kwargs.get('kod',None)
        return Pope.objects.filter(kod=kod,dateend=None).all()

    def resolve_Ab_Obsh_name(*args,**kwargs):
        kod = kwargs.get('kod',None)
        return Ab_Obsh.objects.filter(kod=kod,dateend=None).all()

    def resolve_Prli(*args,**kwargs):
        return Prli.objects.filter(dateend=None).all()

    def resolve_Trv(*args,**kwargs):
        return Trv.objects.filter(dateend=None).all()

    def resolve_Isfin(*args,**kwargs):
        return Isfin.objects.filter(dateend=None).all()

    def resolve_Skom(*args,**kwargs):
        return Skom.objects.filter(dateend=None).all()

    def resolve_F008(*args,**kwargs):
        return F008.objects.filter(dateend=None).all()

    def resolve_F011(*args,**kwargs):
        return F011.objects.filter(dateend=None).all()

    def resolve_N018(*args,**kwargs):
        return N018.objects.filter(dateend=None).all()

    def resolve_N002(*args,**kwargs):
        ds = kwargs.get('ds',None)
        return N002.objects.filter(ds_st=ds,dateend=None).all()

    def resolve_N003(*args, **kwargs):
        ds = kwargs.get('ds', None)
        return N003.objects.filter(ds_t=ds, dateend=None).all()

    def resolve_N004(*args, **kwargs):
        ds = kwargs.get('ds', None)
        return N004.objects.filter(ds_n=ds, dateend=None).all()

    def resolve_N005(*args, **kwargs):
        ds = kwargs.get('ds', None)
        return N005.objects.filter(ds_m=ds, dateend=None).all()

    def resolve_N007(*args,**kwargs):
        return N007.objects.filter(dateend=None).all()

    def resolve_N010(*args,**kwargs):
        return N010.objects.filter(dateend=None).all()

    def resolve_N008(*args,**kwargs):
        return N008.objects.filter(dateend=None).all()

    def resolve_N011(*args,**kwargs):
        return N011.objects.filter(dateend=None).all()

    def resolve_N019(*args,**kwargs):
        return N019.objects.filter(dateend=None).all()

    def resolve_N013(*args,**kwargs):
        return N013.objects.filter(dateend=None).all()

    def resolve_N014(*args,**kwargs):
        return N014.objects.filter(dateend=None).all()

    def resolve_N001(*args,**kwargs):
        return N001.objects.filter(dateend=None).all()

    def resolve_V028(*args,**kwargs):
        return V028.objects.filter(dateend=None).all()

    def resolve_V029(*args,**kwargs):
        return V029.objects.filter(dateend=None).all()

    def resolve_V014(*args,**kwargs):
        return V014.objects.filter(dateend=None).all()

    def resolve_Prpg(*args,**kwargs):
        return Prpg.objects.filter(dateend=None).all()

    def resolve_PER(*args,**kwargs):
        return PER.objects.filter(dateend=None).all()

    def resolve_PR_PER(*args,**kwargs):
        return PR_PER.objects.filter(dateend=None).all()

    def resolve_Tip_pb(*args,**kwargs):
        return Tip_pb.objects.filter(dateend=None).all()

    def resolve_Met_pb(*args,**kwargs):
        return Met_pb.objects.filter(dateend=None).all()

    def resolve_V027(*args,**kwargs):
        return V027.objects.filter(dateend=None).all()

    def resolve_Trvnas(*args,**kwargs):
        return Trvnas.objects.filter(dateend=None).all()

    def resolve_F011_doc(*args,**kwargs):
        name = kwargs.get('name',None)
        return F011.objects.filter(docname=name,dateend=None).all()

    def resolve_V002(*args,**kwargs):
        return V002.objects.filter(dateend=None).all()

    def resolve_anesthesia(*args,**kwargs):
        return anesthesia.objects.filter(dateend=None).all()

    def resolve_V018_bpoms(*args,**kwargs):
        return V018_bpoms.objects.filter(dateend=None).all()

    def resolve_V019_bpoms(*args,**kwargs):
        dateend__max = V019_bpoms.objects.aggregate(Max('dateend'))['dateend__max']
        return V019_bpoms.objects.filter(dateend=dateend__max).all()

    def resolve_V019_sboms(*args,**kwargs):
        return V019_sboms.objects.exclude(idhvid=None).filter(dateend=None).all().distinct()

    def resolve_Tar_vt(*args,**kwargs):
        isf = kwargs.get('isf',None)
        kod_stat = kwargs.get('kod_stat',None)
        metod = kwargs.get('metod',None)
        return Tar_vt.objects.filter(isf=isf,kod_stat=kod_stat,metod__icontains=metod,dateend=None).all()

    def resolve_group_kc_dkk(*args,**kwargs):
        ksg = kwargs.get('ksg',None)
        return group_kc_dkk.objects.filter(ksg_1=ksg,dateend=None).all()

    def resolve_T006_ksg_code_usl_title(root,info,*args, **kwargs):
        ksg = kwargs.get('ksg',None)
        user = MyUser.objects.get(user=info.context.user.id)
        if user.ws.kod == 1:
            return T006.objects.filter(ksg__icontains='st',code_usl_kz=ksg, dateend=None).all()
        elif user.ws.kod == 2:
            return T006.objects.filter(ksg__icontains='ds',code_usl_kz=ksg, dateend=None).all()
    
    def resolve_Age_group(*args,**kwsrgs):
        return Age_group.objects.all().order_by('id')


schema = graphene.Schema(query=Query)