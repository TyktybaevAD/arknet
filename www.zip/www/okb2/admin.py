from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.contrib.auth.models import User
#
# from okb2.models import *
# Register your models here.
from .models import (Statistics_type, F008, V006, V008, V014, F003, V009, V012, V010, V002, V020, V025, V021,
    V023, V026, V024, V001, Ab_Obsh, T003, T004, T005, Vra, T006, V027, V028, V029, N019, N018, N002, N003, N005, N007,
    N008, N010, N011, N001, N013, N014, N015, N016, N017, N020, dtrule, V016, V005, V017, N004, F011, otde, Ds, Rab_Ner,
    Oksm, Kladr, Kladr_T, Street, Street_T, Vrzb, CJ, V_LGOTY, Skom, Prpg, Ws, PR_PER, Trv, Trvnas, PY, PR_OSOB, Xosl,
    Posl, Aosl, Trs, Pope, Prli, Isfin, Tip_pb, Met_pb, PER, anesthesia,Age_group)

from .models import MyUser


class MyUser(admin.StackedInline):
    model = MyUser
    can_delete = False
    verbose_name_plural = 'Код подразделения'



class UserAdmin(UserAdmin):
    inlines = (MyUser,)

admin.site.unregister(User)
admin.site.register(User,UserAdmin)
admin.site.register(Statistics_type)

admin.site.register(F008)
admin.site.register(V006)
admin.site.register(V008)
admin.site.register(V014)
admin.site.register(F003)
admin.site.register(V009)
admin.site.register(V012)
admin.site.register(V010)
admin.site.register(V002)
# admin.site.register(V018_bpoms)
# admin.site.register(V018_sboms)
# admin.site.register(V019_bpoms)
# admin.site.register(V019_sboms)
admin.site.register(V020)
admin.site.register(V025)
admin.site.register(V021)
admin.site.register(V023)
admin.site.register(V026)
admin.site.register(V024)
admin.site.register(V001)
admin.site.register(Ab_Obsh)
admin.site.register(T003)
admin.site.register(T004)
admin.site.register(T005)
admin.site.register(Vra)
admin.site.register(T006)
admin.site.register(V027)
admin.site.register(V028)
admin.site.register(V029)
admin.site.register(N019)
admin.site.register(N018)
admin.site.register(N002)
admin.site.register(N003)
admin.site.register(N005)
admin.site.register(N007)
admin.site.register(N008)
admin.site.register(N010)
admin.site.register(N011)
admin.site.register(N001)
admin.site.register(N013)
admin.site.register(N014)
admin.site.register(N015)
admin.site.register(N016)
admin.site.register(N017)
admin.site.register(N020)
admin.site.register(dtrule)
admin.site.register(V016)
admin.site.register(V005)
admin.site.register(V017)
admin.site.register(N004)
admin.site.register(F011)
admin.site.register(otde)
admin.site.register(Ds)
admin.site.register(Rab_Ner)
admin.site.register(Oksm)
admin.site.register(Kladr)
admin.site.register(Kladr_T)
admin.site.register(Street)
admin.site.register(Street_T)
admin.site.register(Vrzb)
admin.site.register(CJ)
admin.site.register(V_LGOTY)
admin.site.register(Skom)
admin.site.register(Prpg)
admin.site.register(Ws)
admin.site.register(PR_PER)
admin.site.register(Trv)
admin.site.register(Trvnas)
admin.site.register(PY)
admin.site.register(PR_OSOB)
admin.site.register(Xosl)
admin.site.register(Posl)
admin.site.register(Aosl)
admin.site.register(Trs)
admin.site.register(Pope)
admin.site.register(Prli)
admin.site.register(Isfin)
admin.site.register(Tip_pb)
admin.site.register(Met_pb)
admin.site.register(PER)
admin.site.register(anesthesia)
admin.site.register(Age_group)