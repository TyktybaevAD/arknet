from hospital.models import *
from okb2.models import *
import uuid
from  datetime import datetime
import dbf
from  django.conf import settings
from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer
from django.core.mail import EmailMessage

class Create():
    def __init__(self, user, date_1, date_2,filename,type_reestr):
        # self.statistics_type = MyUser.objects.get(user_id=user).statistics_type
        self.user = user
        self.statistics_type = MyUser.objects.get(user_id=user)
        # self.date_1 = self.form_date(date_1) if ((date_1 != '') and (date_1 != None)) else None
        # self.date_2 = self.form_date(date_2) if ((date_2 != '') and (date_2 != None)) else None
        self.date_1 = date_1
        self.date_2 = date_2
        self.filename = filename
        self.temp_dir = 'temp'
        self.dir = '/'.join([settings.MEDIA_ROOT,self.temp_dir,str(user),''])
        self.type_reestr = type_reestr
        self.date_creat = datetime.now()
        self.user_group_name = 'hospital_createreestr_%s' % user

    # def form_date(self, date):
    #     d, m, g = str(date).split("-")
    #     try:
    #         return f'{g}-{m}-{d}'
    #     except:
    #         None

    def create(self):
        sluchays_list = self.get_sluchays()
        if len(sluchays_list) > 0:
            reestr = []
            count_1 = 100 / len(sluchays_list)
            sm = 0
            for n,sluchay in enumerate(sluchays_list):
                reestr.append(self.reestr(n+1,sluchay))
                sm += count_1
                async_to_sync(get_channel_layer().group_send)(self.user_group_name,
                                                              {'type': 'progress', 'text': sm})
            else:
                self.create_dbf(reestr)
                async_to_sync(get_channel_layer().group_send)(self.user_group_name,
                                                              {'type': 'report_data', 'text': 'Реестр сформирован'})
        else:
            self.create_dbf([])
            async_to_sync(get_channel_layer().group_send)(self.user_group_name,
                                                          {'type': 'progress', 'text': 100.0000})
            async_to_sync(get_channel_layer().group_send)(self.user_group_name,
                                                          {'type': 'report_data', 'text': 'Реестр сформирован'})

    def get_sluchays(self):
        
        sluchays = Sluchay.objects.values('id').filter(datp__gte=self.date_1,
                                                       datv__lte=self.date_2,
                                                       statistics_type=self.statistics_type.statistics_type)
        print(sluchays)
        sluchays_list = []
        for sluchay in sluchays:
            sluchays_list.append(Sluchay.objects.get(id=sluchay['id']))
        return  sluchays_list

    def get_patient(self, sluchay):
        return Patient.objects.get(sluchay=sluchay.id)

    def get_oper_1(self,sluchay):
        if sluchay.oper != None:
            oper = sluchay.oper.values('id').filter(pop=True)
            if len(oper) > 0:
                try:
                    oper = Oper.objects.get(id=oper[0]['id'])
                    return oper
                except Oper.DoesNotExist:
                    return None
        return None

    def get_patient_p(self,patient):
        if patient != None:
            if patient.patient_p != None:
                return patient.patient_p
            else:
                return None
        return None


    def get_vidpom(self, sluchay):
        if sluchay.iddokt != None and sluchay.iddokt.v021 in ['76', '49']:
            return 12
        elif sluchay.vds != None and sluchay.vds.vds != None:
            kod = sluchay.vds.vds.kod
            if str(kod) == '5' or kod == '7' or kod == 'Д':
                return 32
            return 31
        else:
            return 31

    def get_novor(self, patient, sluchay):
        if (sluchay.vds != None and sluchay.vds.ctkom != None and sluchay.vds.ctkom.kod == 888) and (patient.nvs == 'Д' and (sluchay.datp - patient.datr).days < 28):
            novor = str(patient.pol.id_pol) if patient.pol != None else ''
            novor += str(patient.datr.day()) if patient.datr != None else ''
            novor += str(patient.datr.month()) if patient.datr != None else ''
            novor += str(patient.datr.year())[2:3] if patient.datr != None else ''
            novor += '01'
            return novor
        return None

    def get_det(self,sluchay):
        if (sluchay.iddokt != None and sluchay.iddokt.v002 != None ):
            if (int(sluchay.iddokt.v002) >= 17 and int(sluchay.iddokt.v002) <= 21) \
            or (int(sluchay.iddokt.v002) == 86) or (int(sluchay.iddokt.v002) == 55) \
            or (int(sluchay.iddokt.v002) == 68):
                return 1
            else:
                return 0

        return 0

    def get_code_md(self,oper):
        if isinstance(oper,Oper):
            try:
                vra = Vra.objects.get(kod=oper.kodx.kod)
            except Vra.DoesNotExist:
                    return '720002 '
            except Vra.MultipleObjectsReturned:
                    return None
            return '720002 '+ str(vra.t005)
        return '720002 '
        # if sluchay.oper != None:
        #     oper = sluchay.oper.values('kodx').filter(pop=True)
        #     if len(oper) > 0:
        #         try:
        #             vra = Vra.objects.get(kod=oper[0]['kodx'])
        #         except Vra.DoesNotExist:
        #             return None
        #         except Vra.MultipleObjectsReturned:
        #             return None
        #         return '720002'+ str(vra.t005)
        #     return None
        # return None

    def get_idsp(self,sluchay):
        idsp = 33
        if sluchay.vds != None and sluchay.vds.vds != None:
            kod = sluchay.vds.vds.kod
            if str(kod) == '5' or kod == '7' or kod == 'Д':
                idsp = 32
            elif str(kod) == '0' or kod == '':
                idsp = 33
        return idsp

    def get_tarif(self,sluchay):

        if (sluchay.code_usl != None):
            tarif = Tarif.objects.values('id').filter(Code_usl=sluchay.code_usl,
                                              Ur='3.2',
                                              dateend=None)
            try:
                tarif = Tarif.objects.get(id=tarif[0]['id'])
            except Tarif.DoesNotExist:
                tarif = None

            if tarif != None:
                return  tarif
            return  None
        return None

    def get_vid_vme(self,oper):
        if oper != None:
            return oper.kod_op.kod if (oper.kod_op != None and oper.kod_op.kod != None) else ''

    def get_napr(self,sluchay):
        if sluchay.napr != None:
            return sluchay.napr
        return  None

    def get_npl(self,sluchay):
        if sluchay.rslt != None:
            if (sluchay.rslt.id_tip == 105 or sluchay.rslt.id_tip == 106):
                return 3
            elif (sluchay.rslt.id_tip == 107):
                return 1
            elif (sluchay.rslt.id_tip == 108):
                return 2
            elif (sluchay.rslt.id_tip == 110):
                return 3
            elif (sluchay.rslt.id_tip == 102):
                return 3
            elif (sluchay.rslt.id_tip == 104):
                return 3
        elif sluchay.ksg_osn != None:
            if sluchay.ksg_osn.ksg == 'st36.004':
                return 3
        elif sluchay.le_vr != None:
            return 3 if (sluchay.le_vr.kd != None and sluchay.le_vr.kd != '' and int(sluchay.le_vr.kd) < 3) else None
        return None

    def get_comentu(self,code_usl,kd,npl):
        if npl != None:
            if kd != None and int(kd) <= 3:
                if code_usl != None and int(code_usl[6]) == 1:
                    return '0.5'
                return '0.9'
            else:
                if code_usl != None and int(code_usl[6]) == 1:
                    return '0.8'
                return '1.0'
        return None



    def get_cons(self,sluchay):
        cons = sluchay.cons
        if cons != None:
            p = cons.pr_cons.id_cons if (cons.pr_cons != None) else 0
            d = cons.dt_cons.strftime('%d.%m.%Y') if (cons.dt_cons != None and cons.dt_cons != '') else 0
            return str(p)+'/'+str(d)
        return None

    def get_comentsl(self,sluchay,le_trv):
        comentsl = None
        if isinstance(sluchay,Sluchay):
            code_usl = sluchay.code_usl.kod if (sluchay.code_usl != None and sluchay.code_usl.kod != None) else None
            if code_usl != None and str(code_usl) == '1.1.3.150':
                comentsl = '4'
        if isinstance(le_trv,Le_trv):
            comentsl = '11'
        return comentsl

    def get_v_tp(self,sluchay):
        if sluchay.vds != None and sluchay.vds.vds != None:
            kod = sluchay.vds.vds.kod
            if str(kod) == '5' or kod == '7':
                return 2
            elif str(kod) == 'Д':
                return 1
            return None
        return None

    def get_vb_p(self,rslt,vb_s):
        if rslt != None:
            if str(rslt) in ['101','102','110']:
                return 1
        elif isinstance(vb_s,Vb_s):
            return 1
        else:
            return None

    def get_for_pom(self,sluchay,oper):
        if str(sluchay.code_usl) == '1.1.3.150':
            return 2
        elif isinstance(oper,Oper):
            return oper.goc.id_tip if (oper.goc != None) else None
        return None


    def reestr(self,n,sluchay):
        # Если тип code_usl хирургический (с опед зачен) добавляем еще одну запись BLOCK_CD = U
        # Записи дублируються с BLOCK_CD = S reestr.copy()
        #Если у нас онко то добавляем к основной записи BLOCK_CD = O и BLOCK_CD = N
        #И также дублируем BLOCK_CD = S reestr.copy()
        # Но при этом меняем значения в нужных местах
        reestr_list = []
        patient = self.get_patient(sluchay)
        le_vr = sluchay.le_vr
        oper_1 = self.get_oper_1(sluchay)
        patient_p = self.get_patient_p(patient)
        napr = self.get_napr(sluchay)
        tarif = self.get_tarif(sluchay)
        onk_sl = sluchay.onk_sl
        onk_usl = sluchay.onk_usl
        b_diag = sluchay.b_diag
        le_trv = sluchay.le_trv
        vb_s =  Vb_s.objects.get(id=sluchay.vb_s.values('id')[0]['id']) if (sluchay.vb_s.count() > 0) else None

        pac = uuid.uuid1()
        reestr = dict()
        reestr['BLOCK_CD'] = 'S'  # BLOCK_CD
        reestr['CODE_MO'] = '720002'  # CODE_MO
        reestr['FAM'] = patient.fam.upper() if patient.fam != None else None  # FAM
        reestr['IM'] = patient.im.upper() if patient.im != None else None  # IM
        reestr['OT'] = patient.ot.upper() if patient.ot != None else None  # OT
        reestr['W'] = patient.pol.id_pol if patient.pol != None else None  # W
        reestr['DR'] = patient.datr if patient.datr != None and patient.datr != '' else None  # DR
        reestr['DOST'] = None  # DOST
        reestr['TEL'] = None  # TEL
        reestr['ID_PAC'] = f'{pac}'  # ID_PAC
        reestr['VPOLIS'] = sluchay.vds.t_pol.id_tip if (sluchay.vds != None) and (sluchay.vds.t_pol != None) else None  # VPOLIS
        reestr['SPOLIS'] = sluchay.vds.sctp if (sluchay.vds != None) and (sluchay.vds.sctp != None) else None  # SPOLIS
        reestr['NPOLIS'] = sluchay.vds.nctp if (sluchay.vds != None) and (sluchay.vds.nctp != None) else None  # NPOLIS
        reestr['ST_OKATO'] = None  # ST_OKATO ?????
        # reestr.append(sluchay.vds.ctkom.kod if (sluchay.vds != None and sluchay.vds.ctkom != None) else '')
        reestr['SMO'] = str(sluchay.vds.ctkom.smo).split('.')[0] if (sluchay.vds != None) and (sluchay.vds.ctkom != None) and (sluchay.vds.ctkom.smo != None) else None  # SMO
        reestr['SMO_OGRN'] = str(sluchay.vds.ctkom.ogrn).split('.')[0] if (sluchay.vds != None) and (sluchay.vds.ctkom != None) and (sluchay.vds.ctkom.ogrn != None) else None  # SMO_OGRN
        reestr['SMO_OK'] = str(sluchay.vds.ctkom.smo_okato).split('.')[0] if (sluchay.vds != None) and (sluchay.vds.ctkom != None)  else None  # SMO_OK
        reestr['SMO_NAM'] = sluchay.vds.ctkom.naim_n if (sluchay.vds != None) and (sluchay.vds.ctkom != None) else None  # SMO_NAM
        reestr['INV'] = None  # INV
        reestr['NOVOR'] =self.get_novor(patient, sluchay)  # NOVOR
        reestr['VNOV_D'] = patient.vec if patient.vec != None else None  # VNOV_D
        reestr['IDCASE'] = n  # IDCASE
        reestr['USL_OK'] = 1  # USL_OK
        reestr['VIDPOM'] = self.get_vidpom(sluchay)  # VIDPOM
        reestr['FOR_POM'] = self.get_for_pom(sluchay,oper_1) # FOR_POM
        reestr['VID_HMP'] =sluchay.vid_hmp if (sluchay.vid_hmp != None and sluchay.vid_hmp != '') else None  # VID_HMP
        reestr['METOD_HMP'] = sluchay.metod_hmp if (sluchay.metod_hmp != None and sluchay.metod_hmp != '') else None  # METOD_HMP
        reestr['NPR_MO'] = sluchay.lpy.mo if sluchay.lpy != None else None  # NPR_MO?
        reestr['LPU'] = '720002'  # LPU
        reestr['LPU_1'] = str(int(float(sluchay.otd.t007))) if (sluchay.otd != None and sluchay.otd.t007 != None and sluchay.otd.t007 != '')  else None  # LPU_1
        reestr['PODR'] = str(int(float(sluchay.otd.t013))) if (sluchay.otd != None and sluchay.otd.t013 != None and sluchay.otd.t013 != '')  else None  # PODR
        reestr['PROFIL'] = sluchay.iddokt.v002 if (sluchay.iddokt != None and sluchay.iddokt.v002 != None) else None  # PROFIL
        reestr['DET'] = self.get_det(sluchay)  # DET
        reestr['TAL_D'] = sluchay.npr_date if (sluchay.npr_date != None and sluchay.npr_date != '') else None  # TAL_D
        reestr['TAL_P'] = sluchay.npr_date if (sluchay.npr_date != None and sluchay.npr_date != '') else None  # TAL_P
        reestr['TAL_NUM'] = None  # TAL_NUM
        reestr['NHISTORY'] = sluchay.nib if (sluchay.nib != None and sluchay.nib != '') else None  # NHISTORY
        reestr['P_PER'] = sluchay.p_per.kod if (sluchay.p_per != None and sluchay.p_per.kod != None) else None # P_PER
        reestr['EXTR'] = sluchay.goc.id_tip if (sluchay.goc != None and sluchay.goc.id_tip != None) else None  # EXTR
        reestr['PRIV'] = patient.in_t.kod if (patient.in_t != None and patient.in_t.kod != None) else None  # PRIV
        reestr['DATE_1'] = sluchay.datp if (sluchay.datp != None and sluchay.datp != None) else None  # DATE_1
        reestr['DATE_2'] = sluchay.datv if (sluchay.datv != None and sluchay.datv != '') else None  # DATE_2
        reestr['DS0'] = sluchay.ds_0.kod if (sluchay.ds_0 != None and sluchay.ds_0.kod != None) else None #DS0
        reestr['DS1'] = sluchay.dskz.kod if (sluchay.dskz != None and sluchay.dskz.kod != None) else None #DS1
        reestr['DS2'] = sluchay.dsc.kod if (sluchay.dsc != None and sluchay.dsc.kod != None) else None #DS2
        reestr['DS3'] = sluchay.dson.kod if (sluchay.dson != None and sluchay.dson.kod != None) else None #DS3
        reestr['VNOV_M'] = patient.vec if (patient.vec != None and patient.vec != '') else None #VNOV_M
        reestr['CODE_MES1'] = sluchay.ksg_osn.ksg if (sluchay.ksg_osn != None and sluchay.ksg_osn.ksg != None) else None #CODE_MES1
        reestr['CODE_MES2'] = sluchay.ksg_sop.ksg if (sluchay.ksg_sop != None and sluchay.ksg_sop.ksg != None) else None #CODE_MES2
        reestr['RSLT'] = sluchay.rslt.id_tip if (sluchay.rslt != None and sluchay.rslt.id_tip != None) else None #RSLT
        reestr['ISHOD'] = sluchay.icx.id_iz if (sluchay.icx != None and sluchay.icx.id_iz != None) else None #ISHOD
        reestr['PRVS'] = sluchay.iddokt.v021 if (sluchay.iddokt != None and sluchay.iddokt.v021 != None) else None #PRVS
        reestr['IDDOKT'] = '720002 '+str(sluchay.iddokt.t005) if (sluchay.iddokt != None and sluchay.iddokt.t005 != None) else None #IDDOKT
        reestr['CODE_MD'] = self.get_code_md(oper_1) #CODE_MD
        reestr['OS_SLUCH'] = None #OS_SLUCH ??? Нужно разобраться как формируется поле Скорее всего берется из операции Особ-ти операции
        reestr['IDSP'] = self.get_idsp(sluchay) #IDSP
        reestr['ED_COL'] = 1 #ED_COL
        reestr['KOL_USL'] = 1 #KOL_USL
        reestr['KD'] = le_vr.kd if (le_vr != None and le_vr.kd != None) else None #KD
        reestr['KD_Z'] = le_vr.kd if (le_vr != None and le_vr.kd != None) else None #KD_Z
        reestr['TARIF'] = tarif.Tarif.replace(',','.') if (tarif != None) else None #TARIF
        reestr['SUMV'] = tarif.Tarif.replace(',','.') if (tarif != None) else None #SUMV
        reestr['COMENTSL'] = self.get_comentsl(sluchay,le_trv) #COMENTSL

        if (sluchay.code_usl != None and sluchay.code_usl.kod != None):
            if int(sluchay.code_usl.kod[6]) == 1:
                reestr['VID_VME'] =  None #VID_VME
            else:
                reestr['VID_VME'] =  self.get_vid_vme(oper=oper_1) #VID_VME
        else:
            reestr['VID_VME'] =  None #VID_VME

        reestr['CODE_USL'] = sluchay.code_usl.kod if (sluchay.code_usl != None and sluchay.code_usl.kod != None) else None #CODE_USL
        reestr['FAM_P'] = patient_p.fam_p if (patient_p != None and patient_p.fam_p) else None #FAM_P
        reestr['IM_P'] = patient_p.im_p if (patient_p != None and patient_p.im_p) else None #IM_P
        reestr['OT_P'] = patient_p.ot_p if (patient_p != None and patient_p.ot_p) else None #OT_P
        reestr['W_P'] = patient_p.pol.id_pol if (patient_p != None and patient_p.pol != None and patient_p.pol.id_pol != None) else None #W_P
        reestr['DR_P'] = patient_p.datr if (patient_p != None and patient_p.datr != None and patient_p.datr != '') else None  #DR_P # В программе
        reestr['DOST_P'] = None#DOST_P
        reestr['MR'] = patient.m_roj if (patient.m_roj != None ) else None #MR
        reestr['DOCTYPE'] = str(patient.udl.id_doc) if (patient.udl != None) else None #DOCTYPE
        reestr['DOCSER'] = patient.s_pasp if patient.s_pasp != None else None #DOCSER
        reestr['DOCNUM'] = patient.n_pasp if patient.n_pasp != None else None #DOCNUM
        reestr['DOCDATE'] = patient.docdate if (patient.docdate != None and patient.docdate != '') else None #DOCDATE
        reestr['DOCORG'] = patient.docorg if patient.docorg != None else None #DOCORG
        reestr['SNILS'] = str(patient.ss) if patient.ss != None else None #SNILS
        reestr['OKATOG'] = patient.okatog[:11] if patient.okatog != None else None #OKATOG
        reestr['OKATOP'] = patient.okatop[:11] if patient.okatop != None else None #OKATOP
        reestr['YEAR'] = self.date_creat.year #YEAR
        reestr['MONTH'] = self.date_creat.month #MONTH
        reestr['NSCHET'] = None #NSCHET
        reestr['DSCHET'] = None #DSCHET
        reestr['PLAT'] = str(72) if (reestr['SMO'] != None and str(reestr['SMO'])[:2] == '72') else None    #PLAT
        reestr['V_TP'] = self.get_v_tp(sluchay) #V_TP
        reestr['PR_NOV'] = None #PR_NOV
        reestr['NAZ_V'] = None #NAZ_V
        reestr['NAPR_USL'] = napr.napr_usl.kod if (napr != None and napr.napr_usl != None) else None #NAPR_USL
        reestr['NAPR_DATE'] = napr.naprdate if (napr != None and napr.naprdate != None and napr.naprdate != '') else None #NAPR_DATE
        reestr['NAPR_MO'] = napr.napr_mo.mo if (napr != None and napr.napr_mo != None) else None  #NAPR_MO
        reestr['NAPR_V'] = napr.napr_v.id_vn if (napr != None and napr.napr_v != None) else None #NAPR_V ++++++
        reestr['NPL'] = self.get_npl(sluchay) #NPL
        reestr['NPL_CF'] = None #NPL_CF
        reestr['COMENTU'] = self.get_comentu(reestr['CODE_USL'],
                                             reestr['KD'],
                                             reestr['NPL']
                                             )#COMENTU
        reestr['SL_ID'] = str(n) #SL_ID
        reestr['IDSERV'] = str(n) #IDSERV
        reestr['MSE'] = None #MSE
        reestr['NPR_DATE'] = sluchay.npr_date if (sluchay.npr_date != None and sluchay.npr_date != '') else None #NPR_DATE ???
        reestr['PROFIL_K'] = le_vr.prof_k.idk_pr if (le_vr != None and le_vr.prof_k != None) else None #PROFIL_K
        reestr['P_CEL'] = str(2.6) if (reestr['CODE_USL'] != None and str(reestr['CODE_USL']) == '1.1.3.150') else None   #str(2.6) #P_CEL ???
        reestr['DN'] = None #DN - dn1:=DN не понятно от куда брать значения
        reestr['REAB'] =  1 if (reestr['CODE_USL'] != None and str(reestr['CODE_USL'])[:6] == '4') else None   #REAB
        reestr['VB_P'] = self.get_vb_p(reestr['RSLT'],vb_s) #VB_P
        reestr['N_KSG'] = sluchay.ksg_osn.ksg if (sluchay.ksg_osn != None and sluchay.ksg_osn.ksg != None) else None # ??? N_KSG
        reestr['VER_KSG'] = self.date_creat.year # ??? VER_KSG
        reestr['KSG_PG'] = None   #KSG_PG поле не существует ??? или не заполняется
        reestr['KOEF_Z'] = tarif.KOEF_Z if (tarif != None) else None #KOEF_Z
        reestr['KOEF_UP'] = tarif.Koef_Up if(tarif != None) else None#KOEF_UP
        reestr['BZTSZ'] = tarif.BZTSZ.replace(',','.') if (tarif != None) else None  #BZTSZ
        reestr['KOEF_D'] = tarif.KOEF_D.replace(',','.') if (tarif != None) else None  #KOEF_D
        reestr['KOEF_U'] = tarif.KOEF_U.replace(',','.') if (tarif != None) else None #KOEF_U
        reestr['CRIT'] = sluchay.oopkk.kod if (sluchay.oopkk != None) else None #CRIT
        reestr['SL_K'] = 0 # ??? SL_K
        reestr['C_ZAB'] = sluchay.c_zab.id_cz if (sluchay.c_zab != None) else None #C_ZAB
        reestr['DS_ONK'] = 0 #DS_ONK
        reestr['ONK_SL'] = 1 if (reestr['DS1'] != None and reestr['DS1'][:1] == 'C') else 0 #ONK_SL
        reestr['DS1_T'] = onk_sl.ds1_t.id_reas if (onk_sl != None and onk_sl.ds1_t != None) else None #DS1_T
        reestr['STAD'] = onk_sl.stad.id_st if (onk_sl != None and onk_sl.stad != None) else None #STAD
        reestr['ONK_T'] = onk_sl.onk_t.kod_t if (onk_sl != None and onk_sl.onk_t != None) else None #ONK_T
        reestr['ONK_N'] = onk_sl.onk_n.kod_n if (onk_sl != None and onk_sl.onk_n != None) else None #ONK_N
        reestr['ONK_M'] = onk_sl.onk_m.kod_m if (onk_sl != None and onk_sl.onk_m != None) else None #ONK_M
        reestr['MTSTZ'] = onk_sl.mtstz if (onk_sl != None and onk_sl.mtstz != None and onk_sl.mtstz != '') else None #MTSTZ
        reestr['SOD'] = None #SOD
        reestr['K_FR'] = None #K_FR
        reestr['WEI'] = None #WEI я
        reestr['HEI'] = None #HEI
        reestr['BSA'] = None #BSA
        reestr['B_DIAG'] = None #  B_DIAG
        reestr['B_PROT'] = None #B_PROT
        reestr['CONS'] = self.get_cons(sluchay) #CONS
        reestr['ONKUSL_ID'] = None #ONKUSL_ID Заполняется так S = 0;O = 1;N = 2; O;N - Онкология
        reestr['USL_TIP'] = onk_usl.usl_tip.id_tlech if (onk_usl != None and onk_usl.usl_tip != None) else None #USL_TIP
        reestr['HIR_TIP'] = onk_usl.hir_tip.id_thir if (onk_usl != None and onk_usl.hir_tip != None) else None #HIR_TIP
        reestr['LEK_TIP_L'] = None #LEK_TIP_L
        reestr['LEK_TIP_V'] = None #LEK_TIP_V
        reestr['LUCH_TIP'] = None #LUCH_TIP
        reestr['PPTR'] = None #PPTR
        reestr['REGNUM'] = None #REGNUM
        reestr['CODE_SH'] = None #CODE_SH
        reestr['DATE_INJ'] = None #DATE_INJ
        reestr['DATE_IN'] = sluchay.datp if (sluchay.datp != None and sluchay.datp != None) else None #DATE_IN
        reestr['DATE_OUT'] = sluchay.datp if (sluchay.datp != None and sluchay.datp != None) else None #DATE_OUT
        reestr['PRSCSDTBEG'] = None #PRSCSDTBEG
        reestr['ADRES'] = patient.adr #ADRES
        reestr_list.append(reestr)

        # При определенных ксловиях нужно будит копировать полностью словарь и поменять там пару значения
        # reestr_u = reestr.copy()
        # reestr_u['BLOCK_CD'] = 'U'
        # reestr_list.append(reestr_u)

        if (sluchay.code_usl != None and sluchay.code_usl.kod != None):
            if int(sluchay.code_usl.kod[6]) == 1:
                reestr_u = reestr.copy()
                reestr_u['BLOCK_CD'] = 'U'
                reestr_u['VID_VME'] =  self.get_vid_vme(oper=oper_1) #VID_VME
                reestr_list.append(reestr_u)

        if (reestr['DS1'] != None and reestr['DS1'][:1] == 'C'):
             reestr_o = reestr.copy()
             reestr_o['BLOCK_CD'] = 'O'
             reestr_list.append(reestr_o)
             reestr_n = reestr.copy()
             reestr_n['BLOCK_CD'] = 'N'
             reestr_list.append(reestr_n)

        return reestr_list

    def create_dbf(self,reestr):
        self.dir += self.filename if len(self.filename) > 0 else 'reestr_'+ str(self.user)
        table = dbf.Table('{0}.dbf'.format(self.dir),
                          'BLOCK_CD C(1);'
                          'CODE_MO C(6);'
                          'FAM C(40);'
                          'IM C(40);'
                          'OT C(40);'
                          'W N(1,0);'
                          'DR D;'
                          'DOST C(48);'
                          'TEL C(40);'
                          'ID_PAC C(36);'
                          'VPOLIS N(1,0);'
                          'SPOLIS C(20);'
                          'NPOLIS C(20);'
                          'ST_OKATO C(5);'
                          'SMO C(5);'
                          'SMO_OGRN C(15);'
                          'SMO_OK C(5);'
                          'SMO_NAM C(100);'
                          'INV N(1,0);'
                          'NOVOR C(9);'
                          'VNOV_D N(4,0);'
                          'IDCASE N(11,0);'
                          'USL_OK N(2,0);'
                          'VIDPOM N(4,0);'
                          'FOR_POM N(1,0);'
                          'VID_HMP C(20);'
                          'METOD_HMP C(20);'
                          'NPR_MO C(20);'
                          'LPU C(6);'
                          'LPU_1 C(8);'
                          'PODR C(12);'
                          'PROFIL N(3,0);'
                          'DET N(1,0);'
                          'TAL_D D;'
                          'TAL_P D;'
                          'TAL_NUM C(20);'
                          'NHISTORY C(50);'
                          'P_PER N(1,0);'
                          'EXTR N(1,0);'
                          'PRIV N(3,0);'
                          'DATE_1 D;'
                          'DATE_2 D;'
                          'DS0 C(10);'
                          'DS1 C(10);'
                          'DS2 C(100);'
                          'DS3 C(100);'  
                          'VNOV_M C(32);'
                          'CODE_MES1 C(20);'
                          'CODE_MES2 C(20);'
                          'RSLT N(3,0);'
                          'ISHOD N(3,0);'
                          'PRVS N(4,0);'
                          'IDDOKT C(25);'
                          'CODE_MD C(25);'
                          'OS_SLUCH C(20);'
                          'IDSP N(2,0);'
                          'ED_COL N(5,2);'
                          'KOL_USL N(6,2);'
                          'KD N(6,2);'
                          'KD_Z N(6,2);'
                          'TARIF N(15,2);'
                          'SUMV N(15,2);'
                          'COMENTSL C(100);'
                          'VID_VME C(15);'
                          'CODE_USL C(20);'
                          'FAM_P C(40);'
                          'IM_P C(40);'
                          'OT_P C(40);'
                          'W_P N(1,0);'
                          'DR_P D;'
                          'DOST_P C(48);'
                          'MR C(200);'
                          'DOCTYPE C(2);'
                          'DOCSER C(10);'
                          'DOCNUM C(20);'
                          'DOCDATE D;'
                          'DOCORG C(100);'
                          'SNILS C(14);'
                          'OKATOG C(11);'
                          'OKATOP C(11);'
                          'YEAR N(4,0);'
                          'MONTH N(2,0);'
                          'NSCHET C(15);'
                          'DSCHET D;'
                          'PLAT C(5);'
                          'V_TP N(1,0);'
                          'PR_NOV N(1,0);'
                          'NAZ_V N(1,0);'
                          'NAPR_USL C(15);'
                          'NAPR_DATE D;'
                          'NAPR_MO C(6);'
                          'NAPR_V N(1,0);'
                          'NPL N(1,0);'
                          'NPL_CF N(6,2);'
                          'COMENTU C(20);'
                          'SL_ID C(36);'
                          'IDSERV C(36);'
                          'MSE N(1,0);'
                          'NPR_DATE D;'
                          'PROFIL_K N(3,0);'
                          'P_CEL C(3);'
                          'DN N(1,0);'
                          'REAB N(1,0);'
                          'VB_P N(1,0);'
                          'N_KSG C(20);'
                          'VER_KSG N(4,0);'
                          'KSG_PG N(1,0);'
                          'KOEF_Z N(8,5);'
                          'KOEF_UP N(8,5);'
                          'BZTSZ N(10,2);'
                          'KOEF_D N(8,5);'
                          'KOEF_U N(8,5);'
                          'CRIT C(10);'
                          'SL_K N(1,0);'
                          'C_ZAB N(1,0);'
                          'DS_ONK N(1,0);'
                          'ONK_SL N(1,0);'
                          'DS1_T N(1,0);'
                          'STAD N(3,0);'
                          'ONK_T N(3,0);'
                          'ONK_N N(3,0);'
                          'ONK_M N(3,0);'
                          'MTSTZ N(1,0);'
                          'SOD N(5,2);'
                          'K_FR N(2,0);'
                          'WEI N(5,1);'
                          'HEI N(3,0);'
                          'BSA N(4,2);'
                          'B_DIAG C(254);'
                          'B_PROT C(254);'
                          'CONS C(254);'
                          'ONKUSL_ID N(4,0);'
                          'USL_TIP N(1,0);'
                          'HIR_TIP N(1,0);'
                          'LEK_TIP_L N(1,0);'
                          'LEK_TIP_V N(1,0);'
                          'LUCH_TIP N(1,0);'
                          'PPTR N(1,0);'
                          'REGNUM C(6);'
                          'CODE_SH C(10);'
                          'DATE_INJ C(254);'
                          'DATE_IN D;'
                          'DATE_OUT D;'
                          'PRSCSDTBEG D;'
                          'ADRES C(200);'
                          , codepage='cp866')

        table.open(mode=dbf.READ_WRITE)
        for r in reestr:
            for all in r:
                table.append(all)
        table.close()



        ## Отпавка сообщения на почту пользователю с прик.файлом
        ## Можно прикрутить протокол и его отправить отправителю

        ## Через модель Os можно скопировать файл и поместить в конкретную директорию

        # email = EmailMessage("Hello is Django", 'message_arknet', ' arknet@okb2-tmn.ru', ['tyktybaev_ad@okb2-tmn.ru','voroniuk_sp@okb2-tmn.ru'])
        # file = dir + '{0}.dbf'.format('reestr_test')
        # print(file)
        # email.attach_file(str(file).replace("'",''))
        # email.send()