from  openpyxl.styles import Font,Alignment,Border,Side

import hospital.models
from services.hospital.patient import Patients
from okb2.models import *
from datetime import datetime
import time
class Reports(Patients):
    def __init__(self,user,request):
        super().__init__(user, request)

    def sh_title(self,sheet,text):
        sheet.merge_cells("A2:I2")
        sheet["A2"].value = text
        sheet["A2"].alignment = Alignment(horizontal="center", vertical="center")
        sheet.merge_cells("A3:I3")
        sheet["A3"].value = self.user.statistics_type.name
        sheet["A3"].alignment = Alignment(horizontal="center", vertical="center")
        sheet.merge_cells("A4:I4")
        sheet["A4"].value = f'За период с {self.date_1.strftime("%d.%m.%Y")} по {self.date_2.strftime("%d.%m.%Y")}'
        sheet["A4"].alignment = Alignment(horizontal="center", vertical="center")


    def filter(self,*args,**kwargs):
        filters,sluchays = args
        f_ = None
        f = []
        # print(filters)
        # print(sluchays)
        for sluchay in sluchays:
            if filters.get('datv',None) != None:
                datv_1,datv_2 = filters.get('datv').values()
                if datv_1 != '' and datv_2 != '':
                    datv_1 = datetime.strptime(datv_1, '%Y-%m-%d').date()
                    datv_2 = datetime.strptime(datv_2,'%Y-%m-%d').date()
                    f_ = datv_1 >= sluchay['sluchay'].datv <= datv_2
                    # if f_ == False : continue
            if filters.get('datp',None) != None:
                datp_1,datp_2 = filters.get('datp').values()
                if datp_1 != '' and datp_2 != '':
                    datp_1 = datetime.strptime(datp_1, '%Y-%m-%d').date()
                    datp_2 = datetime.strptime(datp_2,'%Y-%m-%d').date()
                    f_ = datp_1 >= sluchay['sluchay'].datp <= datp_2
                    # if f_ == False: continue
            if filters.get('otd', None) != None:
                if filters.get('otd')['otd'] != '':
                    otd = otde.objects.get(naim=filters.get('otd')['otd'])
                    f_ =  sluchay['sluchay'].otd.id == otd.id if sluchay['sluchay'].otd != None else False
                    # if f_ == False: continue
            if filters.get('prof', None) != None:
                if sluchay['le_vr'] != None :
                    if filters.get('prof')['prof'] != '':
                        prof = V020.objects.get(k_prname=filters.get('prof')['prof'])
                        f_ = sluchay['le_vr'].prof_k.id == prof.id if sluchay['le_vr'].prof_k != None else False
                        # if f_ == False: continue
            if filters.get('fam', None) != None:
                if filters.get('fam')['fam'] != '':
                    f_ = sluchay['patient'].fam == filters.get('fam')['fam']
                    # if f_ == False: continue
            if filters.get('im', None) != None:
                if filters.get('im')['im'] != '':
                    f_ = sluchay['patient'].im == filters.get('im')['im']
                    # if f_ == False: continue
            if filters.get('ot', None) != None:
                if filters.get('ot')['ot'] != '':
                    f_ = sluchay['patient'].ot == filters.get('ot')['ot']
                    # if f_ == False: continue
            if filters.get('pol', None) != None:
                if filters.get('pol')['pol'] != '':
                    pol = V005.objects.get(polname=filters.get('pol')['pol'])
                    f_ = sluchay['patient'].pol.id == pol.id if sluchay['patient'].pol != None else False
                    # if f_ == False: continue
            if filters.get('type_lgots',None) != None:
                pass
            if filters.get('in_t', None) != None:
                if filters.get('in_t')['in_t'] != '':
                    in_t = T004.objects.get(name=filters.get('in_t')['in_t'])
                    f_ = sluchay['patient'].in_t.id == in_t.id if sluchay['patient'].in_t != None else False
                    # if f_ == False: continue
            if filters.get('r_n', None) != None:
                if filters.get('r_n')['r_n'] != '':
                    r_n = Rab_Ner.objects.get(naim=filters.get('r_n')['r_n'])
                    f_ = sluchay['patient'].r_n.id == r_n.id if sluchay['patient'].r_n != None else False
                    # if f_ == False: continue
            if filters.get('age_group',None) != None:
                if filters.get('age_group')['age_group'] != '':
                    age_group = Age_group.objects.get(name=filters.get('age_group')['age_group'])
                    f_ = self.age_group(sluchay['patient'].vs,
                                        sluchay['patient'].nvs,
                                        sluchay['patient'].datr,
                                        age_group)
                    # if f_ == False: continue
            if filters.get('goc', None) != None:
                if filters.get('goc')['goc'] != '':
                    goc = V014.objects.get(tip_name=filters.get('goc')['goc'])
                    f_ = sluchay['sluchay'].goc.id == goc.id if sluchay['sluchay'].goc != None else False
                    # if f_ == False: continue
            if filters.get('prpg', None) != None:
                if filters.get('prpg')['prpg'] != '':
                    prpg = Prpg.objects.get(naim=filters.get('prpg')['prpg'])
                    f_ = sluchay['sluchay'].prpg.id == prpg if sluchay['sluchay'].prpg != None else False
                    # if f_ == False: continue
            if filters.get('vrez', None) != None:
                if filters.get('vrez')['vrez'] != '':
                    vrez = Vrzb.objects.get(naim=filters.get('vrez')['vrez'])
                    f_ = sluchay['sluchay'].vrez.id == vrez.id if sluchay['sluchay'].vrez != None else False
                    # if f_ == False: continue
            if filters.get('dskz',None) != None:
                dskz_1,dskz_2 = filters.get('dskz').values()
                if dskz_1 != '' and dskz_2 != '':
                    f_ = dskz_1 >= sluchay['sluchay'].dskz.naim <= dskz_2 if sluchay['sluchay'].dskz != None else False
                    # if f_ == False: continue
            if filters.get('dsc', None) != None:
                if filters.get('dsc')['dsc'] != '':
                    dsc = filters.get('dsc')['dsc']
                    f_ = sluchay['sluchay'].dsc.naim == dsc if sluchay['sluchay'].dsc != None else False
                    # if f_ == False: continue
            if filters.get('dspat', None) != None:
                if filters.get('dspat')['dspat'] != '':
                    dspat = filters.get('dspat')['dspat']
                    f_ = sluchay['sluchay'].dspat.naim == dspat if sluchay['sluchay'].dspat != None else False
                    # if f_ == False: continue
            if filters.get('dson', None) != None:
                if filters.get('dson')['dson'] != '':
                    dson = filters.get('dson')['dson']
                    f_ = sluchay['sluchay'].dson.naim == dson if sluchay['sluchay'].dson != None else False
                    # if f_ == False: continue
            if filters.get('c_oksm', None) != None:
                if filters.get('c_oksm')['c_oksm'] != '':
                    c_oksm = Oksm.objects.get(naim=filters.get('c_oksm')['c_oksm'])
                    f_ = sluchay['patient'].c_oksm.id == c_oksm.id if sluchay['patient'].c_oksm != None else False
                    # if f_ == False: continue
            if filters.get('terr',None) != None:
                if filters.get('terr')['terr'] != '':
                    terr = filters.get('terr')['terr']
                    f_ = self.get_terr(sluchay['patient'].adr,
                                       terr)
                    # if f_ == False: continue
            if filters.get('reg',None) != None:
                if filters.get('reg')['reg'] != '':
                    reg = filters.get('reg')['reg']
                    f_ = reg in sluchay['patient'].adr
                    # if f_ == False: continue
            if filters.get('rai_in',None) != None:
                if filters.get('rai_in')['rai_in'] != '':
                    rai_in = filters.get('rai_in')['rai_in']
                    f_ = rai_in in sluchay['patient'].rai_display() if sluchay['patient'].rai != None else False
                    # if f_ == False: continue
            if filters.get('cj',None) != None:
                if filters.get('cj')['cj'] != '':
                    cj = CJ.objects.get(naim=filters.get('cj')['cj'].lower())
                    f_ = sluchay['patient'].cj.id == cj.id if sluchay['patient'].cj != None else False
                    # if f_ == False: continue
            if filters.get('lpy',None) != None:
                if filters.get('lpy')['lpy'] != '':
                    lpy = F003.objects.get(naim=filters.get('lpy')['lpy'])
                    f_ = sluchay['sluchay'].lpy.id == lpy.id if sluchay['sluchay'].lpy !=  None else False
                    # if f_ == False: continue
            if filters.get('ctkom',None) != None:
                if sluchay['vds'] != None :
                    if filters.get('ctkom')['ctkom'] != '':
                        ctkom = Skom.objects.get(naim=filters.get('ctkom')['ctkom'])
                        f_ = sluchay['vds'].ctkom.id == ctkom.id if sluchay['vds'].ctkom != None else False
                    # if f_ == False: continue
            if filters.get('icx',None) != None:
                if filters.get('icx')['icx'] != '':
                    icx = V012.objects.get(iz_name=filters.get('icx')['icx'],dl_uslov=1)
                    f_ = sluchay['sluchay'].icx.id == icx.id if sluchay['sluchay'].icx != None else False
                    # if f_ == False: continue
            if filters.get('otdel_let',None) != None:
                if filters.get('otdel_let')['otdel_let'] != '':
                    otdel_let = otde.objects.get(naim=filters.get('otdel_let')['otdel_let'])
                    f_ =  sluchay['sluchay'].otd.id == otdel_let.id if sluchay['sluchay'].otd != None else False
                    # if f_ == False: continue
            if filters.get('kod_vra',None) != None:
                if sluchay['le_vr'] != None:
                    if filters.get('kod_vra')['vra'] != '':
                        kod_vra = filters.get('kod_vra')['vra']
                        f_ = sluchay['le_vr'].kod.kod == kod_vra if sluchay['le_vr'].kod != None else False
                        # if f_ == False: continue
            if filters.get('kod_op',None) != None:
                if sluchay['oper'] != None:
                    if filters.get('kod_op')['kod_op'] != '':
                        kod_op = V001.objects.get(kod=filters.get('kod_op')['kod_op'])
                        for oper in sluchay['oper']:
                            f_ = oper.kod_op.id == kod_op.id if oper.kod_op != None else False
                        #if f_ == False: continue
            if filters.get('pr_osob',None) != None:
                if sluchay['oper'] != None:
                    if filters.get('pr_osob')['pr_osob'] != '':
                        pr_osob = PR_OSOB.objects.get(naim=filters.get('pr_osob')['pr_osob'])
                        for oper in sluchay['oper']:
                            f_ = pr_osob.id in [i['id'] for i in oper.pr_osob.values('id')]
                        # if f_ == False: continue
            if filters.get('t_trv',None) != None:
                if sluchay['le_trv'] != None :
                    if filters.get('t_trv')['t_trv'] != '':
                        if filters.get('t_trv')['t_trv'] != '':
                            t_trv = Trv.objects.get(naim=filters.get('t_trv')['t_trv'])
                            f_ = sluchay['le_trv'].t_trv.id == t_trv.id if sluchay['le_trv'].t_trv != None else False
                            # if f_ == False: continue
            if filters.get('trav_ns',None) != None:
                if sluchay['le_trv'] != None:
                    if filters.get('trav_ns')['trav_ns'] != '':
                        trav_ns = Trvnas.objects.get(naim=filters.get('trav_ns')['trav_ns'])
                        f_ = sluchay['le_trv'].trav_ns.id == trav_ns.id if sluchay['le_trv'].trav_ns != None else False
                        # if f_ == False: continue
            if filters.get('disability',None) != None:
                if sluchay['disability'] != None:
                    if sluchay['disability'].dat_l1 != None and sluchay['disability'].dat_l2 != None:
                        f_ = True
                    else:
                        f_ = False
                    # if f_ == False: continue
            if filters.get('srber',None) != None:
                if sluchay['disability'] != None:
                    num_1,num_2 = filters.get('srber').values()
                    if num_1 != '' and num_2 != '':
                            f_ = num_1 <= sluchay['disability'].srber <= num_2 if sluchay['disability'].srber != None\
                                                                                  and sluchay['disability'].srber != 0 else False
                    # if f_ == False: continue
            if filters.get('potd',None) != None:
                if sluchay['vb_s'] != None:
                    if filters.get('potd')['potd'] != '':
                        potd = otde.objects.get(naim=filters.get('potd')['potd'])
                        f_ = sluchay['vb_s'][0].potd.id == potd.id if sluchay['vb_s'][0].potd != None else False
                    # if f_ == False: continue
            if filters.get('kod_y',None) != None:
                if sluchay['vb_s'] != None:
                    if filters.get('kod_y')['kod_y'] != '':
                        kod_y = F003.objects.get(naim=filters.get('kod_y')['kod_y'])
                        f_ = sluchay['vb_s'][0].kod_y.id == kod_y.id if sluchay['vb_s'][0].kod_y != None else False
                    # if f_ == False: continue
            if filters.get('dskz_prich',None) != None:
                if filters.get('dskz_prich')['dskz_prich'] != None:
                    f_ = sluchay['sluchay'].dskz.naim == filters.get('dskz_prich')['dskz_prich'] if sluchay['sluchay'].dskz != None else False
                    # if f_ == False: continue
            if filters.get('pr_per',None) != None:
                if sluchay['vb_s'] != None:
                    if filters.get('pr_per')['pr_per'] != None:
                        pr_per = PR_PER.objects.get(naim=filters.get('pr_per')['pr_per'])
                        f_ = sluchay['vb_s'][0].pr_per.id == pr_per.id if sluchay['vb_s'][0].pr_per != None else False
                        # if f_ == False: continue
            if filters.get('time_minuts_po',None) != None:
                if filters.get('time_minuts_po')['time_minuts_po'] != '':
                    time_minuts_po = filters.get('time_minuts_po')['time_minuts_po']
                    if sluchay['sluchay'].tm_otd != None and sluchay['sluchay'].tm_otd_1 != None:
                        tm_otd = time.strptime(sluchay['sluchay'].tm_otd,'%H:%M')
                        tm_otd_1 = time.strptime(sluchay['sluchay'].tm_otd_1, '%H:%M')
                        f_ = (tm_otd_1.tm_min - tm_otd.tm_min) == int(time_minuts_po)
                    # if f_ == False: continue
            
            if  filters.get('abobsh_list',None)!= None:
                abobsh = filters.get('abobsh_list')
                if abobsh['abobsh'] != '':
                   if sluchay['manpy'] != None:
                       for manpy in sluchay['manpy']:
                            f_ = abobsh['abobsh'] == manpy.kodmn.kod if manpy.kodmn != None else False
                            if f_:
                                break
                 # if f_ == False: continue
            if filters.get('kod_vra_man',None) != None:
                vra = filters.get('kod_vra_man')
                if vra['vra'] != '':
                    for manpy in sluchay['manpy']:
                        f_ = vra['vra'] == manpy.tnvr.kod if manpy.tnvr != None else False
                        if f_:
                            break
                # if f_ == False: continue

            if f_:
                f.append(sluchay)

            # print(f)

        return f
    def age_group(self,*args):
        vs,nvs,datr,age_group = args
        if age_group.name == 'до 1 года':
            return  nvs in ['Д','М']
        elif age_group.name == '1 - до 7 лет':
            return  nvs == 'Л' and (1<=vs<=7)
        elif age_group.name == '7 - 14 лет':
            return  nvs == 'Л' and (7<=vs<=14)
        elif age_group.name == 'подростки 15 лет':
            return  nvs == 'Л' and (vs==15)
        elif age_group.name == '18 - 19 лет':
            return  nvs == 'Л' and (18<=vs<=19)
        elif age_group.name == '20 - 29 лет':
            return  nvs == 'Л' and (20<=vs<=29)
        elif age_group.name == '30 - 39 лет':
            return  nvs == 'Л' and (30<=vs<=39)
        elif age_group.name == '40 - 49 лет':
            return  nvs == 'Л' and (40<=vs<=49)
        elif age_group.name == '50 - 59 лет':
            return  nvs == 'Л' and (50<=vs<=59)
        elif age_group.name == '60 - 69 лет':
            return  nvs == 'Л' and (60<=vs<=69)
        elif age_group.name == '70 - 79 лет':
            return  nvs == 'Л' and (70<=vs<=79)
        elif age_group.name == '80 и старше лет':
            return  nvs == 'Л' and (80<=vs)
        elif age_group.name == 'от 0 до 17 лет':
            return  nvs == 'Л' and (0<=vs<=17)
        elif age_group.name == 'старше 60 и старше':
            return  nvs == 'Л' and (60<=vs)
        elif age_group.name == '70 лет и старше':
            return  nvs == 'Л' and (70<=vs)
        elif age_group.name == 'до 65 лет':
            return  nvs == 'Л' and (65>=vs)
        elif age_group.name == '18 - 59 лет':
            return  nvs == 'Л' and (18<=vs<=59)
        elif age_group.name == '1968 - 1983 г.':
            return  nvs == 'Л' and (1968<=datr.year<=1983)
        elif age_group.name == '30 - 50 лет':
            return  nvs == 'Л' and (30<=vs<=50)
        elif age_group.name == 'трудоспособные':
            return  nvs == 'Л' and ((18<=vs<=55) or (18<=vs<=60))
        elif age_group.name == 'нетрудоспособные':
            return  nvs == 'Л' and ((18<=vs<=56) or (18<=vs<=61))
        elif age_group.name == 'до 50 лет':
            return  nvs == 'Л' and (50>=vs)
        elif age_group.name == '15 - 16 лет':
            return  nvs == 'Л' and (15<=vs<=16)
        elif age_group.name == 'с 18 по 50 лет':
            return  nvs == 'Л' and (18<=vs<=50)
        elif age_group.name == '55 лет и старше':
            return  nvs == 'Л' and (55<=vs)
        elif age_group.name == 'от 40 до 55 лет':
            return  nvs == 'Л' and (40<=vs<=55)
        elif age_group.name == 'с 17 по 26 лет':
            return  nvs == 'Л' and (17<=vs<=26)
        elif age_group.name == 'с 10 до 14 лет':
            return  nvs == 'Л' and (10<=vs<=14)
        elif age_group.name == '18 лет и старше':
            return  nvs == 'Л' and (18<=vs)
        elif age_group.name == 'с 18 до 27 лет':
            return  nvs == 'Л' and (18<=vs<=27)
        elif age_group.name == 'от 40 до 60 лет':
            return  nvs == 'Л' and (40<=vs<=60)

    def get_terr(self,*args):
        adr, terr = args
        if terr == 'г.Тюменю':
            return 'Тюмень' in adr
        elif terr == 'Юг Тюм.обл.кроме Тюм.р-н':
            return (('Тюменская обл' in adr) or ('обл. Тюменская' in adr) or ('ОБЛ ТЮМЕНСКАЯ' in adr))\
                   and (('Тюменский р-н' not in adr) or ('р-н. Тюменский' not in adr))
        elif terr == 'Тюменский р-н':
            return 'Тюменский р-н' in adr or 'р-н. Тюменский' in adr
        elif terr == 'Ханты-Мансйский АО':
            return 'Ханты-Мансийский' in adr
        elif terr == 'Ямало-Немецкий АО':
            return 'Ямало-Ненецкий' in adr
        elif terr == 'Др.регионы Россий':
            return (('Тюменская обл' not in adr) and ('обл. Тюменская' not in adr) and ('ОБЛ ТЮМЕНСКАЯ' not in adr))\
                   and (('Тюменский р-н' not in adr) and ('р-н. Тюменский' not in adr))
