from services.hospital.reports import Reports
from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer
from openpyxl.styles import numbers
from openpyxl import Workbook
from  openpyxl.styles import Font,Alignment,Border,Side
from openpyxl import load_workbook
import json
import copy
import os
import shutil
from django.conf import  settings
from okb2.models import MyUser

class Create(Reports):
    def __init__(self,user,request):
        super().__init__(user,request)
        self.user_group_name = 'hospital_reports_%s' % user
        self.list_data = json.loads(self.request['list_data']) if self.request.get('list_data') != None else []
        self.path_shoblons = 'shoblons/hospital/oth'
        self.temp_dir = 'temp'
        self.border = Border(left=Side(border_style='thin',color='000000'),
                            right=Side(border_style='thin', color='000000'),
                            top=Side(border_style='thin',color='000000'),
                            bottom=Side(border_style='thin', color='000000'))

    def create(self):
        self.get_patients(limit=10)
        self.sluchays = self.get_sluchays(self.patient_list_obj)
        self.old_sluchays = copy.deepcopy(self.sluchays)

        #Допилить с фильтрами
        # filters = json.loads(self.request.get('filters'))
        #
        # self.sluchays = self.filter(filters, self.sluchays)




        type_fun = self.request.get('type_report')
        if type_fun == 'a_oth_1':
            self.a_oth_1()
        elif type_fun == 'a_oth_2':
            self.a_oth_2()
        elif type_fun == 'a_oth_3':
            self.a_oth_3()
        elif type_fun == 'a_oth_4':
            self.a_oth_4()
        elif type_fun == 'a_oth_5':
            self.a_oth_5()
        elif type_fun == 'a_oth_6':
            self.a_oth_6()
        elif type_fun == 'a_oth_7':
            self.a_oth_7()
        elif type_fun == 'a_oth_8':
            self.a_oth_8()
        elif type_fun == 'a_oth_9':
            self.a_oth_9()
        elif type_fun == 'a_oth_10':
            self.a_oth_10()
        elif type_fun == 'a_oth_11':
            self.a_oth_11()
        elif type_fun == 'a_oth_12':
            self.a_oth_12()
        elif type_fun == 'a_oth_13':
            self.a_oth_13()
        elif type_fun == 'a_oth_14':
            self.a_oth_14()
        elif type_fun == 'a_oth_15':
            self.a_oth_15()
        elif type_fun == 'a_oth_16':
            self.a_oth_16()
        elif type_fun == 'a_oth_17':
            self.a_oth_17()
        elif type_fun == 'a_oth_18':
            self.a_oth_18()
        elif type_fun == 'a_oth_19':
            self.a_oth_19()
        elif type_fun == 'a_oth_20':
            self.a_oth_20()
        elif type_fun == 'a_oth_21':
            self.a_oth_21()
        elif type_fun == 'a_oth_22':
            self.a_oth_22()
        elif type_fun == 'a_oth_23':
            self.a_oth_23()
        elif type_fun == 'a_oth_24':
            self.a_oth_24()
        elif type_fun == 'a_oth_25':
            self.a_oth_25()
        elif type_fun == 'a_oth_26':
            self.a_oth_26()
        elif type_fun == 'a_oth_27':
            self.a_oth_27()
        elif type_fun == 'a_oth_28':
            self.a_oth_28()
        elif type_fun == 'a_oth_29':
            self.a_oth_29()
        elif type_fun == 'a_oth_30':
            self.a_oth_30()
        elif type_fun == 'a_oth_31':
            self.a_oth_31()
        elif type_fun == 'a_oth_32':
            self.a_oth_32()
        elif type_fun == 'a_oth_33':
            self.a_oth_33()
        elif type_fun == 'a_oth_34':
            self.a_oth_34()


    def a_oth_1(self):
        file_shoblon = '/'.join([settings.MEDIA_ROOT,self.path_shoblons,'a_oth_1.xlsx'])
        if os.path.exists(file_shoblon):
            file_new = str(self.request.get('filename')) + '.xlsx' if len(str(self.request.get('filename'))) > 0  else 'a_oth_1.xlsx'
            file_new = '/'.join([settings.MEDIA_ROOT,self.temp_dir,str(self.user.id),file_new])
            shutil.copy2(file_shoblon,file_new)
            wb = load_workbook(file_new)
            sheet = wb.active
            sheet.cell(row=4,column=1).value = f'За период с {self.date_1.strftime("%d.%m.%Y")} по {self.date_2.strftime("%d.%m.%Y")} г.'
            sheet.cell(row=5,column=1).value = str(self.user.statistics_type.name).capitalize()
            temp = []
            for slych in self.sluchays:
                temp.append(
                    [
                        slych['sluchay'].otd.naim if slych['sluchay'].otd != None else '',
                        len(slych['manpy']) if slych['manpy'] != None else 0,
                        1 if slych['sluchay'].goc != None and slych['sluchay'].goc.tip_name == 'Экстренная' else 0,
                        1 if slych['sluchay'].goc != None and slych['sluchay'].goc.tip_name == 'Плановая' else 0
                    ]
                )
            res_set = [[r, 0, 0, 0] for r in list(set(otd[0] for otd in temp))]
            row = 9
            for t in temp:
                for r in res_set:
                    if r[0] == t[0]:
                        r[1] += t[1]
                        r[2] += t[2]
                        r[3] += t[3]
            for i, res in enumerate(res_set):
                for l, r in enumerate(res):
                    sheet.cell(row=i + row,column=1 + l).value = r
                    sheet.cell(row=i + row, column=1 + l).alignment = Alignment(horizontal="center", vertical="center")
                    sheet.cell(row=i + row, column=1 + l).border = self.border

            wb.save(file_new)
            if self.user.statistics_type.id == 2:
                shutil.copy2(file_new,'/'.join([settings.MEDIA_MNT,'stat','STW','Отчёты']))
            elif self.user.statistics_type.id == 1:
                shutil.copy2(file_new, '/'.join([settings.MEDIA_MNT, 'stat', 'STD', 'Отчёты']))

            async_to_sync(get_channel_layer().group_send)(self.user_group_name,
                                                          {'type': 'report_data', 'text': 'Отчет фромирован'})

    def a_oth_2(self):
        file_shoblon = '/'.join([settings.MEDIA_ROOT,self.path_shoblons,'a_oth_2.xlsx'])
        if os.path.exists(file_shoblon):
            file_new = str(self.request.get('filename')) + '.xlsx' if len(str(self.request.get('filename'))) > 0 else 'a_oth_2.xlsx'
            file_new = '/'.join([settings.MEDIA_ROOT, self.temp_dir, str(self.user.id), file_new])
            shutil.copy2(file_shoblon,file_new)
            wb = load_workbook(file_new)
            sheet = wb.active
            sheet.cell(row=4,column=1).value = f'За период с {self.date_1.strftime("%d.%m.%Y")} по {self.date_2.strftime("%d.%m.%Y")} г.'
            sheet.cell(row=5,column=1).value = str(self.user.statistics_type.name).capitalize()

            temp = []
            for slych in self.sluchays:
                temp.append(
                    [
                        slych['sluchay'].otd.naim if slych['sluchay'].otd != None else '',
                        1 if slych['patient'].adr != '' and ((('Тюменская обл' not in slych['patient'].adr) and (
                                    'обл. Тюменская' not in slych['patient'].adr) and ('ОБЛ ТЮМЕНСКАЯ' not in slych['patient'].adr)) \
                                                             and (('Тюменский р-н' not in slych['patient'].adr) and (
                                            'р-н. Тюменский' not in slych['patient'].adr))) else 0,
                        1 if slych['patient'].adr != '' and 'Тюмень' in slych['patient'].adr else 0,
                        1 if slych['patient'].adr != '' and ((('Тюменская обл' in slych['patient'].adr) or (
                                    'обл. Тюменская' in slych['patient'].adr) or ('ОБЛ ТЮМЕНСКАЯ' in slych['patient'].adr)) \
                                                             and (('Тюменский р-н' not in slych['patient'].adr) or (
                                            'р-н. Тюменский' not in slych['patient'].adr))) else 0,
                        1 if slych['patient'].adr != '' and 'Тюменский р-н' in slych[
                            'patient'].adr or 'р-н. Тюменский' in slych['patient'].adr else 0,
                        1 if slych['patient'].adr != '' and 'Ханты-Мансийский' in slych['patient'].adr else 0,
                        1 if slych['patient'].adr != '' and 'Ямало-Ненецкий' in slych['patient'].adr else 0,
                        1 if slych['patient'].adr != '' and ((('Тюменская обл' not in slych['patient'].adr) and (
                                    'обл. Тюменская' not in slych['patient'].adr) and ('ОБЛ ТЮМЕНСКАЯ' not in slych['patient'].adr)) \
                                                             and (('Тюменский р-н' not in slych['patient'].adr) and ('р-н. Тюменский' not in slych['patient'].adr))) else 0,
                        1 if slych['patient'].c_oksm != None and slych['patient'].c_oksm.kod != 643 else 0
                    ]
                )

            res_set = [[r, 0, 0, 0, 0, 0, 0, 0, 0, 0] for r in list(set(otd[0] for otd in temp))]

            row = 9
            for t in temp:
                for r in res_set:
                    if r[0] == t[0]:
                        r[1] += sum(t[1:])
                        r[2] += t[2]
                        r[3] += t[3]
                        r[4] += t[4]
                        r[5] += t[5]
                        r[6] += t[6]
                        r[7] += t[7]
                        r[8] += t[8]

            for i, res in enumerate(res_set):
                for l, r in enumerate(res):
                    sheet.cell(row=i + row,column=1 + l).value = r
                    sheet.cell(row=i + row, column=1 + l).border = self.border
                    sheet.cell(row=i + row,column=1 + l).alignment = Alignment(horizontal="center",vertical="center")

            wb.save(file_new)
            if self.user.statistics_type.id == 2:
                shutil.copy2(file_new, '/'.join([settings.MEDIA_MNT, 'stat', 'STW', 'Отчёты']))
            elif self.user.statistics_type.id == 1:
                shutil.copy2(file_new, '/'.join([settings.MEDIA_MNT, 'stat', 'STD', 'Отчёты']))

            async_to_sync(get_channel_layer().group_send)(self.user_group_name,
                                                          {'type': 'report_data', 'text': 'Отчет фромирован'})
    def a_oth_3(self):
        pass

    def a_oth_4(self):
        file_shoblon = '/'.join([settings.MEDIA_ROOT, self.path_shoblons, 'a_oth_4.xlsx'])
        if os.path.exists(file_shoblon):
            file_new = self.dir + str(self.request.get('filename')) + '.xlsx' if len(str(self.request.get('filename'))) > 0 else 'a_oth_4.xlsx'
            file_new = '/'.join([settings.MEDIA_ROOT, self.temp_dir, str(self.user.id), file_new])
            shutil.copy2(file_shoblon, file_new)

            wb = load_workbook(file_new)
            sheet = wb.active
            sheet.cell(row=4,column=1).value = f'За период с {self.date_1.strftime("%d.%m.%Y")} по {self.date_2.strftime("%d.%m.%Y")} г.'
            sheet.cell(row=5, column=1).value = str(self.user.statistics_type.name).capitalize()
            wb.save()

            if self.user.statistics_type.id == 2:
                shutil.copy2(file_new, '/'.join([settings.MEDIA_MNT, 'stat', 'STW', 'Отчёты']))
            elif self.user.statistics_type.id == 1:
                shutil.copy2(file_new, '/'.join([settings.MEDIA_MNT, 'stat', 'STD', 'Отчёты']))

            async_to_sync(get_channel_layer().group_send)(self.user_group_name,
                                                          {'type': 'report_data', 'text': 'Отчет фромирован'})

    def a_oth_5(self):
        file_shoblon = '/'.join([settings.MEDIA_ROOT, self.path_shoblons, 'a_oth_5.xlsx'])
        if os.path.exists(file_shoblon):
            file_new = self.dir + str(self.request.get('filename')) + '.xlsx' if len(str(self.request.get('filename'))) > 0 else 'a_oth_5.xlsx'
            file_new = '/'.join([settings.MEDIA_ROOT, self.temp_dir, str(self.user.id), file_new])
            shutil.copy2(file_shoblon, file_new)

            wb = load_workbook(file_new)
            sheet = wb.active
            sheet.cell(row=4,column=1).value = f'За период с {self.date_1.strftime("%d.%m.%Y")} по {self.date_2.strftime("%d.%m.%Y")} г.'
            sheet.cell(row=5, column=1).value = str(self.user.statistics_type.name).capitalize()
            wb.save()

            if self.user.statistics_type.id == 2:
                shutil.copy2(file_new, '/'.join([settings.MEDIA_MNT, 'stat', 'STW', 'Отчёты']))
            elif self.user.statistics_type.id == 1:
                shutil.copy2(file_new, '/'.join([settings.MEDIA_MNT, 'stat', 'STD', 'Отчёты']))

            async_to_sync(get_channel_layer().group_send)(self.user_group_name,
                                                          {'type': 'report_data', 'text': 'Отчет фромирован'})

    def a_oth_6(self):
        file_shoblon = '/'.join([settings.MEDIA_ROOT, self.path_shoblons, 'a_oth_6.xlsx'])
        if os.path.exists(file_shoblon):
            file_new = self.dir + str(self.request.get('filename')) + '.xlsx' if len( str(self.request.get('filename'))) > 0 else 'a_oth_6.xlsx'
            file_new = '/'.join([settings.MEDIA_ROOT, self.temp_dir, str(self.user.id), file_new])
            shutil.copy2(file_shoblon, file_new)

            wb = load_workbook(file_new)
            sheet = wb.active
            sheet.cell(row=4,column=1).value = f'За период с {self.date_1.strftime("%d.%m.%Y")} по {self.date_2.strftime("%d.%m.%Y")} г.'
            sheet.cell(row=5, column=1).value = str(self.user.statistics_type.name).capitalize()
            wb.save()

            if self.user.statistics_type.id == 2:
                shutil.copy2(file_new, '/'.join([settings.MEDIA_MNT, 'stat', 'STW', 'Отчёты']))
            elif self.user.statistics_type.id == 1:
                shutil.copy2(file_new, '/'.join([settings.MEDIA_MNT, 'stat', 'STD', 'Отчёты']))

            async_to_sync(get_channel_layer().group_send)(self.user_group_name,
                                                          {'type': 'report_data', 'text': 'Отчет фромирован'})
    def a_oth_7(self):
        pass

    def a_oth_8(self):
        file_shoblon = '/'.join([settings.MEDIA_ROOT, self.path_shoblons, 'a_oth_8.xlsx'])
        if os.path.exists(file_shoblon):
            file_new = self.dir + str(self.request.get('filename')) + '.xlsx' if len(str(self.request.get('filename'))) > 0 else 'a_oth_8.xlsx'
            file_new = '/'.join([settings.MEDIA_ROOT, self.temp_dir, str(self.user.id), file_new])
            shutil.copy2(file_shoblon, file_new)

            wb = load_workbook(file_new)
            sheet = wb.active
            sheet.cell(row=4,column=1).value = f'За период с {self.date_1.strftime("%d.%m.%Y")} по {self.date_2.strftime("%d.%m.%Y")} г.'
            sheet.cell(row=5, column=1).value = str(self.user.statistics_type.name).capitalize()
            wb.save()

            if self.user.statistics_type.id == 2:
                shutil.copy2(file_new, '/'.join([settings.MEDIA_MNT, 'stat', 'STW', 'Отчёты']))
            elif self.user.statistics_type.id == 1:
                shutil.copy2(file_new, '/'.join([settings.MEDIA_MNT, 'stat', 'STD', 'Отчёты']))

            async_to_sync(get_channel_layer().group_send)(self.user_group_name,
                                                          {'type': 'report_data', 'text': 'Отчет фромирован'})
    def a_oth_9(self):
        file_shoblon = '/'.join([settings.MEDIA_ROOT, self.path_shoblons, 'a_oth_9.xlsx'])
        if os.path.exists(file_shoblon):
            file_new = self.dir + str(self.request.get('filename')) + '.xlsx' if len(str(self.request.get('filename'))) > 0 else 'a_oth_9.xlsx'
            file_new = '/'.join([settings.MEDIA_ROOT, self.temp_dir, str(self.user.id), file_new])
            shutil.copy2(file_shoblon, file_new)

            wb = load_workbook(file_new)
            sheet = wb.active
            sheet.cell(row=4,column=1).value = f'За период с {self.date_1.strftime("%d.%m.%Y")} по {self.date_2.strftime("%d.%m.%Y")} г.'
            sheet.cell(row=5, column=1).value = str(self.user.statistics_type.name).capitalize()
            wb.save()

            if self.user.statistics_type.id == 2:
                shutil.copy2(file_new, '/'.join([settings.MEDIA_MNT, 'stat', 'STW', 'Отчёты']))
            elif self.user.statistics_type.id == 1:
                shutil.copy2(file_new, '/'.join([settings.MEDIA_MNT, 'stat', 'STD', 'Отчёты']))

            async_to_sync(get_channel_layer().group_send)(self.user_group_name,
                                                          {'type': 'report_data', 'text': 'Отчет фромирован'})
    def a_oth_10(self):
        pass

    def a_oth_11(self):
        file_shoblon = '/'.join([settings.MEDIA_ROOT, self.path_shoblons, 'a_oth_11.xlsx'])
        if os.path.exists(file_shoblon):
            file_new = self.dir + str(self.request.get('filename')) + '.xlsx' if len(str(self.request.get('filename'))) > 0 else 'a_oth_11.xlsx'
            file_new = '/'.join([settings.MEDIA_ROOT, self.temp_dir, str(self.user.id), file_new])
            shutil.copy2(file_shoblon, file_new)

            wb = load_workbook(file_new)
            sheet = wb.active
            sheet.cell(row=4,column=1).value = f'За период с {self.date_1.strftime("%d.%m.%Y")} по {self.date_2.strftime("%d.%m.%Y")} г.'
            sheet.cell(row=5, column=1).value = str(self.user.statistics_type.name).capitalize()
            wb.save()

            if self.user.statistics_type.id == 2:
                shutil.copy2(file_new, '/'.join([settings.MEDIA_MNT, 'stat', 'STW', 'Отчёты']))
            elif self.user.statistics_type.id == 1:
                shutil.copy2(file_new, '/'.join([settings.MEDIA_MNT, 'stat', 'STD', 'Отчёты']))

            async_to_sync(get_channel_layer().group_send)(self.user_group_name,
                                                          {'type': 'report_data', 'text': 'Отчет фромирован'})
    def a_oth_12(self):
        file_shoblon = '/'.join([settings.MEDIA_ROOT, self.path_shoblons, 'a_oth_12.xlsx'])
        if os.path.exists(file_shoblon):
            file_new = self.dir + str(self.request.get('filename')) + '.xlsx' if len(str(self.request.get('filename'))) > 0 else 'a_oth_12.xlsx'
            file_new = '/'.join([settings.MEDIA_ROOT, self.temp_dir, str(self.user.id), file_new])
            shutil.copy2(file_shoblon, file_new)

            wb = load_workbook(file_new)
            sheet = wb.active
            sheet.cell(row=4,column=1).value = f'За период с {self.date_1.strftime("%d.%m.%Y")} по {self.date_2.strftime("%d.%m.%Y")} г.'
            sheet.cell(row=5, column=1).value = str(self.user.statistics_type.name).capitalize()
            wb.save()

            if self.user.statistics_type.id == 2:
                shutil.copy2(file_new, '/'.join([settings.MEDIA_MNT, 'stat', 'STW', 'Отчёты']))
            elif self.user.statistics_type.id == 1:
                shutil.copy2(file_new, '/'.join([settings.MEDIA_MNT, 'stat', 'STD', 'Отчёты']))

            async_to_sync(get_channel_layer().group_send)(self.user_group_name,
                                                          {'type': 'report_data', 'text': 'Отчет фромирован'})
    def a_oth_13(self):
        file_shoblon = '/'.join([settings.MEDIA_ROOT, self.path_shoblons, 'a_oth_13.xlsx'])
        if os.path.exists(file_shoblon):
            file_new = self.dir + str(self.request.get('filename')) + '.xlsx' if len(str(self.request.get('filename'))) > 0 else 'a_oth_13.xlsx'
            file_new = '/'.join([settings.MEDIA_ROOT, self.temp_dir, str(self.user.id), file_new])
            shutil.copy2(file_shoblon, file_new)

            wb = load_workbook(file_new)
            sheet = wb.active
            sheet.cell(row=4,column=1).value = f'За период с {self.date_1.strftime("%d.%m.%Y")} по {self.date_2.strftime("%d.%m.%Y")} г.'
            sheet.cell(row=5, column=1).value = str(self.user.statistics_type.name).capitalize()
            wb.save()

            if self.user.statistics_type.id == 2:
                shutil.copy2(file_new, '/'.join([settings.MEDIA_MNT, 'stat', 'STW', 'Отчёты']))
            elif self.user.statistics_type.id == 1:
                shutil.copy2(file_new, '/'.join([settings.MEDIA_MNT, 'stat', 'STD', 'Отчёты']))

            async_to_sync(get_channel_layer().group_send)(self.user_group_name,
                                                          {'type': 'report_data', 'text': 'Отчет фромирован'})
    def a_oth_14(self):
        file_shoblon = '/'.join([settings.MEDIA_ROOT, self.path_shoblons, 'a_oth_14.xlsx'])
        if os.path.exists(file_shoblon):
            file_new = self.dir + str(self.request.get('filename')) + '.xlsx' if len(str(self.request.get('filename'))) > 0 else 'a_oth_14.xlsx'
            file_new = '/'.join([settings.MEDIA_ROOT, self.temp_dir, str(self.user.id), file_new])
            shutil.copy2(file_shoblon, file_new)

            wb = load_workbook(file_new)
            sheet = wb.active
            sheet.cell(row=4,column=1).value = f'За период с {self.date_1.strftime("%d.%m.%Y")} по {self.date_2.strftime("%d.%m.%Y")} г.'
            sheet.cell(row=5, column=1).value = str(self.user.statistics_type.name).capitalize()
            wb.save()

            if self.user.statistics_type.id == 2:
                shutil.copy2(file_new, '/'.join([settings.MEDIA_MNT, 'stat', 'STW', 'Отчёты']))
            elif self.user.statistics_type.id == 1:
                shutil.copy2(file_new, '/'.join([settings.MEDIA_MNT, 'stat', 'STD', 'Отчёты']))

            async_to_sync(get_channel_layer().group_send)(self.user_group_name,
                                                          {'type': 'report_data', 'text': 'Отчет фромирован'})
    def a_oth_15(self):
        pass

    def a_oth_16(self):
        pass

    def a_oth_17(self):
        pass

    def a_oth_18(self):
        file_shoblon = '/'.join([settings.MEDIA_ROOT, self.path_shoblons, 'a_oth_18.xlsx'])
        if os.path.exists(file_shoblon):
            file_new = self.dir + str(self.request.get('filename')) + '.xlsx' if len(str(self.request.get('filename'))) > 0 else 'a_oth_18.xlsx'
            file_new = '/'.join([settings.MEDIA_ROOT, self.temp_dir, str(self.user.id), file_new])
            shutil.copy2(file_shoblon, file_new)

            wb = load_workbook(file_new)
            sheet = wb.active
            sheet.cell(row=4,column=1).value = f'За период с {self.date_1.strftime("%d.%m.%Y")} по {self.date_2.strftime("%d.%m.%Y")} г.'
            sheet.cell(row=5, column=1).value = str(self.user.statistics_type.name).capitalize()
            wb.save()

            if self.user.statistics_type.id == 2:
                shutil.copy2(file_new, '/'.join([settings.MEDIA_MNT, 'stat', 'STW', 'Отчёты']))
            elif self.user.statistics_type.id == 1:
                shutil.copy2(file_new, '/'.join([settings.MEDIA_MNT, 'stat', 'STD', 'Отчёты']))

            async_to_sync(get_channel_layer().group_send)(self.user_group_name,
                                                          {'type': 'report_data', 'text': 'Отчет фромирован'})
    def a_oth_19(self):
        file_shoblon = '/'.join([settings.MEDIA_ROOT, self.path_shoblons, 'a_oth_19.xlsx'])
        if os.path.exists(file_shoblon):
            file_new = self.dir + str(self.request.get('filename')) + '.xlsx' if len(str(self.request.get('filename'))) > 0 else 'a_oth_19.xlsx'
            file_new = '/'.join([settings.MEDIA_ROOT, self.temp_dir, str(self.user.id), file_new])
            shutil.copy2(file_shoblon, file_new)

            wb = load_workbook(file_new)
            sheet = wb.active
            sheet.cell(row=4,column=1).value = f'За период с {self.date_1.strftime("%d.%m.%Y")} по {self.date_2.strftime("%d.%m.%Y")} г.'
            sheet.cell(row=5, column=1).value = str(self.user.statistics_type.name).capitalize()
            sheet.cell(row=26,column=1).value = f'За период с {self.date_1.strftime("%d.%m.%Y")} по {self.date_2.strftime("%d.%m.%Y")} г.'
            sheet.cell(row=27, column=1).value = str(self.user.statistics_type.name).capitalize()
            wb.save()

            if self.user.statistics_type.id == 2:
                shutil.copy2(file_new, '/'.join([settings.MEDIA_MNT, 'stat', 'STW', 'Отчёты']))
            elif self.user.statistics_type.id == 1:
                shutil.copy2(file_new, '/'.join([settings.MEDIA_MNT, 'stat', 'STD', 'Отчёты']))

            async_to_sync(get_channel_layer().group_send)(self.user_group_name,
                                                          {'type': 'report_data', 'text': 'Отчет фромирован'})

    def a_oth_20(self):
        pass

    def a_oth_21(self):
        pass

    def a_oth_22(self):
        pass

    def a_oth_23(self):
        file_shoblon = '/'.join([settings.MEDIA_ROOT, self.path_shoblons, 'a_oth_23.xlsx'])
        if os.path.exists(file_shoblon):
            file_new = self.dir + str(self.request.get('filename')) + '.xlsx' if len(str(self.request.get('filename'))) > 0 else 'a_oth_23.xlsx'
            file_new = '/'.join([settings.MEDIA_ROOT, self.temp_dir, str(self.user.id), file_new])
            shutil.copy2(file_shoblon, file_new)

            wb = load_workbook(file_new)
            sheet = wb.active
            sheet.cell(row=4,column=1).value = f'За период с {self.date_1.strftime("%d.%m.%Y")} по {self.date_2.strftime("%d.%m.%Y")} г.'
            sheet.cell(row=5, column=1).value = str(self.user.statistics_type.name).capitalize()
            wb.save()

            if self.user.statistics_type.id == 2:
                shutil.copy2(file_new, '/'.join([settings.MEDIA_MNT, 'stat', 'STW', 'Отчёты']))
            elif self.user.statistics_type.id == 1:
                shutil.copy2(file_new, '/'.join([settings.MEDIA_MNT, 'stat', 'STD', 'Отчёты']))

            async_to_sync(get_channel_layer().group_send)(self.user_group_name,
                                                          {'type': 'report_data', 'text': 'Отчет фромирован'})

    def a_oth_24(self):
        file_shoblon = '/'.join([settings.MEDIA_ROOT, self.path_shoblons, 'a_oth_24.xlsx'])
        if os.path.exists(file_shoblon):
            file_new = self.dir + str(self.request.get('filename')) + '.xlsx' if len(str(self.request.get('filename'))) > 0 else 'a_oth_24.xlsx'
            file_new = '/'.join([settings.MEDIA_ROOT, self.temp_dir, str(self.user.id), file_new])
            shutil.copy2(file_shoblon, file_new)

            wb = load_workbook(file_new)
            sheet = wb.active
            sheet.cell(row=4,column=1).value = f'За период с {self.date_1.strftime("%d.%m.%Y")} по {self.date_2.strftime("%d.%m.%Y")} г.'
            sheet.cell(row=5, column=1).value = str(self.user.statistics_type.name).capitalize()
            wb.save()

            if self.user.statistics_type.id == 2:
                shutil.copy2(file_new, '/'.join([settings.MEDIA_MNT, 'stat', 'STW', 'Отчёты']))
            elif self.user.statistics_type.id == 1:
                shutil.copy2(file_new, '/'.join([settings.MEDIA_MNT, 'stat', 'STD', 'Отчёты']))

            async_to_sync(get_channel_layer().group_send)(self.user_group_name,
                                                          {'type': 'report_data', 'text': 'Отчет фромирован'})

    def a_oth_25(self):
        file_shoblon = '/'.join([settings.MEDIA_ROOT, self.path_shoblons, 'a_oth_25.xlsx'])
        if os.path.exists(file_shoblon):
            file_new = self.dir + str(self.request.get('filename')) + '.xlsx' if len(str(self.request.get('filename'))) > 0 else 'a_oth_25.xlsx'
            file_new = '/'.join([settings.MEDIA_ROOT, self.temp_dir, str(self.user.id), file_new])
            shutil.copy2(file_shoblon, file_new)

            wb = load_workbook(file_new)
            sheet = wb.active
            sheet.cell(row=4,column=1).value = f'За период с {self.date_1.strftime("%d.%m.%Y")} по {self.date_2.strftime("%d.%m.%Y")} г.'
            sheet.cell(row=5, column=1).value = str(self.user.statistics_type.name).capitalize()
            wb.save()

            if self.user.statistics_type.id == 2:
                shutil.copy2(file_new, '/'.join([settings.MEDIA_MNT, 'stat', 'STW', 'Отчёты']))
            elif self.user.statistics_type.id == 1:
                shutil.copy2(file_new, '/'.join([settings.MEDIA_MNT, 'stat', 'STD', 'Отчёты']))

            async_to_sync(get_channel_layer().group_send)(self.user_group_name,
                                                          {'type': 'report_data', 'text': 'Отчет фромирован'})

    def a_oth_26(self):
        file_shoblon = '/'.join([settings.MEDIA_ROOT, self.path_shoblons, 'a_oth_26.xlsx'])
        if os.path.exists(file_shoblon):
            file_new = self.dir + str(self.request.get('filename')) + '.xlsx' if len(str(self.request.get('filename'))) > 0 else 'a_oth_26.xlsx'
            file_new = '/'.join([settings.MEDIA_ROOT, self.temp_dir, str(self.user.id), file_new])
            shutil.copy2(file_shoblon, file_new)

            wb = load_workbook(file_new)
            sheet = wb.active
            sheet.cell(row=4,column=1).value = f'За период с {self.date_1.strftime("%d.%m.%Y")} по {self.date_2.strftime("%d.%m.%Y")} г.'
            sheet.cell(row=5, column=1).value = str(self.user.statistics_type.name).capitalize()
            wb.save()

            if self.user.statistics_type.id == 2:
                shutil.copy2(file_new, '/'.join([settings.MEDIA_MNT, 'stat', 'STW', 'Отчёты']))
            elif self.user.statistics_type.id == 1:
                shutil.copy2(file_new, '/'.join([settings.MEDIA_MNT, 'stat', 'STD', 'Отчёты']))

            async_to_sync(get_channel_layer().group_send)(self.user_group_name,
                                                          {'type': 'report_data', 'text': 'Отчет фромирован'})

    def a_oth_27(self):
        pass

    def a_oth_28(self):
        pass

    def a_oth_29(self):
        file_shoblon = '/'.join([settings.MEDIA_ROOT, self.path_shoblons, 'a_oth_28.xlsx'])
        if os.path.exists(file_shoblon):
            file_new = self.dir + str(self.request.get('filename')) + '.xlsx' if len(str(self.request.get('filename'))) > 0 else 'a_oth_28.xlsx'
            file_new = '/'.join([settings.MEDIA_ROOT, self.temp_dir, str(self.user.id), file_new])
            shutil.copy2(file_shoblon, file_new)

            wb = load_workbook(file_new)
            sheet = wb.active
            sheet.cell(row=4,column=1).value = f'За период с {self.date_1.strftime("%d.%m.%Y")} по {self.date_2.strftime("%d.%m.%Y")} г.'
            sheet.cell(row=5, column=1).value = str(self.user.statistics_type.name).capitalize()
            wb.save()

            if self.user.statistics_type.id == 2:
                shutil.copy2(file_new, '/'.join([settings.MEDIA_MNT, 'stat', 'STW', 'Отчёты']))
            elif self.user.statistics_type.id == 1:
                shutil.copy2(file_new, '/'.join([settings.MEDIA_MNT, 'stat', 'STD', 'Отчёты']))

            async_to_sync(get_channel_layer().group_send)(self.user_group_name,
                                                          {'type': 'report_data', 'text': 'Отчет фромирован'})

    def a_oth_30(self):
        file_shoblon = '/'.join([settings.MEDIA_ROOT, self.path_shoblons, 'a_oth_30.xlsx'])
        if os.path.exists(file_shoblon):
            file_new = self.dir + str(self.request.get('filename')) + '.xlsx' if len(str(self.request.get('filename'))) > 0 else 'a_oth_30.xlsx'
            file_new = '/'.join([settings.MEDIA_ROOT, self.temp_dir, str(self.user.id), file_new])
            shutil.copy2(file_shoblon, file_new)

            wb = load_workbook(file_new)
            sheet = wb.active
            sheet.cell(row=4,column=1).value = f'За период с {self.date_1.strftime("%d.%m.%Y")} по {self.date_2.strftime("%d.%m.%Y")} г.'
            sheet.cell(row=5, column=1).value = str(self.user.statistics_type.name).capitalize()
            wb.save()

            if self.user.statistics_type.id == 2:
                shutil.copy2(file_new, '/'.join([settings.MEDIA_MNT, 'stat', 'STW', 'Отчёты']))
            elif self.user.statistics_type.id == 1:
                shutil.copy2(file_new, '/'.join([settings.MEDIA_MNT, 'stat', 'STD', 'Отчёты']))

            async_to_sync(get_channel_layer().group_send)(self.user_group_name,
                                                          {'type': 'report_data', 'text': 'Отчет фромирован'})

    def a_oth_31(self):
        file_shoblon = '/'.join([settings.MEDIA_ROOT, self.path_shoblons, 'a_oth_31.xlsx'])
        if os.path.exists(file_shoblon):
            file_new = self.dir + str(self.request.get('filename')) + '.xlsx' if len(str(self.request.get('filename'))) > 0 else 'a_oth_31.xlsx'
            file_new = '/'.join([settings.MEDIA_ROOT, self.temp_dir, str(self.user.id), file_new])
            shutil.copy2(file_shoblon, file_new)

            wb = load_workbook(file_new)
            sheet = wb.active
            sheet.cell(row=4,column=1).value = f'За период с {self.date_1.strftime("%d.%m.%Y")} по {self.date_2.strftime("%d.%m.%Y")} г.'
            sheet.cell(row=5, column=1).value = str(self.user.statistics_type.name).capitalize()
            wb.save()

            if self.user.statistics_type.id == 2:
                shutil.copy2(file_new, '/'.join([settings.MEDIA_MNT, 'stat', 'STW', 'Отчёты']))
            elif self.user.statistics_type.id == 1:
                shutil.copy2(file_new, '/'.join([settings.MEDIA_MNT, 'stat', 'STD', 'Отчёты']))

            async_to_sync(get_channel_layer().group_send)(self.user_group_name,
                                                          {'type': 'report_data', 'text': 'Отчет фромирован'})

    def a_oth_32(self):
        pass

    def a_oth_33(self):
        pass

    def a_oth_34(self):
        pass
