from services.hospital.reports import Reports
from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer
from openpyxl.styles import numbers
from openpyxl import Workbook
from  openpyxl.styles import Font,Alignment,Border,Side
from openpyxl import load_workbook
import json
import copy
import os
import shutil
from django.conf import  settings
from okb2.models import MyUser

class Create(Reports):
    def __init__(self,user,request):
        super().__init__(user,request)
        self.user_group_name = 'hospital_reference_%s' % user
        self.list_data = json.loads(self.request['list_data']) if self.request.get('list_data') != None else []
        self.path_shoblons = 'shoblons/hospital/forms'
        self.temp_dir = 'temp'
        self.border = Border(left=Side(border_style='thin',color='000000'),
                            right=Side(border_style='thin', color='000000'),
                            top=Side(border_style='thin',color='000000'),
                            bottom=Side(border_style='thin', color='000000'))


    def create(self):
        print(self.request)
        # print(self.date_1,self.date_2)
        # self.get_patients(limit=10)
        # self.sluchays = self.get_sluchays(self.patient_list_obj)
        # self.old_sluchays = copy.deepcopy(self.sluchays)
        type_fun = self.request.get('type_report')
        if type_fun == 'annual_13_1_1':
            self.annual_13_1_1()
        elif type_fun == 'annual_13_1_2':
            self.annual_13_1_2()
        elif type_fun == 'annual_13_1_3':
            self.annual_13_1_3()
        elif type_fun == 'annual_13_1_4':
            self.annual_13_1_4()
        elif type_fun == 'annual_13_1_5':
            self.annual_13_1_5()

    def annual_13_1_1(self):
        # print(self.user_group_name)
        file_shoblon = '/'.join([settings.MEDIA_ROOT, self.path_shoblons, 'Ф13.docx'])
        print(file_shoblon)
        async_to_sync(get_channel_layer().group_send)(self.user_group_name,
                                                      {'type': 'report_data', 'text': 'Отчет фромирован'})

    def annual_13_1_2(self):
        pass

    def annual_13_1_3(self):
        pass

    def annual_13_1_4(self):
        pass

    def annual_13_1_5(self):
        pass