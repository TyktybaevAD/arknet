import os
from hospital.models import *
from okb2.models import MyUser
from datetime import datetime
from  django.conf import settings
from django.db.models import  Q
class Patients:
    def __init__(self,user,request):
        # self.user_group_name = 'post_%s' % user
        self.user = MyUser.objects.get(user=user)
        self.request = request
        self.name_file = self.request.get('filename')
        self.path()

    def path(self):
        if not os.path.isdir(settings.MEDIA_ROOT + '/temp/' + f'{str(self.user.id)}/'):
            os.mkdir(settings.MEDIA_ROOT + '/temp/' + f'{str(self.user.id)}/')
        self.dir = settings.MEDIA_ROOT + '/temp/' + f'{str(self.user.id)}/'

    def get_patients(self,limit=None):
        self.date_1 = datetime.strptime(self.request.get('date_1'),'%Y-%m-%d').date()
        self.date_2 = datetime.strptime(self.request.get('date_2'), '%Y-%m-%d').date()
        if limit == None:
            sluchay_list = Sluchay.objects.values('id').filter(datp__gte=self.date_1,
                                                           datv__lte=self.date_2,
                                                           statistics_type=self.user.statistics_type)
            # sluchay_list = Sluchay.objects.values('id').filter(
            #                                             Q(nib='0201124977')
            #                                             |
            #                                             Q(nib='0201125246')
            #                                             |
            #                                             Q(nib='0202051239'))
            # print(sluchay_list)
        else:
            sluchay_list = Sluchay.objects.values('id').filter(datp__gte=self.date_1,
                                                               datv__lte=self.date_2,
                                                               statistics_type=self.user.statistics_type)[:limit]
        self.patient_list_obj = [Patient.objects.get(sluchay=sluchay['id']) for sluchay in sluchay_list]


    def get_sluchays(self,patient_list):
        self.patients = []
        for i,patient in enumerate(patient_list):
            patient_p = patient.patient_p if patient.patient_p != None else None
            sluchay = Sluchay.objects.get(id=patient.sluchay.values('id')[0]['id'])
            vb_s = [v for v in sluchay.vb_s.values('id')]
            vb_s = [Vb_s.objects.get(id=v['id']) for v in vb_s]
            vb_a = sluchay.vb_a if sluchay.vb_a != None else None
            vds = sluchay.vds if sluchay.vds != None else None
            le_vr = sluchay.le_vr if sluchay.le_vr != None else None
            le_trv = sluchay.le_trv if sluchay.le_trv != None else None
            # Берем все операции
            oper = [Oper.objects.get(id=oper['id']) for oper in sluchay.oper.values('id')] if sluchay.oper != None else None
            oslo = [op.oslo.values('id') for op in oper]
            oslo = [Oslo.objects.get(id=i['id']) for o in oslo for i in o ]
            manpy = [m for m in sluchay.manpy.values('id')]
            manpy = [Manpy.objects.get(id=m['id']) for m in manpy ]
            disability = sluchay.disability if sluchay.disability != None else None
            napr = sluchay.napr if sluchay.napr != None else None
            cons = sluchay.cons if sluchay.cons != None else None
            onk_sl = sluchay.onk_sl if sluchay.onk_sl != None else None
            b_diag = sluchay.b_diag if sluchay.b_diag != None else None
            b_prot = sluchay.b_prot if sluchay.b_prot != None else None
            onk_usl = sluchay.onk_usl if sluchay.onk_usl != None else None
            ksg_kpg = [k for k in sluchay.ksg_kpg.values('id')]
            ksg_kpg = [Ksg_kpg.objects.get(id=k['id']) for k in ksg_kpg]

            temp_d = dict()
            temp_d['patient'] = patient
            temp_d['patient_p'] = patient_p
            temp_d['sluchay'] = sluchay
            temp_d['vb_s'] = vb_s if vb_s != None and len(vb_s) > 0 else None
            temp_d['vb_a'] = vb_a
            temp_d['vds'] = vds
            temp_d['le_vr'] = le_vr
            temp_d['le_trv'] = le_trv
            temp_d['oper'] = oper
            temp_d['oslo'] = oslo if oslo != None and len(oslo) > 0 else None
            temp_d['manpy'] = manpy if manpy != None and len(oslo) > 0 else None
            temp_d['disability'] = disability
            temp_d['napr'] = napr
            temp_d['cons'] = cons
            temp_d['onk_sl'] = onk_sl
            temp_d['b_diag'] = b_diag
            temp_d['b_prot'] = b_prot
            temp_d['onk_usl'] = onk_usl
            temp_d['ksg_kpg'] = ksg_kpg if ksg_kpg != None and len(ksg_kpg) > 0 else None

            self.patients.append(temp_d)
        return self.patients
